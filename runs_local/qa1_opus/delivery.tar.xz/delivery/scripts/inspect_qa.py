"""Self-check of the delivery against QA-W100 rev A (our own reading of it).
python3 inspect_qa.py [movement.json|variant_6h.json] [--class D|B] [--only checks] [--assembly]"""
import json
import math
import os
import pickle
import sys
import time
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
APP = os.path.dirname(DELIV)
sys.path.insert(0, os.path.join(APP, "tools"))
sys.path.insert(0, HERE)
import kernel  # noqa: E402
import manifold3d as m3  # noqa: E402

CACHE = os.environ.get("QA_CACHE", os.path.join(APP, "work", "cache"))
TOL = 0.01
R_CASE, H_CASE = 20.7, 13.4
T_BARREL = 70.1
ALLOW = {"AD-C100-HT": 725.0, "AD-CW614N": 110.0}
SPEED = {"D": F(-1, 8), "B": F(-1, 6)}       # turns per hour, CCW positive


def lewis():
    txt = open(os.path.join(APP, "datasheets", "DS-W04_gear_rating.md")).read().split("## 3.")[1]
    Y = {}
    for line in txt.splitlines():
        c = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(c) == 11 and c[0].isdigit():
            for j in range(10):
                if c[j + 1] not in ("–", "-", ""):
                    Y[int(c[0]) + j] = float(c[j + 1])
    return Y


def load(name):
    p = os.path.join(DELIV, "parts", name + ".step")
    os.makedirs(CACHE, exist_ok=True)
    key = os.path.join(CACHE, "%s_%d_%d.pkl" % (name, os.path.getsize(p), int(os.path.getmtime(p))))
    if os.path.exists(key):
        v, t = pickle.load(open(key, "rb"))
        return m3.Manifold(m3.Mesh(vert_properties=v, tri_verts=t))
    man = kernel.load_step_part(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096, 0.005)
    mesh = man.to_mesh()
    pickle.dump((np.asarray(mesh.vert_properties), np.asarray(mesh.tri_verts)), open(key, "wb"))
    return man


def barrel():
    t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 7, 10 ** 9)
    return kernel.tris_to_manifold(t)


def rotz(man, c, deg):
    a = math.radians(deg)
    cs, sn = math.cos(a), math.sin(a)
    T = np.array([[cs, -sn, 0, c[0] - cs * c[0] + sn * c[1]], [sn, cs, 0, c[1] - sn * c[0] - cs * c[1]], [0, 0, 1, 0]])
    return man.transform(T.tolist())


def tr(man, d):
    return man.translate(list(map(float, d)))


def U(lst):
    return kernel.union(list(lst))


class Mv:
    def __init__(self, fname, cls):
        self.doc = json.load(open(os.path.join(DELIV, fname)))
        self.cls = cls
        d = self.doc
        self.parts = {}
        names = list(d["fixed"]) + [p for m in d["mobiles"].values() for p in m["parts"]]
        for n in names:
            self.parts[n] = load(n)
        self.fixed = d["fixed"]
        self.frame = U(self.parts[n] for n in self.fixed)
        self.mob = {"barrel": barrel()}
        self.axis = {"barrel": (0.0, 0.0)}
        self.mparts = {"barrel": ["barrel"]}
        self.parts["barrel"] = self.mob["barrel"]
        for k, m in d["mobiles"].items():
            self.mob[k] = U(self.parts[p] for p in m["parts"])
            self.axis[k] = tuple(m["axis"])
            self.mparts[k] = m["parts"]
        self.meshes = d["meshes"]


# ---------------- mesh test ----------------
def mesh_test(Dm, Dc, zD, Nm, Nc, zN, a_assembled, shift=0.0):
    """Returns (ok, details). shift: N moved along D->N line (+ away)."""
    Nc = np.array(Nc, float)
    Dc = np.array(Dc, float)
    v = Nc - Dc
    dist = np.hypot(*v)
    u = v / dist if dist > 0.01 else np.array([1.0, 0.0])
    Nm0 = tr(Nm, [u[0] * shift, u[1] * shift, 0]) if shift else Nm
    Ncs = Nc + u * shift
    m = 2 * a_assembled / (zD + zN)
    nsteps = 8 * max(zD, zN)
    worst_ov, worst_ratio, worst_gap, minV, minH = 0.0, 1e9, 0.0, 1e9, 1e9

    def pose(i):
        ang = i * 360.0 / (8 * zD)
        return rotz(Dm, Dc, ang), rotz(Nm0, Ncs, -ang * zD / zN), ang
    for i in range(nsteps):
        Dr, Nr, ang = pose(i)
        ov = kernel.ivol(Dr, Nr)
        worst_ov = max(worst_ov, ov)
        if i % 8 == 0:
            for fr in (1 / 3, 1 / 5):
                Da, Na, _ = pose(i + fr)
                worst_ov = max(worst_ov, kernel.ivol(Da, Na))
            D2 = rotz(Dm, Dc, ang + 90.0 / zD)
            reg = (D2 ^ Nr) - Dr
            V = reg.volume()
            if V > 0:
                bb = reg.bounding_box()
                H = bb[5] - bb[2]
            else:
                H = 0.0
            minV = min(minV, V)
            if H > 0:
                minH = min(minH, H)
                worst_ratio = min(worst_ratio, (V / H) / (0.5 * m * m))
            else:
                worst_ratio = 0.0
        if i % 4 == 0 and ov <= 1e-12:
            g = kernel.min_distance(Dr, Nr, 0.5)
            worst_gap = max(worst_gap, g)
    ok = worst_ov <= TOL and worst_gap <= 0.1 and minV >= 0.001 and worst_ratio > 1.0
    return ok, dict(ov=round(worst_ov, 5), gap=round(worst_gap, 4), minV=round(minV, 5), ratio=round(worst_ratio, 3),
                    b=round(minH, 4), m=round(m, 5))


def _mesh_job(args):
    fname, cls, idx, shift = args
    mv = Mv(fname, cls)
    e = mv.meshes[idx]
    Dn, Nn = e["driver"], e["driven"]
    a = float(np.hypot(*(np.array(mv.axis[Nn]) - np.array(mv.axis[Dn]))))
    t = time.time()
    ok, det = mesh_test(mv.mob[Dn], mv.axis[Dn], e["driver_teeth"], mv.mob[Nn], mv.axis[Nn], e["driven_teeth"], a, shift)
    det["t"] = round(time.time() - t, 1)
    return idx, shift, ok, det


def speeds(mv, passing):
    sp = {"barrel": SPEED[mv.cls]}
    bad = False
    changed = True
    while changed:
        changed = False
        for i, e in enumerate(mv.meshes):
            if not passing.get(i, False):
                continue
            Dn, Nn, zD, zN = e["driver"], e["driven"], e["driver_teeth"], e["driven_teeth"]
            for a, b, za, zb in ((Dn, Nn, zD, zN), (Nn, Dn, zN, zD)):
                if a in sp:
                    v = -sp[a] * F(za, zb)
                    if b in sp and sp[b] != v:
                        bad = True
                    elif b not in sp:
                        sp[b] = v
                        changed = True
    return sp, bad


def _pair_job(args):
    fname, cls, a, b, sa, sb = args
    mv = Mv(fname, cls)
    A, B = mv.mob[a], mv.mob[b]
    ca, cb = mv.axis[a], mv.axis[b]
    worst = 0.0
    fa, fb = abs(float(sa)), abs(float(sb))
    poses = []
    if fa == 0 and fb == 0:
        poses = [(0.0, 0.0)]
    else:
        fast = max(fa, fb)
        T = 1.0 / fast
        for k in range(144):
            t = T * k / 144
            poses.append((360 * float(sa) * t, 360 * float(sb) * t))
        if sa != sb:
            rel = abs(float(sa - sb))
            T2 = 1.0 / rel
            for k in range(144):
                t = T2 * k / 144
                poses.append((360 * float(sa) * t, 360 * float(sb) * t))
    for pa, pb in poses:
        worst = max(worst, kernel.ivol(rotz(A, ca, pa), rotz(B, cb, pb)))
    return a, b, worst


def part1(fname, cls, jobs=4, skip=()):
    t0 = time.time()
    mv = Mv(fname, cls)
    R = {}
    names = list(mv.mob)
    # C2
    c2 = []
    for k in names:
        v = kernel.ivol(mv.frame, mv.mob[k])
        if v > TOL:
            c2.append("frame x %s %.4f" % (k, v))
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            v = kernel.ivol(mv.mob[names[i]], mv.mob[names[j]])
            if v > TOL:
                c2.append("%s x %s %.4f" % (names[i], names[j], v))
    fx = mv.fixed
    for i in range(len(fx)):
        for j in range(i + 1, len(fx)):
            v = kernel.ivol(mv.parts[fx[i]], mv.parts[fx[j]])
            if v > TOL:
                c2.append("fixed %s x %s %.4f" % (fx[i], fx[j], v))
    for k in names:
        ps = mv.mparts[k]
        for i in range(len(ps)):
            for j in range(i + 1, len(ps)):
                v = kernel.ivol(mv.parts[ps[i]], mv.parts[ps[j]])
                if v > TOL:
                    c2.append("in %s: %s x %s %.4f" % (k, ps[i], ps[j], v))
    # frame connectivity
    joined = {fx[0]}
    changed = True
    while changed:
        changed = False
        for a in fx:
            if a in joined:
                continue
            for b in list(joined):
                if kernel.min_distance(mv.parts[a], mv.parts[b], 0.05) <= 0.01:
                    joined.add(a)
                    changed = True
                    break
    if len(joined) != len(fx):
        c2.append("frame not joined: %s" % (set(fx) - joined))
    R["C2"] = (not c2, c2)
    print("C2", R["C2"], round(time.time() - t0), flush=True)
    # 1 free to turn
    bad = []
    for k in names:
        w = max(kernel.ivol(mv.frame, rotz(mv.mob[k], mv.axis[k], 5 * s)) for s in range(72))
        if w > TOL:
            bad.append((k, w))
    R["1"] = (not bad, bad)
    print("1", R["1"], flush=True)
    # 2 held
    dirs = {"+x": (0.3, 0, 0), "-x": (-0.3, 0, 0), "+y": (0, 0.3, 0), "-y": (0, -0.3, 0), "+z": (0, 0, 0.3), "-z": (0, 0, -0.3)}
    notheld = []
    for dn, dv in dirs.items():
        held = {k: kernel.ivol(mv.frame, tr(mv.mob[k], dv)) > TOL for k in names}
        changed = True
        while changed:
            changed = False
            for k in names:
                if held[k]:
                    continue
                for j in names:
                    if j == k or not held[j]:
                        continue
                    if np.hypot(*(np.array(mv.axis[j]) - np.array(mv.axis[k]))) > 0.01:
                        continue
                    if kernel.ivol(tr(mv.mob[k], dv), mv.mob[j]) > TOL:
                        held[k] = True
                        changed = True
                        break
        notheld += [(k, dn) for k in names if not held[k]]
    R["2"] = (not notheld, notheld)
    print("2", R["2"], flush=True)
    # 3 seated
    bad = []
    for k in names:
        ps = mv.mparts[k]
        if k == "barrel" or len(ps) < 2:
            continue
        for p in ps:
            others = U(mv.parts[q] for q in ps if q != p)
            for dn in ("+x", "-x", "+y", "-y"):
                v = kernel.ivol(tr(mv.parts[p], dirs[dn]), others)
                if v <= TOL:
                    bad.append((k, p, dn, v))
            vz = [kernel.ivol(tr(mv.parts[p], dirs[dn]), others) for dn in ("+z", "-z")]
            if max(vz) <= TOL:
                bad.append((k, p, "z", vz))
        linked = {ps[0]}
        changed = True
        while changed:
            changed = False
            for p in ps:
                if p in linked:
                    continue
                if any(kernel.min_distance(mv.parts[p], mv.parts[q], 0.05) <= 0.02 for q in linked):
                    linked.add(p)
                    changed = True
        if len(linked) != len(ps):
            bad.append((k, "not one piece"))
    R["3"] = (not bad, bad)
    print("3", R["3"], flush=True)
    # 4, 5 mesh tests
    jobsl = [(fname, cls, i, s) for i in range(len(mv.meshes)) for s in (0.0, 0.03, -0.03)]
    if "5" in skip:
        jobsl = [j for j in jobsl if j[3] == 0.0]
    res = {}
    with ProcessPoolExecutor(jobs) as ex:
        for idx, sh, ok, det in ex.map(_mesh_job, jobsl):
            res[(idx, sh)] = (ok, det)
            e = mv.meshes[idx]
            print("  mesh %s->%s shift %+.2f %s %s" % (e["driver"], e["driven"], sh, ok, det), flush=True)
    passing = {i: res[(i, 0.0)][0] for i in range(len(mv.meshes))}
    sp, conflict = speeds(mv, passing)
    reached = all(k in sp for k in names)
    R["4"] = (all(passing.values()) and not conflict and reached and len(mv.meshes) > 0, (passing, conflict, reached))
    R["5"] = (all(res.get((i, s), (False,))[0] for i in range(len(mv.meshes)) for s in (0.03, -0.03)), None)
    print("speeds", {k: str(v) for k, v in sp.items()})
    print("4", R["4"], "5", R["5"], flush=True)
    # 6 non-meshed pairs
    meshed = {frozenset((e["driver"], e["driven"])) for e in mv.meshes}
    pj = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            if frozenset((a, b)) in meshed:
                continue
            pj.append((fname, cls, a, b, sp.get(a, F(0)), sp.get(b, F(0))))
    bad = []
    with ProcessPoolExecutor(jobs) as ex:
        for a, b, w in ex.map(_pair_job, pj):
            if w > TOL:
                bad.append((a, b, w))
    R["6"] = (not bad, bad)
    print("6", R["6"], round(time.time() - t0), flush=True)
    # 7-9 (+ day)
    h = mv.doc["hands"]
    want = {"hour": F(-1, 12), "minute": F(-1), "seconds": F(-60), "day": F(-1, 24)}
    for key, cid in (("hour", "7"), ("minute", "8"), ("seconds", "9"), ("day", "P2.1")):
        if key not in h or h[key] is None:
            R[cid] = (False, "absent")
            continue
        got = sp.get(h[key]["mobile"])
        R[cid] = (got == want[key] and not conflict, str(got))
    # 10
    R["10"] = (np.hypot(*(np.array(mv.axis[h["hour"]["mobile"]]) - np.array(mv.axis[h["minute"]["mobile"]]))) <= 0.01, None)
    # 11 + day placement
    ftop = max(mv.parts[n].bounding_box()[5] for n in mv.fixed)
    out = {}
    for key, reach in (("hour", 5), ("minute", 5), ("seconds", 5), ("day", 3)):
        e = h[key]
        man = mv.parts[e["part"]]
        c = np.array(mv.axis[e["mobile"]])
        v = kernel.verts(man)
        rmax = np.hypot(v[:, 0] - c[0], v[:, 1] - c[1]).max()
        low = man.bounding_box()[2]
        # centroid of volume
        mesh = man.to_mesh()
        vp = np.asarray(mesh.vert_properties)[:, :3]
        tt = vp[np.asarray(mesh.tri_verts)]
        vol6 = np.einsum("ij,ij->i", tt[:, 0], np.cross(tt[:, 1], tt[:, 2]))
        cen = (vol6[:, None] * tt.sum(1)).sum(0) / (4 * vol6.sum())
        cd = np.hypot(cen[0] - c[0], cen[1] - c[1])
        out[key] = (rmax >= reach and low >= ftop - 1e-9 and cd >= 0.5, round(rmax, 3), round(low, 3), round(cd, 3))
    R["11"] = (all(out[k][0] for k in ("hour", "minute", "seconds")), out, "frame top", ftop)
    dax = np.hypot(*(np.array(mv.axis[h["day"]["mobile"]]) - np.array(mv.axis[h["hour"]["mobile"]])))
    R["P2.2"] = (out["day"][0] and dax >= 6, round(dax, 3))
    # 12
    cc = np.array(mv.doc["case_centre"])
    worst = 0
    for n in mv.fixed:
        v = kernel.verts(mv.parts[n])
        worst = max(worst, np.hypot(v[:, 0] - cc[0], v[:, 1] - cc[1]).max())
    for k in names:
        v = kernel.verts(mv.mob[k])
        c = np.array(mv.axis[k])
        worst = max(worst, np.hypot(v[:, 0] - c[0], v[:, 1] - c[1]).max() + np.hypot(*(c - cc)))
    allm = U([mv.frame] + list(mv.mob.values()))
    bb = allm.bounding_box()
    R["12"] = (worst <= R_CASE and bb[5] - bb[2] <= H_CASE, round(worst, 3), round(bb[5] - bb[2], 3))
    # 14
    Y = lewis()
    path = rated_path(mv, passing, h["seconds"]["mobile"])
    bad = []
    info = []
    if path is None:
        bad.append("seconds not reached")
    else:
        for i in path:
            e = mv.meshes[i]
            ok, det = res[(i, 0.0)]
            Dn, Nn = e["driver"], e["driven"]
            TD = T_BARREL * abs(sp["barrel"] / sp[Dn])
            m = det["m"]
            Fz = float(TD) / (m * e["driver_teeth"] / 2)
            b = det["b"]
            for g, z in ((Dn, e["driver_teeth"]), (Nn, e["driven_teeth"])):
                if g == "barrel":
                    continue
                sig = Fz / (b * m * Y[z])
                al = ALLOW[mv.doc["mobiles"][g]["material"]]
                info.append((Dn, Nn, g, z, round(sig, 1), al))
                if sig > al:
                    bad.append((g, sig))
    R["14"] = (not bad, info, bad)
    for k in sorted(R):
        print(k, R[k])
    print("elapsed", round(time.time() - t0))
    return R


def rated_path(mv, passing, target):
    adj = {}
    for i, e in enumerate(mv.meshes):
        if passing.get(i):
            adj.setdefault(e["driver"], []).append((e["driven"], i))
            adj.setdefault(e["driven"], []).append((e["driver"], i))
    prev = {"barrel": None}
    q = ["barrel"]
    while q:
        x = q.pop(0)
        for y, i in adj.get(x, []):
            if y not in prev:
                prev[y] = (x, i)
                q.append(y)
    if target not in prev:
        return None
    path = []
    x = target
    while prev[x] is not None:
        x, i = prev[x]
        path.append(i)
    return path[::-1]


def printability(fname):
    from printcheck import printable
    doc = json.load(open(os.path.join(DELIV, fname)))
    names = list(doc["fixed"]) + [p for m in doc["mobiles"].values() for p in m["parts"]]
    for n in names:
        t = time.time()
        print("13", n, printable(load(n)), round(time.time() - t, 1), flush=True)


if __name__ == "__main__":
    fname = sys.argv[1] if len(sys.argv) > 1 else "movement.json"
    cls = sys.argv[2] if len(sys.argv) > 2 else "D"
    what = sys.argv[3] if len(sys.argv) > 3 else "part1"
    if what == "part1":
        part1(fname, cls)
    elif what == "print":
        printability(fname)
