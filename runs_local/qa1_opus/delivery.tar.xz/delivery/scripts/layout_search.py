"""Random search of axis positions under the clearance rules (2D), minimising the case radius needed."""
import math, numpy as np
rng = np.random.default_rng(1)
def P(r, a): return np.array([r*math.cos(a), r*math.sin(a)])
d = lambda p, q: float(np.hypot(*(p-q)))
HAND = dict(hour=5.6, minute=7.0, sec=5.6, day=3.6)
def evaluate(ang):
    a,b,c,dd,e,f = ang
    A = P(10.8,a); M = A+P(8.4,b); B = M+P(7.2,c); S = B+P(6.8,dd); C = M+P(4.0,e); D = C+P(7.2,f)
    O = np.zeros(2)
    pen = 0.0
    def need(x, lim):
        nonlocal pen
        if x < lim: pen += (lim-x)
    # outside barrel drum
    for X, r in ((M,0.7),(B,0.45),(S,0.45)):
        need(d(X,O), 9.8+r+0.25)
    need(d(A,O), 10.79)
    # tier 1 gear coverage
    need(d(A,M), 6.6+0.6+0.25)       # M wheel vs A body
    need(d(S,M), 6.6+0.45+0.25)      # M wheel vs S
    need(d(A,B), 6.2+0.6+0.25)       # B wheel vs A
    need(d(B,A), 4.6+0.45+0.25)      # A wheel vs B
    need(d(S,A), 4.6+0.45+0.25)      # A wheel vs S
    need(d(S,M), 5.2+0.45+0.25)      # M pinion (6h) vs S
    need(d(B,M), 6.2+0.7+0.1)
    # tier 2
    need(d(C,S), 3.2+0.3+0.25); need(d(M,S), 3.4+0.3+0.25)
    need(d(D,S), 6.6+0.3+0.25); need(d(D,M), 6.6+3.4+0.3)
    # hands
    need(d(S,M), HAND['sec']+0.75+0.3); need(d(D,S), HAND['day']+0.3+0.3)
    need(d(D,M), 6.0)
    pts = dict(O=(O,9.8),A=(A,4.6),M=(M,max(6.6,HAND['minute'])),B=(B,6.2),S=(S,HAND['sec']),C=(C,3.4),D=(D,6.6))
    # best case centre: minimise max(|X-c|+r) via a few iterations of sub-gradient
    cc = np.mean([p for p,_ in pts.values()],0)
    for it in range(120):
        vals = [(d(p,cc)+r, p) for p,r in pts.values()]
        v,p = max(vals, key=lambda t:t[0])
        g = (cc-p)/max(d(p,cc),1e-9)
        cc = cc - 0.05*g*(1-it/120)
    R = max(d(p,cc)+r for p,r in pts.values())
    return pen, R, dict(A=A,M=M,B=B,S=S,C=C,D=D,cc=cc)
best=None
for k in range(15000):
    ang = rng.uniform(0,2*math.pi,6)
    pen,R,pos = evaluate(ang)
    score = pen*100 + R
    if best is None or score < best[0]:
        best=(score,pen,R,ang,pos)
print(best)
# local refine
score,pen,R,ang,pos = best
for k in range(6000):
    a2 = ang + rng.normal(0,0.03,6)
    p2,R2,pos2 = evaluate(a2)
    s2 = p2*100+R2
    if s2 < score: score,pen,R,ang,pos = s2,p2,R2,a2,pos2
print(score,pen,R,list(ang)); print({k:list(np.round(v,3)) for k,v in pos.items()})
