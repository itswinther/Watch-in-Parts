"""Assembly plan of movement.json: every part lowered straight down along -z onto its place.
python3 assembly.py [--check]"""
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import inspect_qa as Q  # noqa: E402
import kernel  # noqa: E402

ORDER = ["plate", "barrel", "A_8h", "M_8h", "B", "S", "train_bridge", "cannon", "C", "H", "Dy",
         "dial_bridge", "hand_day", "hand_seconds", "hand_hour", "hand_minute"]
STEP = 0.19


def main(check):
    mv = Q.Mv("movement.json", "D")
    allnames = list(mv.fixed) + [p for k, ps in mv.mparts.items() if k != "barrel" for p in ps] + ["barrel"]
    assert sorted(allnames) == sorted(ORDER), (sorted(allnames), sorted(ORDER))
    whole = Q.U([mv.parts[n] for n in allnames]).bounding_box()
    top = whole[5] + 5.0
    paths = {}
    for n in ORDER:
        bb = mv.parts[n].bounding_box()
        lift = top - bb[2] + 0.2
        k = int(math.ceil(lift / STEP))
        zs = [lift * (1 - i / k) for i in range(k + 1)]
        paths[n] = [[[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, round(z, 6)], [0, 0, 0, 1]] for z in zs]
        paths[n][-1] = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
    with open(os.path.join(DELIV, "assembly.json"), "w") as f:
        json.dump({"order": ORDER, "paths": paths}, f)
    if not check:
        return
    placed = []
    for n in ORDER:
        P = np.array(paths[n], float)
        bb = mv.parts[n].bounding_box()
        g = [whole[i] - 5 for i in range(3)] + [whole[i] + 5 for i in range(3, 6)]
        b0 = [bb[i] + P[0][i % 3, 3] for i in range(6)]
        outside = any(b0[i] >= g[i + 3] or b0[i + 3] <= g[i] for i in range(3))
        worst = 0.0
        for T in P:
            moved = Q.tr(mv.parts[n], T[:3, 3])
            for q in placed:
                worst = max(worst, kernel.ivol(moved, mv.parts[q]))
        dz = np.abs(np.diff(P[:, 2, 3])).max()
        ok = outside and worst <= 0.01 and dz <= 0.2 and 2 <= len(P) <= 1500
        print("%-14s poses %4d outside %s maxstep %.3f worst %.5f %s" % (n, len(P), outside, dz, worst, "OK" if ok else "FAIL"),
              flush=True)
        placed.append(n)


if __name__ == "__main__":
    main("--check" in sys.argv)
