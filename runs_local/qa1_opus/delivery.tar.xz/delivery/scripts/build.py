"""Builds every part (STEP) and movement.json / variant_6h.json of the demonstration calibre.
Run: python3 build.py   (writes into ../parts and ..)"""
import json
import math
import os
import sys

import numpy as np
import cadquery as cq

HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(DELIV), "tools"))
import kernel                                   # noqa: E402
from gears import gear_outline, outline_points  # noqa: E402

PI = math.pi


def P(r, a):
    return np.array([r * math.cos(a), r * math.sin(a)])


# ---------------- layout (axes) ----------------
ANG = [4.608798692913857, 0.2416589685787022, 0.8836873484506066, 1.814873241622272,
       2.3652303921903175, 3.107984409264298]
O = np.zeros(2)
A = P(10.8, ANG[0])            # barrel 96 / A pinion 12, m 0.2
M = A + P(8.4, ANG[1])         # A wheel / M pinion, m 0.4, 42 teeth together
B = M + P(7.2, ANG[2])         # M wheel 64 / B pinion 8, m 0.2
S = B + P(6.8, ANG[3])         # B wheel 60 / S pinion 8, m 0.2
C = M + P(4.0, ANG[4])         # cannon 10 / C wheel 30 ; C pinion 8 / H wheel 32, m 0.2
D = C + P(7.2, ANG[5])         # C pinion 8 / day wheel 64, m 0.2
CC = np.array([3.6, -2.4])     # case centre
R_PLATE = 16.0

# ---------------- z levels ----------------
Z_PLATE = (-1.3, -0.1)
L0 = (0.0, 1.0)
L1 = (1.3, 2.0)
L2 = (2.3, 3.0)
L3 = (3.3, 4.0)
Z_TB = (4.95, 5.7)
L4 = (6.0, 6.6)
L5 = (6.9, 7.5)
Z_DB = (7.6, 8.2)
Z_HDAY = (8.45, 8.8)
Z_HSEC = (9.05, 9.4)
Z_HHOUR = (9.65, 10.0)
Z_HMIN = (10.25, 10.6)

PIV = 0.3          # pivot radius
HOLE = 0.33        # pivot hole radius
PIN = 0.2          # hand pin radius
FIT = 0.003        # hand bore over pin

# ---------------- CAD helpers ----------------
_outline_cache = {}


def outline(z, m, thin):
    k = (z, m, thin)
    if k not in _outline_cache:
        _outline_cache[k] = outline_points(gear_outline(z, m, thin))
    return _outline_cache[k]


def cyl(c, r, z0, z1):
    return cq.Workplane("XY").workplane(offset=z0).center(float(c[0]), float(c[1])).circle(r).extrude(z1 - z0)


def prism(pts, z0, z1):
    pts = [(float(x), float(y)) for x, y in pts]
    return cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1 - z0)


def gear(c, z, m, thin, phase, lv):
    pts = outline(z, m, thin)
    cs, sn = math.cos(phase), math.sin(phase)
    q = np.stack([cs * pts[:, 0] - sn * pts[:, 1] + c[0], sn * pts[:, 0] + cs * pts[:, 1] + c[1]], 1)
    return prism(q, lv[0], lv[1])


def fuse(items):
    s = items[0]
    for it in items[1:]:
        s = s.union(it)
    return s.clean()


def hand(c, angle, z, length, hub, bore, w0, w1, tail=0.0):
    """A hand: round hub with a bore, and a tapered blade towards `angle`."""
    u = np.array([math.cos(angle), math.sin(angle)])
    v = np.array([-u[1], u[0]])
    p0 = c - u * tail
    pts = [p0 + v * w0 / 2, c + u * length - v * w1 / 2 + v * 0, c + u * length + v * w1 / 2]
    pts = [p0 - v * w0 / 2, c + u * length - v * w1 / 2, c + u * length + v * w1 / 2, p0 + v * w0 / 2]
    blade = prism(pts, z[0], z[1])
    h = cyl(c, hub, z[0], z[1]).union(blade)
    return h.cut(cyl(c, bore, z[0] - 0.1, z[1] + 0.1)).clean()


# ---------------- gear phases ----------------
def phase_after(dpos, dphase, dz, npos, nz):
    beta = math.atan2(npos[1] - dpos[1], npos[0] - dpos[0])
    pd = 2 * PI / dz
    delta = (beta - dphase) % pd
    return beta + PI + PI / nz + delta * dz / nz


THIN02 = 0.02      # tooth thinning (arc on pitch circle) for module 0.2 gears
THIN_A0 = 0.03     # A pinion against the barrel
THIN04 = 0.03      # module 0.4


def build(variant):
    """variant 8 or 6. Returns dict name -> cq solid, and the movement document."""
    za_w, zm_p = (21, 21) if variant == 8 else (18, 24)
    sfx = "8h" if variant == 8 else "6h"
    parts = {}
    # phases
    ph_barrel = 0.0
    ph_Ap = phase_after(O, ph_barrel, 96, A, 12)
    ph_Aw = 0.0
    ph_Mp = phase_after(A, ph_Aw, za_w, M, zm_p)
    ph_Mw = 0.0
    ph_Bp = phase_after(M, ph_Mw, 64, B, 8)
    ph_Bw = 0.0
    ph_Sp = phase_after(B, ph_Bw, 60, S, 8)
    ph_can = 0.0
    ph_Cw = phase_after(M, ph_can, 10, C, 30)
    ph_Cp = 0.0
    ph_Hw = phase_after(C, ph_Cp, 8, M, 32)
    ph_Dw = phase_after(C, ph_Cp, 8, D, 64)

    def tier1_arbor(c, rb, top_extra=None):
        items = [cyl(c, PIV, -0.8, -0.05), cyl(c, rb, -0.05, 4.9)]
        if top_extra is None:
            items.append(cyl(c, PIV, 4.9, 5.55))
        return items

    # A
    items = tier1_arbor(A, 0.6)
    items += [gear(A, 12, 0.2, THIN_A0, ph_Ap, L0), gear(A, za_w, 0.4, THIN04, ph_Aw, L1)]
    parts["A_" + sfx] = fuse(items)
    # M (centre / minute)
    items = [cyl(M, PIV, -0.8, -0.05), cyl(M, 0.7, -0.05, 4.9), cyl(M, 0.5, 4.9, 6.0),
             cyl(M, 0.3, 6.0, Z_HMIN[0]), cyl(M, PIN, Z_HMIN[0], Z_HMIN[1]),
             gear(M, zm_p, 0.4, THIN04, ph_Mp, L1), gear(M, 64, 0.2, THIN02, ph_Mw, L2)]
    parts["M_" + sfx] = fuse(items)
    if variant == 8:
        # B
        items = tier1_arbor(B, 0.45) + [gear(B, 8, 0.2, THIN02, ph_Bp, L2), gear(B, 60, 0.2, THIN02, ph_Bw, L3)]
        parts["B"] = fuse(items)
        # S (seconds)
        items = [cyl(S, PIV, -0.8, -0.05), cyl(S, 0.45, -0.05, 4.9), cyl(S, 0.3, 4.9, Z_HSEC[0]),
                 cyl(S, PIN, Z_HSEC[0], Z_HSEC[1]), gear(S, 8, 0.2, THIN02, ph_Sp, L3)]
        parts["S"] = fuse(items)
        # cannon pinion (part of M)
        parts["cannon"] = fuse([gear(M, 10, 0.2, THIN02, ph_can, L4)]).cut(cyl(M, 0.3 + FIT, L4[0] - 0.1, L4[1] + 0.1)).clean()
        # C (minute wheel)
        items = [cyl(C, PIV, 5.35, 5.75), cyl(C, 0.45, 5.75, 7.55), cyl(C, PIV, 7.55, 8.0),
                 gear(C, 30, 0.2, THIN02, ph_Cw, L4), gear(C, 8, 0.2, THIN02, ph_Cp, L5)]
        parts["C"] = fuse(items)
        # H (hour wheel)
        h = fuse([cyl(M, 0.75, 6.65, Z_HHOUR[0]), cyl(M, 0.6, Z_HHOUR[0], Z_HHOUR[1]),
                  gear(M, 32, 0.2, THIN02, ph_Hw, L5)])
        parts["H"] = h.cut(cyl(M, 0.33, 6.5, 10.2)).clean()
        # Dy (24-hour)
        items = [cyl(D, PIV, 5.35, 5.75), cyl(D, 0.45, 5.75, 7.55), cyl(D, 0.3, 7.55, Z_HDAY[0]),
                 cyl(D, PIN, Z_HDAY[0], Z_HDAY[1]), gear(D, 64, 0.2, THIN02, ph_Dw, L5)]
        parts["Dy"] = fuse(items)
        # hands
        parts["hand_hour"] = hand(M, math.radians(120), Z_HHOUR, 5.6, 1.0, 0.6 + FIT, 0.9, 0.45)
        parts["hand_minute"] = hand(M, math.radians(60), Z_HMIN, 7.0, 0.6, PIN + FIT, 0.7, 0.35)
        parts["hand_seconds"] = hand(S, math.radians(200), Z_HSEC, 5.6, 0.6, PIN + FIT, 0.6, 0.3)
        parts["hand_day"] = hand(D, math.radians(250), Z_HDAY, 3.6, 0.6, PIN + FIT, 0.7, 0.35)
        # frame
        parts.update(frame())
    doc = movement_doc(variant, za_w, zm_p, sfx)
    return parts, doc


def pillar_sites(tier):
    """Pillar positions: free of every gear and arbor of the tier, inside the plate."""
    if tier == 1:
        obst = [(O, 9.8), (A, 4.6), (M, 6.6), (B, 6.2), (S, 1.0)]
    else:
        obst = [(M, 3.4), (C, 3.2), (D, 6.6), (S, 0.3)]
    best = []
    cand = []
    for r in np.linspace(9, R_PLATE - 1.4, 30):
        for a in np.linspace(0, 2 * PI, 180, endpoint=False):
            p = CC + P(r, a)
            gap = min(float(np.hypot(*(p - c))) - rr for c, rr in obst)
            if gap >= 0.8 + 0.6:
                cand.append((p, gap))
    # pick 3 well spread
    import itertools
    cand = cand[::7]
    bestv = -1
    for tri in itertools.combinations(range(len(cand)), 3):
        ps = [cand[i][0] for i in tri]
        v = min(np.hypot(*(ps[i] - ps[j])) for i in range(3) for j in range(i + 1, 3))
        if v > bestv:
            bestv, best = v, ps
    return best


def frame():
    out = {}
    # plate + tier-1 pillars
    pl = cyl(CC, R_PLATE, *Z_PLATE)
    for p in pillar_sites(1):
        pl = pl.union(cyl(p, 0.8, Z_PLATE[1] - 0.05, Z_TB[0]))
    pl = pl.cut(cyl(O, 0.53, -1.05, 0.5))
    for c in (A, M, B, S):
        pl = pl.cut(cyl(c, HOLE, -0.85, 0.5))
    out["plate"] = pl.clean()
    # train bridge
    tb = cyl(CC, R_PLATE, *Z_TB)
    tb = tb.cut(cyl(O, 0.53, 4.0, 6.0)).cut(cyl(M, 0.53, 4.0, 6.0))
    for c in (A, B, S):
        tb = tb.cut(cyl(c, HOLE, 4.0, 6.0))
    for c in (C, D):
        tb = tb.cut(cyl(c, HOLE, 5.3, 6.0))
    out["train_bridge"] = tb.clean()
    # dial-side bridge with hanging pillars
    db = cyl(CC, R_PLATE, *Z_DB)
    for p in pillar_sites(2):
        db = db.union(cyl(p, 0.8, Z_TB[1], Z_DB[0] + 0.05))
    db = db.cut(cyl(M, 0.78, 7.0, 9.0))
    for c in (S, C, D):
        db = db.cut(cyl(c, HOLE, 7.0, 9.0))
    out["dial_bridge"] = db.clean()
    return out


def movement_doc(variant, za_w, zm_p, sfx):
    mat = "AD-C100-HT"
    xy = lambda p: [round(float(p[0]), 9), round(float(p[1]), 9)]
    return {
        "case_centre": xy(CC),
        "fixed": ["plate", "train_bridge", "dial_bridge"],
        "mobiles": {
            "A": {"axis": xy(A), "parts": ["A_" + sfx], "material": mat},
            "M": {"axis": xy(M), "parts": ["M_" + sfx, "cannon", "hand_minute"], "material": mat},
            "B": {"axis": xy(B), "parts": ["B"], "material": mat},
            "S": {"axis": xy(S), "parts": ["S", "hand_seconds"], "material": mat},
            "C": {"axis": xy(C), "parts": ["C"], "material": mat},
            "H": {"axis": xy(M), "parts": ["H", "hand_hour"], "material": mat},
            "Dy": {"axis": xy(D), "parts": ["Dy", "hand_day"], "material": mat},
        },
        "meshes": [
            {"driver": "barrel", "driver_teeth": 96, "driven": "A", "driven_teeth": 12},
            {"driver": "A", "driver_teeth": za_w, "driven": "M", "driven_teeth": zm_p},
            {"driver": "M", "driver_teeth": 64, "driven": "B", "driven_teeth": 8},
            {"driver": "B", "driver_teeth": 60, "driven": "S", "driven_teeth": 8},
            {"driver": "M", "driver_teeth": 10, "driven": "C", "driven_teeth": 30},
            {"driver": "C", "driver_teeth": 8, "driven": "H", "driven_teeth": 32},
            {"driver": "C", "driver_teeth": 8, "driven": "Dy", "driven_teeth": 64},
        ],
        "hands": {
            "hour": {"mobile": "H", "part": "hand_hour"},
            "minute": {"mobile": "M", "part": "hand_minute"},
            "seconds": {"mobile": "S", "part": "hand_seconds"},
            "day": {"mobile": "Dy", "part": "hand_day"},
        },
    }


if __name__ == "__main__":
    os.makedirs(os.path.join(DELIV, "parts"), exist_ok=True)
    only = set(sys.argv[1:])
    for variant, fname in ((8, "movement.json"), (6, "variant_6h.json")):
        parts, doc = build(variant)
        for name, solid in parts.items():
            if only and name not in only:
                continue
            path = os.path.join(DELIV, "parts", name + ".step")
            kernel.write_step(path, solid)
            print("wrote", name, flush=True)
        with open(os.path.join(DELIV, fname), "w") as f:
            json.dump(doc, f, indent=1)
