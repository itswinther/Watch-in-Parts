"""Rack-generated involute spur gear outlines (2D), 25 degree basic rack, addendum 1 m, dedendum 1.25 m,
full-round rack tip (DS-W04 tooth form). Backlash by a negative profile shift."""
import math
import numpy as np
import manifold3d as m3

ALPHA = math.radians(25.0)


def rack_tooth(m, top):
    """Cutter tooth (cuts one tooth space), rack coords (u along pitch line, v outward), centred u=0."""
    ta = math.tan(ALPHA)
    vtip = -1.25 * m
    w_tip = math.pi * m / 4 + vtip * ta          # half width at the cutter tip line
    rho = w_tip * math.tan(math.pi / 4 + ALPHA / 2)
    vc = vtip + rho                               # centre of tip round
    # tangent points of the round with the flanks: flank normal direction (cos a, -sin a) on +u side
    tu, tv = rho * math.cos(ALPHA), vc - rho * math.sin(ALPHA)
    pts = []
    # right flank from top down to tangent point
    pts.append((math.pi * m / 4 + top * ta, top))
    pts.append((tu, tv))
    # arc from right tangent to left tangent through bottom
    a0 = -ALPHA
    a1 = -math.pi + ALPHA
    n = 24
    for i in range(1, n):
        a = a0 + (a1 - a0) * i / n
        pts.append((rho * math.cos(a), vc + rho * math.sin(a)))
    pts.append((-tu, tv))
    pts.append((-(math.pi * m / 4 + top * ta), top))
    return np.array(pts[::-1])


def gear_outline(z, m, thin=0.0, steps=None, simplify=0.001):
    """CrossSection of the gear, one tooth centred on +x. thin = reduction of the tooth thickness on the
    pitch circle (arc, mm) by negative profile shift."""
    r = m * z / 2.0
    xm = -thin / (2 * math.tan(ALPHA))            # profile shift (mm), negative
    rt = r + m                                    # tip radius kept nominal
    tooth = rack_tooth(m, 2.5 * m)
    umax = 7.0 * m + 0.5 * r * 0  # rack travel each side
    if steps is None:
        steps = 700
    polys = []
    for u in np.linspace(-umax, umax, steps):
        phi = u / r
        P = tooth.copy()
        X = P[:, 0] - u
        Y = P[:, 1] + r + xm
        c, s = math.cos(-phi), math.sin(-phi)
        polys.append(np.stack([c * X - s * Y, s * X + c * Y], 1))
    space = m3.CrossSection.batch_boolean([m3.CrossSection([p.tolist()]) for p in polys], m3.OpType.Add)
    blank = m3.CrossSection.circle(rt, 2048)
    spaces = []
    for k in range(z):
        spaces.append(space.rotate(360.0 * k / z))
    g = blank - m3.CrossSection.batch_boolean(spaces, m3.OpType.Add)
    # tooth centred on +x: spaces centred on +y (90 deg) -> teeth at 90 + 180/z
    g = g.rotate(-(90.0 + 180.0 / z))
    if simplify:
        g = g.simplify(simplify)
    return g


def outline_points(cs):
    P = cs.to_polygons()
    assert len(P) == 1, len(P)
    return np.asarray(P[0], float)
