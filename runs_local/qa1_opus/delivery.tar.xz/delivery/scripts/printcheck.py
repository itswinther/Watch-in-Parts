"""Printability test of DS-W03 section 3 on a manifold."""
import math, sys
sys.path.insert(0, '/tmp/claude-0/runs/qa1_opus/app/tools')
import numpy as np, kernel

H = 0.05
OFF = 0.0113


def printable(man):
    bb = man.bounding_box()
    lo = np.array(bb[:3]); hi = np.array(bb[3:])
    k0 = np.floor((lo - OFF) / H) - 3
    origin = k0 * H + OFF - H / 2           # voxel i centre = origin + (i+0.5)H = (k0+i)H + OFF
    shape = tuple(int(v) for v in np.ceil((hi - origin) / H).astype(int) + 3)
    n, dev = kernel.opening_test_slabs(man, origin, shape, H, 1.5, 1.0, 6.0)
    return n, dev, (n >= 1 and dev <= 4.0 + 1e-9)
