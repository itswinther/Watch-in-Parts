"""Builds every part (STEP), movement.json, variant_6h.json and assembly.json.
    python3 build.py
World frame: barrel axis at (0,0), dial side +z."""
import json, math, os, sys
import numpy as np
from gearlib import gear_outline, driven_phase, APP, kernel

OUT = os.path.join(APP, "delivery")
PARTS = os.path.join(OUT, "parts")

# ---------------- layout (plan) ----------------
O = (0.0, 0.0)
K = (11.0, 0.0)                       # centre: minute + hour
CC = (10.7, 0.0)                      # case centre
def circ2(p, rp, q, rq, side):
    d = math.hypot(q[0] - p[0], q[1] - p[1])
    a = (rp * rp - rq * rq + d * d) / (2 * d)
    h = math.sqrt(rp * rp - a * a)
    ux, uy = (q[0] - p[0]) / d, (q[1] - p[1]) / d
    return (p[0] + a * ux - side * h * uy, p[1] + a * uy + side * h * ux)
M1 = circ2(O, 10.8, K, 11.2, +1)      # barrel pinion + changer wheel
T = (K[0] + 10.8 * math.cos(math.radians(-30)), K[1] + 10.8 * math.sin(math.radians(-30)))   # third
F = (T[0] + 10.2 * math.cos(math.radians(85)), T[1] + 10.2 * math.sin(math.radians(85)))     # fourth: seconds
D = (K[0] + 9.2 * math.cos(math.radians(-120)), K[1] + 9.2 * math.sin(math.radians(-120)))   # 24-hour
W = circ2(K, 6.0, D, 8.4, +1)         # motion-work wheel
AX = dict(barrel=O, m1=M1, centre=K, third=T, fourth=F, day=D, mw=W, hour=K)

# ---------------- levels (z) ----------------
PL0, PL1 = -1.0, -0.15                # main plate
L = [(0.0, 1.0), (1.3, 2.1), (2.4, 3.2), (3.5, 4.3), (4.6, 5.4), (5.7, 6.5), (6.8, 7.6)]
TP0, TP1 = 7.9, 8.7                   # top plate
SH_B, SH_T = -0.05, 7.8               # arbor shoulders at the plates
HZ = dict(day=(8.85, 9.25), seconds=(9.45, 9.85), hour=(10.05, 10.45), minute=(10.65, 11.05))
R_ARB, R_PIV, R_BORE = 0.6, 0.4, 0.45
SEAT = 0.005                          # gap of pressed-on parts
R_PLATE = 20.6
R_PILLAR = 0.8
THIN = 0.03                           # tooth thinning (arc on the pitch circle) of each gear

def cyl(c, r, z0, z1):
    return ("cyl", float(c[0]), float(c[1]), float(r), float(z0), float(z1))

def gear(c, z, m, phase, lev):
    r = z * m / 2
    pts = gear_outline(z, m, math.pi * m / 2 - THIN, r + m, r - 1.25 * m, phase)
    pts = pts + np.array(c)[None, :]
    return ("poly", pts, float(L[lev][0]), float(L[lev][1]))

def hand_prims(c, r_hub, r_hole, reach, width, z0, z1, ang_deg=90.0):
    a = math.radians(ang_deg)
    u = np.array([math.cos(a), math.sin(a)]); n = np.array([-u[1], u[0]])
    c = np.array(c)
    s = r_hub * 0.6
    pts = np.array([c + s * u - width / 2 * n, c + reach * u - width / 2 * n,
                    c + reach * u + width / 2 * n, c + s * u + width / 2 * n])
    return dict(add=[cyl(c, r_hub, z0, z1), ("poly", pts, float(z0), float(z1))], sub=[cyl(c, r_hole, z0 - 1, z1 + 1)])

def pillar_spots():
    """Places on the rim, clear of everything that turns."""
    reach = [(O, 9.8), (M1, 6.9), (K, 9.8), (T, 9.2), (F, 1.5), (D, 7.4), (W, 5.0)]
    rr = R_PLATE - R_PILLAR - 0.1
    good = []
    for deg in range(0, 360):
        p = (CC[0] + rr * math.cos(math.radians(deg)), CC[1] + rr * math.sin(math.radians(deg)))
        clr = min(math.hypot(p[0] - c[0], p[1] - c[1]) - R - R_PILLAR for c, R in reach)
        good.append((deg, clr, p))
    # pick four spread spots: best clearance in each quadrant-ish window
    spots = []
    for lo in (20, 110, 200, 290):
        cand = [g for g in good if lo <= g[0] < lo + 90]
        b = max(cand, key=lambda g: g[1])
        assert b[1] > 0.25, ("no room for a pillar", lo, b)
        spots.append(b[2])
    return spots

def design(variant):
    """Returns (parts: name -> dict(add, sub)), movement dict."""
    zA, zB = (28, 28) if variant == "8h" else (24, 32)
    sfx = "" if variant == "8h" else "_6h"
    parts = {}
    # ---- gear phases, in train order ----
    ph_m1p = driven_phase(O, M1, 96, 12, 0.0, 0.0)
    ph_A = 0.0
    ph_B = driven_phase(M1, K, zA, zB, ph_A, 0.0)
    ph_C = 0.0
    ph_tp = driven_phase(K, T, 96, 12, ph_C, 0.0)
    ph_tw = 0.0
    ph_fp = driven_phase(T, F, 90, 12, ph_tw, 0.0)
    ph_cp = 0.0
    ph_w1 = driven_phase(K, W, 12, 48, ph_cp, 0.0)
    ph_w15 = 0.0
    ph_hw = driven_phase(W, K, 15, 45, ph_w15, 0.0)
    ph_w12 = 0.0
    ph_dw = driven_phase(W, D, 12, 72, ph_w12, 0.0)
    # ---- frame ----
    spots = pillar_spots()
    main = dict(add=[cyl(CC, R_PLATE, PL0, PL1)],
                sub=[cyl(O, 0.55, PL0 - 1, PL1 + 1)] + [cyl(c, R_BORE, PL0 - 1, PL1 + 1) for c in (M1, K, T, F)])
    top = dict(add=[cyl(CC, R_PLATE, TP0, TP1), cyl(O, 0.9, 1.15, TP0 + 0.1)] +
                   [cyl(p, R_PILLAR, PL1 + 0.004, TP0 + 0.1) for p in spots],
               sub=[cyl(O, 0.55, 0.5, 1.75), cyl(K, 0.95, TP0 - 1, TP1 + 1)] +
                   [cyl(c, R_BORE, TP0 - 1, TP1 + 1) for c in (M1, T, F, D, W)])
    parts["main_plate"] = main
    parts["top_plate"] = top
    # ---- mobiles ----
    def full_arbor(c, top_z):
        return [cyl(c, R_PIV, PL0 + 0.1, SH_B + 0.01), cyl(c, R_ARB, SH_B, SH_T), cyl(c, R_PIV, SH_T - 0.01, top_z)]
    parts["m1" + sfx] = dict(add=full_arbor(M1, TP1 - 0.1) + [gear(M1, 12, 0.2, ph_m1p, 0), gear(M1, zA, 0.4, ph_A, 1)], sub=[])
    parts["centre" + sfx] = dict(add=[cyl(K, R_PIV, PL0 + 0.1, SH_B + 0.01), cyl(K, R_ARB, SH_B, L[5][1]),
                                      cyl(K, 0.4, L[5][1] - 0.01, HZ["minute"][0]), cyl(K, 0.3, HZ["minute"][0] - 0.01, HZ["minute"][1] + 0.05),
                                      gear(K, zB, 0.4, ph_B, 1), gear(K, 96, 0.2, ph_C, 2), gear(K, 12, 0.2, ph_cp, 5)], sub=[])
    parts["third"] = dict(add=full_arbor(T, TP1 - 0.1) + [gear(T, 12, 0.2, ph_tp, 2), gear(T, 90, 0.2, ph_tw, 3)], sub=[])
    zs = HZ["seconds"]
    parts["fourth"] = dict(add=full_arbor(F, zs[0]) + [cyl(F, 0.3, zs[0] - 0.01, zs[1]), gear(F, 12, 0.2, ph_fp, 3)], sub=[])
    zd = HZ["day"]
    parts["day_wheel"] = dict(add=[cyl(D, R_ARB, L[4][0], SH_T), cyl(D, R_PIV, SH_T - 0.01, zd[0]), cyl(D, 0.3, zd[0] - 0.01, zd[1]),
                                   gear(D, 72, 0.2, ph_dw, 4)], sub=[])
    parts["mw_wheel"] = dict(add=[cyl(W, R_ARB, L[4][0], SH_T), cyl(W, R_PIV, SH_T - 0.01, zd[0]), cyl(W, 0.3, zd[0] - 0.01, zd[1]),
                                  gear(W, 12, 0.2, ph_w12, 4), gear(W, 48, 0.2, ph_w1, 5), gear(W, 15, 0.2, ph_w15, 6)], sub=[])
    parts["mw_collar"] = dict(add=[cyl(W, 0.9, zd[0] + SEAT, zd[1])], sub=[cyl(W, 0.3 + SEAT, zd[0] - 1, zd[1] + 1)])
    zh = HZ["hour"]
    parts["hour_wheel"] = dict(add=[cyl(K, 1.0, L[5][1] + 0.1, L[6][0] + 0.01), gear(K, 45, 0.2, ph_hw, 6), cyl(K, 1.3, L[6][1] - 0.01, SH_T),
                                    cyl(K, 0.9, SH_T - 0.01, zh[0]), cyl(K, 0.7, zh[0] - 0.01, zh[1])],
                               sub=[cyl(K, 0.45, 0, 20)])
    parts["hand_day"] = hand_prims(D, 0.8, 0.3 + SEAT, 3.6, 0.6, zd[0] + SEAT, zd[1])
    parts["hand_seconds"] = hand_prims(F, 0.9, 0.3 + SEAT, 5.4, 0.5, zs[0] + SEAT, zs[1])
    parts["hand_hour"] = hand_prims(K, 1.2, 0.7 + SEAT, 5.4, 0.7, zh[0] + SEAT, zh[1])
    zm = HZ["minute"]
    parts["hand_minute"] = hand_prims(K, 1.0, 0.3 + SEAT, 7.0, 0.6, zm[0] + SEAT, zm[1])
    mov = {
        "case_centre": list(CC),
        "fixed": ["main_plate", "top_plate"],
        "mobiles": {
            "m1": {"axis": list(M1), "parts": ["m1" + sfx]},
            "centre": {"axis": list(K), "parts": ["centre" + sfx, "hand_minute"]},
            "third": {"axis": list(T), "parts": ["third"]},
            "fourth": {"axis": list(F), "parts": ["fourth", "hand_seconds"]},
            "mw": {"axis": list(W), "parts": ["mw_wheel", "mw_collar"]},
            "hour": {"axis": list(K), "parts": ["hour_wheel", "hand_hour"]},
            "day": {"axis": list(D), "parts": ["day_wheel", "hand_day"]},
        },
        "meshes": [
            {"driver": "barrel", "driver_teeth": 96, "driven": "m1", "driven_teeth": 12},
            {"driver": "m1", "driver_teeth": zA, "driven": "centre", "driven_teeth": zB},
            {"driver": "centre", "driver_teeth": 96, "driven": "third", "driven_teeth": 12},
            {"driver": "third", "driver_teeth": 90, "driven": "fourth", "driven_teeth": 12},
            {"driver": "centre", "driver_teeth": 12, "driven": "mw", "driven_teeth": 48},
            {"driver": "mw", "driver_teeth": 15, "driven": "hour", "driven_teeth": 45},
            {"driver": "mw", "driver_teeth": 12, "driven": "day", "driven_teeth": 72},
        ],
        "hands": {
            "hour": {"mobile": "hour", "part": "hand_hour"},
            "minute": {"mobile": "centre", "part": "hand_minute"},
            "seconds": {"mobile": "fourth", "part": "hand_seconds"},
            "day": {"mobile": "day", "part": "hand_day"},
        },
    }
    return parts, mov

ORDER = ["main_plate", "barrel", "m1", "centre", "third", "fourth", "day_wheel", "mw_wheel", "hour_wheel",
         "top_plate", "hand_day", "mw_collar", "hand_seconds", "hand_hour", "hand_minute"]

def to_cq(part):
    import cadquery as cq
    def solid(p):
        if p[0] == "cyl":
            _, x, y, r, z0, z1 = p
            return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(r).extrude(z1 - z0)
        _, pts, z0, z1 = p
        return cq.Workplane("XY").workplane(offset=z0).polyline([tuple(q) for q in pts]).close().extrude(z1 - z0)
    body = None
    for p in part["add"]:
        s = solid(p)
        body = s if body is None else body.union(s)
    for p in part["sub"]:
        body = body.cut(solid(p))
    return body.clean()

def zrange(part):
    return min(p[-2] for p in part["add"]), max(p[-1] for p in part["add"])

def main():
    os.makedirs(PARTS, exist_ok=True)
    only = sys.argv[1:]
    p8, m8 = design("8h")
    p6, m6 = design("6h")
    allparts = dict(p6); allparts.update(p8)
    for name, part in allparts.items():
        if only and name not in only:
            continue
        kernel.write_step(os.path.join(PARTS, name + ".step"), to_cq(part))
        print("wrote", name, flush=True)
    json.dump(m8, open(os.path.join(OUT, "movement.json"), "w"), indent=1)
    json.dump(m6, open(os.path.join(OUT, "variant_6h.json"), "w"), indent=1)
    # ---- assembly: every part comes straight down the z axis (the main plate comes up from below)
    zlo = PL0
    zhi = max(zrange(p)[1] for p in p8.values())
    paths = {}
    step = 0.19
    for name in ORDER:
        if name == "barrel":
            z0, z1 = -1.0, 1.6
        else:
            z0, z1 = zrange(p8[name])
        if name == "main_plate":
            dist = (z1 - (zlo - 5.0)) + 0.2; sign = -1
        else:
            dist = (zhi + 5.0 - z0) + 0.2; sign = +1
        n = int(math.ceil(dist / step))
        P = []
        for k in range(n, -1, -1):
            Tm = np.eye(4); Tm[2, 3] = sign * dist * k / n
            P.append(Tm.tolist())
        paths[name] = P
    json.dump({"order": ORDER, "paths": paths}, open(os.path.join(OUT, "assembly.json"), "w"))
    print("done")

if __name__ == "__main__":
    main()
