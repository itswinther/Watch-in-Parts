"""A local copy of the acceptance test (instruction.md), for checking the delivery before hand-in.
    python3 grader.py movement.json|variant_6h.json [quick] [only=mesh,print,asm,...]"""
import json, math, os, sys, hashlib, itertools, time
from fractions import Fraction
from multiprocessing import Pool
import numpy as np
import manifold3d as m3
from gearlib import APP, kernel, rot_about, mesh_test

OUT = os.path.join(APP, "delivery")
CACHE = os.environ.get("PART_CACHE", "/tmp/claude-0/-tmp-claude-0-runs-smoke1-fable-app/84db1fc9-c179-44df-8c22-168c06b406bb/scratchpad/cache")
os.makedirs(CACHE, exist_ok=True)
TOL = 0.01

def load(name):
    if name == "barrel":
        return kernel.tris_to_part(kernel.read_stl(APP + "/supplied/barrel.stl", 10**7, 10**9), 0.005)
    p = os.path.join(OUT, "parts", name + ".step")
    st = os.stat(p)
    key = hashlib.md5(("%s-%d-%d" % (name, st.st_size, st.st_mtime_ns)).encode()).hexdigest()
    c = os.path.join(CACHE, key + ".npy")
    if os.path.exists(c):
        tris = np.load(c)
    else:
        tris = kernel.read_step(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096)
        np.save(c, tris)
    return kernel.tris_to_part(tris, 0.005)

G = {}
def setup(movfile):
    mov = json.load(open(os.path.join(OUT, movfile)))
    G["mov"] = mov
    G["parts"] = {}
    for n in mov["fixed"]:
        G["parts"][n] = load(n)
    G["mob"] = {"barrel": load("barrel")}
    G["axis"] = {"barrel": (0.0, 0.0)}
    for k, m in mov["mobiles"].items():
        for n in m["parts"]:
            G["parts"][n] = load(n)
        G["mob"][k] = kernel.union([G["parts"][n] for n in m["parts"]])
        G["axis"][k] = tuple(m["axis"])
    G["frame"] = kernel.union([G["parts"][n] for n in mov["fixed"]])
    return mov

def speeds(mov, period_h):
    sp = {"barrel": Fraction(-1, period_h)}        # turns per hour, clockwise negative
    ok = True
    ch = True
    while ch:
        ch = False
        for e in mov["meshes"]:
            for a, b, za, zb in ((e["driver"], e["driven"], e["driver_teeth"], e["driven_teeth"]),
                                 (e["driven"], e["driver"], e["driven_teeth"], e["driver_teeth"])):
                if a in sp:
                    v = -sp[a] * Fraction(za, zb)
                    if b not in sp:
                        sp[b] = v; ch = True
                    elif sp[b] != v:
                        ok = False
    return sp, ok

def t_mesh(args):
    i, sh, quick = args
    e = G["mov"]["meshes"][i]
    ok, w = mesh_test(G["mob"][e["driver"]], G["mob"][e["driven"]], G["axis"][e["driver"]], G["axis"][e["driven"]],
                      e["driver_teeth"], e["driven_teeth"], sh, quick)
    return ("mesh %s>%s shift %+.2f" % (e["driver"], e["driven"], sh), ok,
            "jam %.5f gap %.4f area %.4f/%.4f vol %.4f" % (w["jam"], w["gap"], w["area"], w["need_area"], w["vol"]))

def t_free(k):
    worst = 0.0
    for s in range(72):
        worst = max(worst, kernel.ivol(rot_about(G["mob"][k], G["axis"][k], 5.0 * s), G["frame"]))
    return ("free %s" % k, worst <= TOL, "%.5f" % worst)

def t_pair(args):
    a, b, sa, sb = args
    A, B = G["mob"][a], G["mob"][b]
    fa, fb = float(sa), float(sb)
    worst = 0.0
    fast = max(abs(fa), abs(fb))
    seqs = []
    if fast > 0:
        seqs.append([(360.0 * fa / fast * s / 144, 360.0 * fb / fast * s / 144) for s in range(144)])
        if fa != fb:
            rel = abs(fa - fb)
            seqs.append([(360.0 * fa / rel * s / 144, 360.0 * fb / rel * s / 144) for s in range(144)])
    else:
        seqs.append([(0, 0)])
    for seq in seqs:
        for ra, rb in seq:
            worst = max(worst, kernel.ivol(rot_about(A, G["axis"][a], ra), rot_about(B, G["axis"][b], rb)))
    return ("pair %s/%s" % (a, b), worst <= TOL, "%.5f" % worst)

def t_print(n):
    man = G["parts"][n]
    h = 0.05
    bb = man.bounding_box()
    lo = np.array(bb[:3]); hi = np.array(bb[3:])
    k0 = np.floor((lo - 0.0113) / h) - 2
    origin = k0 * h + 0.0113 - h / 2
    shape = tuple(int(v) for v in (np.ceil((hi - origin) / h) + 2))
    npieces, dev = kernel.opening_test_slabs(man, origin, shape, h, 1.5, 1.0, 6.0)
    return ("print %s" % n, npieces >= 1 and dev <= 4.0 + 1e-9, "pieces %d dev %.2f vox" % (npieces, dev))

def t_asm(name):
    asm = G["asm"]; order = G["order"]
    P = asm["paths"].get(name)
    sol = G["asmparts"][name]
    idx = order.index(name)
    before = order[:idx] + G["notinorder"]
    if not isinstance(P, list) or not (2 <= len(P) <= 1500):
        return ("asm " + name, False, "pose count")
    Ps = np.array(P, float)
    if Ps.shape[1:] != (4, 4) or not np.isfinite(Ps).all():
        return ("asm " + name, False, "matrix")
    for Tm in Ps:
        R = Tm[:3, :3]
        if abs(R.T @ R - np.eye(3)).max() > 1e-6 or abs(np.linalg.det(R) - 1) > 1e-6 or abs(Tm[3] - [0, 0, 0, 1]).max() > 1e-6:
            return ("asm " + name, False, "not rigid")
    if abs(Ps[-1] - np.eye(4)).max() > 1e-6:
        return ("asm " + name, False, "last pose")
    V = kernel.verts(sol)
    Vh = np.c_[V, np.ones(len(V))]
    prev = None
    for Tm in Ps:
        cur = (Vh @ Tm.T)[:, :3]
        if prev is not None and np.linalg.norm(cur - prev, axis=1).max() > 0.2:
            return ("asm " + name, False, "step too long")
        prev = cur
    first = (Vh @ Ps[0].T)[:, :3]
    lo, hi = G["bbox"]
    blo, bhi = first.min(0), first.max(0)
    outside = any(bhi[i] < lo[i] - 5 or blo[i] > hi[i] + 5 for i in range(3))
    if not outside:
        return ("asm " + name, False, "first pose not outside")
    worst = 0.0
    for Tm in Ps:
        cur = kernel.apply(sol, Tm)
        for o in before:
            worst = max(worst, kernel.ivol(cur, G["asmparts"][o]))
    return ("asm " + name, worst <= TOL, "%.5f over %d poses" % (worst, len(Ps)))

def run(fn, args, pool):
    res = pool.map(fn, args, chunksize=1) if pool else [fn(a) for a in args]
    bad = 0
    for name, ok, info in res:
        print(("  ok   " if ok else "  FAIL ") + name + "  " + info, flush=True)
        bad += 0 if ok else 1
    return bad

def main():
    movfile = sys.argv[1]
    quick = None
    only = None
    for a in sys.argv[2:]:
        if a.startswith("quick"):
            quick = int(a[5:] or 64)
        if a.startswith("only="):
            only = a[5:].split(",")
    period = 8 if movfile == "movement.json" else 6
    mov = setup(movfile)
    want = lambda k: only is None or k in only
    bad = 0
    def chk(name, ok, info=""):
        nonlocal bad
        print(("  ok   " if ok else "  FAIL ") + name + "  " + str(info), flush=True)
        bad += 0 if ok else 1
    parts, mob, axis, frame = G["parts"], G["mob"], G["axis"], G["frame"]
    mnames = list(mob)
    if want("static"):
        # C2
        w = max(kernel.ivol(frame, mob[k]) for k in mnames)
        chk("C2 frame/mobile", w <= TOL, w)
        w = max(kernel.ivol(mob[a], mob[b]) for a, b in itertools.combinations(mnames, 2))
        chk("C2 mobile/mobile", w <= TOL, w)
        fx = mov["fixed"]
        w = max([kernel.ivol(parts[a], parts[b]) for a, b in itertools.combinations(fx, 2)] + [0])
        chk("C2 fixed/fixed", w <= TOL, w)
        w = 0
        for k, m in mov["mobiles"].items():
            for a, b in itertools.combinations(m["parts"], 2):
                w = max(w, kernel.ivol(parts[a], parts[b]))
        chk("C2 within mobile", w <= TOL, w)
        comp = {fx[0]}
        ch = True
        while ch:
            ch = False
            for a in fx:
                if a not in comp and any(kernel.min_distance(parts[a], parts[b], 1.0) <= 0.01 for b in comp):
                    comp.add(a); ch = True
        chk("C2 one frame", len(comp) == len(fx), [kernel.min_distance(parts[a], parts[b], 1.0) for a, b in itertools.combinations(fx, 2)])
        # held
        dirs = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
        held = {(k, d): kernel.ivol(mob[k].translate([0.3 * c for c in d]), frame) > TOL for k in mnames for d in dirs}
        info = {(k, d): kernel.ivol(mob[k].translate([0.3 * c for c in d]), frame) for k in mnames for d in dirs}
        ch = True
        while ch:
            ch = False
            for k in mnames:
                for d in dirs:
                    if held[(k, d)]:
                        continue
                    for o in mnames:
                        if o != k and math.hypot(axis[o][0] - axis[k][0], axis[o][1] - axis[k][1]) <= 0.01 and held[(o, d)]:
                            v = kernel.ivol(mob[k].translate([0.3 * c for c in d]), mob[o])
                            if v > TOL:
                                held[(k, d)] = True; ch = True; info[(k, d)] = max(info[(k, d)], v)
        for k in mnames:
            chk("held %s" % k, all(held[(k, d)] for d in dirs), " ".join("%.3f" % info[(k, d)] for d in dirs))
        # seated
        for k, m in mov["mobiles"].items():
            if len(m["parts"]) < 2:
                continue
            ok = True; inf = []
            for n in m["parts"]:
                rest = kernel.union([parts[o] for o in m["parts"] if o != n])
                vs = [kernel.ivol(parts[n].translate([0.3 * c for c in d]), rest) for d in dirs]
                inf.append(" ".join("%.3f" % v for v in vs))
                ok = ok and all(v > TOL for v in vs[:4]) and (vs[4] > TOL or vs[5] > TOL)
            comp = {m["parts"][0]}
            ch = True
            while ch:
                ch = False
                for a in m["parts"]:
                    if a not in comp and any(kernel.min_distance(parts[a], parts[b], 1.0) <= 0.02 for b in comp):
                        comp.add(a); ch = True
            chk("seated %s" % k, ok and len(comp) == len(m["parts"]), " | ".join(inf))
        # speeds and hands
        sp, cons = speeds(mov, period)
        chk("speeds consistent, all driven", cons and all(k in sp for k in mnames), {k: str(v) for k, v in sp.items()})
        want_sp = dict(hour=Fraction(-1, 12), minute=Fraction(-1), seconds=Fraction(-60), day=Fraction(-1, 24))
        for h, v in want_sp.items():
            chk("hand speed %s" % h, sp.get(mov["hands"][h]["mobile"]) == v, sp.get(mov["hands"][h]["mobile"]))
        ah, am, ad = axis[mov["hands"]["hour"]["mobile"]], axis[mov["hands"]["minute"]["mobile"]], axis[mov["hands"]["day"]["mobile"]]
        chk("common centre", math.hypot(ah[0] - am[0], ah[1] - am[1]) <= 0.01)
        chk("day axis", math.hypot(ah[0] - ad[0], ah[1] - ad[1]) >= 6)
        ftop = max(parts[n].bounding_box()[5] for n in mov["fixed"])
        for h, need in (("hour", 5), ("minute", 5), ("seconds", 5), ("day", 3)):
            hp = parts[mov["hands"][h]["part"]]; ax = axis[mov["hands"][h]["mobile"]]
            V = kernel.verts(hp)
            reach = np.hypot(V[:, 0] - ax[0], V[:, 1] - ax[1]).max()
            mesh = hp.to_mesh(); vv = np.asarray(mesh.vert_properties)[:, :3].astype(float); tt = np.asarray(mesh.tri_verts)
            tr = vv[tt]
            vol6 = np.einsum("ij,ij->i", tr[:, 0], np.cross(tr[:, 1], tr[:, 2]))
            cen = (vol6[:, None] * (tr.sum(1) / 4)).sum(0) / vol6.sum()
            cd = math.hypot(cen[0] - ax[0], cen[1] - ax[1])
            chk("hand %s" % h, reach >= need and V[:, 2].min() >= ftop and cd >= 0.5, "reach %.2f low %.3f frametop %.3f com %.2f" % (reach, V[:, 2].min(), ftop, cd))
        # case
        cc = mov["case_centre"]
        w = 0
        for n in mov["fixed"]:
            V = kernel.verts(parts[n]); w = max(w, np.hypot(V[:, 0] - cc[0], V[:, 1] - cc[1]).max())
        for k in mnames:
            V = kernel.verts(mob[k]); ax = axis[k]
            w = max(w, np.hypot(V[:, 0] - ax[0], V[:, 1] - ax[1]).max() + math.hypot(ax[0] - cc[0], ax[1] - cc[1]))
        zs = [s.bounding_box() for s in list(parts.values()) + [mob["barrel"]]]
        ht = max(b[5] for b in zs) - min(b[2] for b in zs)
        chk("fits case", w <= 20.7 and ht <= 13.4, "radius %.3f height %.3f" % (w, ht))
    pool = Pool(4)
    if want("free"):
        bad += run(t_free, mnames, pool)
    if want("pair"):
        sp, _ = speeds(mov, period)
        meshed = {frozenset((e["driver"], e["driven"])) for e in mov["meshes"]}
        prs = [(a, b, sp.get(a, 0), sp.get(b, 0)) for a, b in itertools.combinations(mnames, 2) if frozenset((a, b)) not in meshed]
        bad += run(t_pair, prs, pool)
    if want("mesh"):
        bad += run(t_mesh, [(i, sh, quick) for i in range(len(mov["meshes"])) for sh in (0.0, 0.03, -0.03)], pool)
    if want("print"):
        bad += run(t_print, [n for n in parts], pool)
    pool.close()
    if want("asm") and movfile == "movement.json":
        asm = json.load(open(os.path.join(OUT, "assembly.json")))
        allp = dict(parts); allp["barrel"] = mob["barrel"]
        order = []
        for n in asm["order"]:
            if n in allp and n not in order:
                order.append(n)
        G["asm"], G["order"], G["asmparts"] = asm, order, allp
        G["notinorder"] = [n for n in allp if n not in order]
        bbs = np.array([s.bounding_box() for s in allp.values()])
        G["bbox"] = (bbs[:, :3].min(0), bbs[:, 3:].max(0))
        pool = Pool(4)
        b = run(t_asm, order, pool)
        pool.close()
        chk("assembly: all installed", b == 0 and not G["notinorder"], "not in order: %s" % G["notinorder"])
    print("FAILURES: %d" % bad)

if __name__ == "__main__":
    main()
