"""Involute gear outlines (polylines) and a copy of the acceptance mesh test, on manifold3d."""
import math, os, sys
import numpy as np
import manifold3d as m3
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel

def inv(a):
    return math.tan(a) - a

def gear_outline(z, m, s, ra, rf, phase=0.0, alpha_deg=25.0, nfl=6, relief=0.0):
    """CCW outline of a spur gear centred on the origin. s: tooth thickness (arc) on the pitch
    circle; ra, rf: tip and root radii; phase: angle (rad) of one tooth centre.
    relief: extra angle (rad) by which the flank below the base circle leans into the tooth."""
    al = math.radians(alpha_deg)
    r = z * m / 2.0
    rb = r * math.cos(al)
    half = s / (2 * r) + inv(al)            # half tooth angle on the base circle
    r0 = max(rb, rf)
    pts = []                                # right flank (negative-angle side), root -> tip
    one = []
    if rf < rb:
        one.append((rf, -(half) + relief))
    for k in range(nfl + 1):
        rr = r0 + (ra - r0) * k / nfl
        a = math.acos(min(1.0, rb / rr))
        one.append((rr, -(half - inv(a))))
    assert one[-1][1] < 0, "tooth is pointed below the tip radius"
    out = []
    pitch = 2 * math.pi / z
    for t in range(z):
        c = phase + t * pitch
        for rr, a in one:
            out.append((rr * math.cos(c + a), rr * math.sin(c + a)))
        for rr, a in reversed(one):
            out.append((rr * math.cos(c - a), rr * math.sin(c - a)))
    return np.array(out)

def prism(outline, z0, z1, cx=0.0, cy=0.0):
    cs = m3.CrossSection([np.asarray(outline, float)])
    return m3.Manifold.extrude(cs, z1 - z0).translate([cx, cy, z0])

def rot_about(man, ax, deg):
    return man.translate([-ax[0], -ax[1], 0]).rotate([0, 0, deg]).translate([ax[0], ax[1], 0])

def mesh_test(D, N, axD, axN, zD, zN, shift=0.0, quick=None, verbose=False):
    """The acceptance mesh test. D, N: manifolds in drawn position. shift: N moved along the line
    from D's axis to N's axis (+ away). Returns (ok, dict of worst figures)."""
    axD = np.asarray(axD, float); axN0 = np.asarray(axN, float)
    d = axN0 - axD
    a = float(np.hypot(*d))
    m = 2 * a / (zD + zN)
    u = d / a if a > 1e-9 else np.array([1.0, 0.0])
    axN = axN0 + shift * u
    if shift:
        N = N.translate([shift * u[0], shift * u[1], 0])
    nsteps = 8 * max(zD, zN)
    if quick:
        nsteps = min(nsteps, quick)
    worst = dict(jam=0.0, gap=0.0, area=1e9, vol=1e9)
    def pose(i):
        th = i * 360.0 / (8 * zD)
        return rot_about(D, axD, th), rot_about(N, axN, -th * zD / zN), th
    ok = True
    for i in range(nsteps):
        Dp, Np, th = pose(i)
        X = Dp ^ Np
        v = X.volume()
        worst["jam"] = max(worst["jam"], v)
        if i % 8 == 0:
            for f in (1 / 3, 1 / 5):
                D2, N2, _ = pose(i + f)
                worst["jam"] = max(worst["jam"], kernel.ivol(D2, N2))
        if i % 4 == 0 and X.is_empty():
            g = Dp.min_gap(Np, 1.0)
            worst["gap"] = max(worst["gap"], g)
        if i % 8 == 0:
            D3 = rot_about(D, axD, th + 90.0 / zD)
            R = (D3 ^ Np) - Dp
            V = R.volume()
            if R.is_empty() or V <= 0:
                worst["area"] = 0; worst["vol"] = 0
            else:
                bb = R.bounding_box()
                H = bb[5] - bb[2]
                worst["vol"] = min(worst["vol"], V)
                worst["area"] = min(worst["area"], V / H)
    worst["need_area"] = 0.5 * m * m
    ok = worst["jam"] <= 0.01 and worst["gap"] <= 0.1 and worst["vol"] >= 0.001 and worst["area"] > 0.5 * m * m
    return ok, worst

def mesh_test3(D, N, axD, axN, zD, zN, quick=None):
    res = {}
    allok = True
    for sh in (0.0, 0.03, -0.03):
        ok, w = mesh_test(D, N, axD, axN, zD, zN, sh, quick)
        res[sh] = w
        allok = allok and ok
    return allok, res

def driven_phase(axD, axN, zD, zN, phaseD, bias):
    """Phase (angle of a tooth centre) of the driven gear so that it meshes with the driver whose
    tooth-centre phase is phaseD. bias: rotation (rad, CCW positive) added to the driven gear
    away from the centred-backlash position."""
    psi = math.atan2(axN[1] - axD[1], axN[0] - axD[0])
    pD = 2 * math.pi / zD
    e = (psi - phaseD) % pD                 # driver must turn +e to put a tooth on the line of centres
    # with a driver tooth on the line, the driven gear has a space centred at psi+pi
    pN = 2 * math.pi / zN
    return psi + math.pi + pN / 2 + e * zD / zN + bias
