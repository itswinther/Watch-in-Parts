import sys, math, time
import numpy as np
from gearlib import *
t = kernel.read_stl(APP + "/supplied/barrel.stl", 10**7, 10**9)
barrel = kernel.tris_to_manifold(t)
def trial(s, ra, rf, biasarc, relief=0.0, zN=12, quick=64, a=None):
    m = 0.2
    a = a or 0.1 * (96 + zN)
    axN = (a * math.cos(0.7), a * math.sin(0.7))
    r = zN * m / 2
    ph = driven_phase((0, 0), axN, 96, zN, 0.0, biasarc / r)
    g = prism(gear_outline(zN, m, s, ra, rf, ph, relief=relief), 0, 1, *axN)
    ok, res = mesh_test3(barrel, g, (0, 0), axN, 96, zN, quick)
    print(s, ra, rf, biasarc, relief, ok)
    for k, w in res.items():
        print("   %+.2f jam %.5f gap %.4f area %.4f (need %.4f)" % (k, w["jam"], w["gap"], w["area"], w["need_area"]))
for bias in (0.02, 0.01, 0.0, -0.01, -0.02):
    trial(0.284, 1.4, 0.95, bias)
