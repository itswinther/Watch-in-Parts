import sys,json,math,numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/work'); sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools')
import insp, kernel as k
def printable(man):
    h=0.05; off=0.0113
    bb=np.array(man.bounding_box())
    lo=bb[:3]-0.3; hi=bb[3:]+0.3
    # centres at h*kk+off -> origin so that origin+0.5h = off mod h
    o=np.floor((lo-off)/h)*h+off-0.5*h
    shape=tuple(int(math.ceil((hi[i]-o[i])/h))+1 for i in range(3))
    n,dev=k.opening_test_slabs(man,tuple(o),shape,h,1.5,1.0,6,slab=32)
    return n,dev
def check(fn):
    J=json.load(open(f'{insp.D}/{fn}'))
    names=list(J['fixed'])+[p for m in J['mobiles'].values() for p in m['parts']]
    out={}
    fixed=k.union([insp.part(n) for n in J['fixed']])
    fixedtop=fixed.bounding_box()[5]
    cc=np.array(J['case_centre'])
    for h in ('hour','minute','seconds','day'):
        e=J['hands'][h]; P=insp.part(e['part']); ax=np.array(J['mobiles'][e['mobile']]['axis'])
        v=k.verts(P); r=np.hypot(*(v[:,:2]-ax).T).max()
        # centre of volume
        m=P.to_mesh(); 
        V=P.volume()
        # centroid via triangles
        vp=np.asarray(m.vert_properties)[:,:3]; t=np.asarray(m.tri_verts)
        a,b,c=vp[t[:,0]],vp[t[:,1]],vp[t[:,2]]
        vol=np.einsum('ij,ij->i',a,np.cross(b,c))/6
        cen=((a+b+c)/4*vol[:,None]).sum(0)/vol.sum()
        out[h]=dict(reach=r,cen=float(np.hypot(*(cen[:2]-ax))),zmin=float(v[:,2].min()),fixedtop=fixedtop)
    # case
    fv=k.verts(fixed); out['fixed_r']=float(np.hypot(*(fv[:,:2]-cc).T).max())
    for m,v in J['mobiles'].items():
        ps=k.union([insp.part(n) for n in v['parts']]); pv=k.verts(ps)
        ax=np.array(v['axis']); out['mob_'+m]=float(np.hypot(*(pv[:,:2]-ax).T).max()+np.linalg.norm(ax-cc))
    bv=k.verts(insp.BAR); out['mob_barrel']=float(np.hypot(*bv[:,:2].T).max()+np.linalg.norm(cc))
    zs=[fv[:,2].min(),fv[:,2].max()]
    allz=[k.verts(insp.part(n))[:,2] for n in names]+[bv[:,2]]
    out['height']=float(max(a.max() for a in allz)-min(a.min() for a in allz))
    return out,names
if __name__=='__main__':
    if sys.argv[1]=='geom':
        o,_=check(sys.argv[2]); 
        for kk,v in o.items(): print(kk,v)
    else:
        for n in sys.argv[2:]:
            print(n,printable(insp.part(n)),flush=True)
