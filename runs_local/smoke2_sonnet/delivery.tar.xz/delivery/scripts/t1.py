import sys; sys.path.insert(0,'.')
import gear, meshtest, math, numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools')
import kernel as k
B=k.tris_to_manifold(k.read_stl('/tmp/claude-0/runs/smoke2_sonnet/app/supplied/barrel.stl',10**7,10**9))
z=24
for tth in (0.284,0.30,0.31):
  for da in (0.0,):
    N=gear.gear_man(z,0.1,0.9,tth=tth,phase=math.pi-math.pi/z).translate([12+da,0,0])
    for sh in (0,0.03,-0.03):
        r=meshtest.mesh_test(B,(0,0),96,N,(12+da,0),z,shift=sh)
        print(tth,da,sh,r['maxint'],r['minV'],r['minVH'],r['thr'],r['fail'][:2])
