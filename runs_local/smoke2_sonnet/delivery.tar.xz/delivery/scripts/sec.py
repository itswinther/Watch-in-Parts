from fractions import Fraction as F
from collections import defaultdict
pairs=[(p,q) for p in range(12,41) for q in range(12,41) if 1<=F(p,q)<=4.5]
d=defaultdict(list)
for a in pairs:
  for b in pairs:
    d[F(a[0],a[1])*F(b[0],b[1])].append((a,b))
sols=[]
for r,l in d.items():
    if r>60: continue
    need=60/r
    if need in d:
        for a in l:
            for b in d[need]:
                s=a+b; 
                sols.append(s)
sols.sort(key=lambda s: max(max(x) for x in s)*1000+sum(sum(x) for x in s))
for s in sols[:8]: print(s)
print(len(sols))
