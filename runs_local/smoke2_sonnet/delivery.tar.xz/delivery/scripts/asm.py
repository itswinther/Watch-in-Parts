import json,sys,numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/work'); sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools')
import insp, kernel as k
D=insp.D
ORDER=['plate_low','barrel','plate_mid','g1_8','m_arb_8','x1','x2','x3','s_body','plate_top','m_mp','d_body','i_body','j_body','h_body','plate_dial','h_hand','m_hand','s_hand','d_hand']
def solid(n): return insp.BAR if n=='barrel' else insp.part(n)
def path_for(n,top=9.5+5.0+0.3):
    S=solid(n); zmin=S.bounding_box()[2]
    lift=top-zmin+0.2
    nst=int(np.ceil(lift/0.19))
    poses=[]
    for i in range(nst+1):
        T=np.eye(4); T[2,3]=lift*(1-i/nst); poses.append(T.tolist())
    poses[-1]=np.eye(4).tolist()
    return poses
def write():
    paths={n:path_for(n) for n in ORDER}
    json.dump({'order':ORDER,'paths':paths},open(D+'/assembly.json','w'))
def check():
    A=json.load(open(D+'/assembly.json'))
    placed=[]; bad=[]
    allsol=k.union([solid(n) for n in A['order']])
    bb=np.array(allsol.bounding_box())
    for n in A['order']:
        S=solid(n); b=np.array(S.bounding_box()); ok=True
        P=A['paths'][n]
        T0=np.array(P[0]); b0=b.copy(); b0[[2,5]]+=T0[2,3]
        outside=any(b0[i+3]<bb[i]-5 or b0[i]>bb[i+3]+5 for i in range(3))
        if not outside: ok=False; bad.append((n,'rule2'))
        for i,T in enumerate(P):
            T=np.array(T)
            if not ok: break
            if i>0:
                d=np.abs(T[:3,3]-np.array(P[i-1])[:3,3]).max()
                if d>0.2: ok=False; bad.append((n,'step',i)); break
            M=S.transform(T[:3,:4].tolist())
            for q,Q in placed:
                v=k.ivol(M,Q)
                if v>0.01: ok=False; bad.append((n,'collide',q,i,v)); break
        placed.append((n,S))   # a part that breaks a rule still stands assembled
    return bad
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='write': write()
    print('bad',check())
