import math, random, json, sys
import numpy as np
tip=lambda z:0.1*z+0.2
def gears(build):
    b1,m1=(30,15) if build==8 else (27,18)
    return {
     'G1':{0:24,1:b1},
     'M':{1:m1,2:32,6:15},
     'X1':{2:14,3:35},
     'X2':{3:12,4:36},
     'X3':{4:12,5:36},
     'S':{5:12},
     'I':{6:45,7:12},
     'H':{7:48},
     'J':{7:32,6:12},
     'D':{6:36},
    }
DIST={'G1':12.0,'M':4.5,'X1':4.6,'X2':4.7,'X3':4.8,'S':4.8,'I':6.0,'J':8.0,'D':4.8}
PAR={'G1':'B','M':'G1','X1':'M','X2':'X1','X3':'X2','S':'X3','I':'M','J':'M','D':'J'}
KEYS=['G1','M','X1','X2','X3','S','I','J','D']
HAND={'M':5.4,'H':5.2,'S':5.4,'D':3.4}
HLEV={'H':1,'M':2,'S':3,'D':4}
LOWER=['G1','M','X1','X2','X3','S']; UPPER=['M','I','J','D','S','H']
LSL=[1,2,3,4,5]; USL=[6,7]
MESH={0:[('B','G1')],1:[('G1','M')],2:[('M','X1')],3:[('X1','X2')],4:[('X2','X3')],5:[('X3','S')],6:[('M','I'),('J','D')],7:[('I','H'),('H','J')]}
def partner(s,a,b): return (a,b) in MESH[s] or (b,a) in MESH[s]
def place(ang):
    pos={'B':np.zeros(2)}
    for k in KEYS:
        pos[k]=pos[PAR[k]]+DIST[k]*np.array([math.cos(ang[k]),math.sin(ang[k])])
    pos['H']=pos['M']
    return pos
def enclosing(P,R):
    c=P.mean(0); step=3.0
    for i in range(80):
        v=np.hypot(*(P-c).T)+R; j=v.argmax()
        d=P[j]-c; n=np.linalg.norm(d)
        if n>1e-9: c=c+step*d/n
        step*=0.9
    return c,(np.hypot(*(P-c).T)+R).max()
def mobR(g):
    Rm={}
    for k,gg in g.items():
        r=max(tip(z) for z in gg.values())
        if k in LOWER: r=max(r,1.05)
        if k in HAND: r=max(r,HAND[k]+0.6)
        Rm[k]=r
    return Rm
def score(ang,verbose=False):
    pen=0; viol=[]
    allP=[];allR=[]
    for build in (8,6):
        g=gears(build); pos=place(ang); Rm=mobR(g)
        def colr(X,s):
            if s in g[X]: return tip(g[X][s])+0.08
            if s in (1,5) and X in LOWER and X!='M': return 0.9
            if s==7 and X=='D': return 0.9
            return 0.67
        for (deck,mobs,slots) in (('L',LOWER,LSL),('U',UPPER,USL)):
            for s in slots:
                for A in mobs:
                    if s not in g[A]: continue
                    R=tip(g[A][s])+0.08
                    for X in mobs:
                        if X==A: continue
                        if {X,A}=={'M','H'}: continue
                        d=np.linalg.norm(pos[A]-pos[X])
                        if partner(s,A,X) : continue
                        need=R+colr(X,s)
                        if X=='H' and s==6: need=R+0.67
                        if d<need: pen+=need-d+0.5; viol.append((build,A,s,X,round(need-d,2)))
        # collars vs collars at slot 1 and 5 (lower), slot 7 (D)
        for s in (1,5):
            cl=[X for X in LOWER if s not in g[X] and X!='M']
            for i in range(len(cl)):
                for j in range(i+1,len(cl)):
                    d=np.linalg.norm(pos[cl[i]]-pos[cl[j]])
                    if d<1.9: pen+=1.9-d+0.5; viol.append(('col',cl[i],cl[j]))
        # keep G1 cutout clear
        for X in ['M','X1','X2','X3','S']:
            d=np.linalg.norm(pos['G1']-pos[X])
            if d<3.9: pen+=3.9-d+0.5; viol.append(('cut',X))
        # hands
        for a in HLEV:
            for b in HLEV:
                if a==b or HLEV[b]<=HLEV[a]: continue
                if {a,b}=={'H','M'}: continue
                d=np.linalg.norm(pos[a]-pos[b]); need=HAND[a]+0.4+1.1
                if d<need: pen+=need-d+0.5; viol.append(('hand',a,b))
        d=np.linalg.norm(pos['D']-pos['H'])
        if d<6.8: pen+=6.8-d+0.5; viol.append(('Ddist',))
        ks=['B']+list(g.keys())
        allP+= [pos[k] for k in ks]; allR+=[9.8 if k=='B' else Rm[k] for k in ks]
    c,R=enclosing(np.array(allP),np.array(allR))
    pen+=max(0,R-19.6)*3
    if verbose: print(viol, c, R)
    return pen,c,R
def search(seed,rst=30,iters=300):
    random.seed(seed)
    best=None
    for r in range(rst):
        ang={k:random.uniform(0,2*math.pi) for k in KEYS}
        s=score(ang)[0]
        for it in range(iters):
            k=random.choice(KEYS); old=ang[k]
            ang[k]=old+random.gauss(0,0.6*(1-it/iters)+0.04)
            s2=score(ang)[0]
            if s2<=s: s=s2
            else: ang[k]=old
            if s<1e-9: break
        if best is None or s<best[0]: best=(s,dict(ang))
        if s<1e-9: break
    return best
if __name__=='__main__':
    b=search(int(sys.argv[1]))
    print(b[0]); print(json.dumps(b[1])); score(b[1],True)
