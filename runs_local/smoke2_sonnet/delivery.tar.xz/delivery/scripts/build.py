import math, json, os, sys
import numpy as np
import cadquery as cq
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/work'); sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools')
import gear, layout2 as L
import kernel as k
OUT='/tmp/claude-0/runs/smoke2_sonnet/app/delivery'
os.makedirs(OUT+'/parts',exist_ok=True)
TTH=0.284
ang=json.load(open('/tmp/claude-0/runs/smoke2_sonnet/app/work/layout_sel.json'))
pos={k_:np.round(v,3) for k_,v in L.place(ang).items()}
allP=[];allR=[]
for b in (8,6):
    g=L.gears(b); Rm=L.mobR(g)
    for kk in ['B']+list(g): allP.append(pos[kk]); allR.append(9.8 if kk=='B' else Rm[kk])
cc,Rcc=L.enclosing(np.array(allP),np.array(allR))
cc=np.round(cc,3)
RF=19.8
def slot(s):
    z0=1.7+0.7*(s-1) if s<=5 else 5.7+0.7*(s-6)
    return z0,z0+0.5
P1=(-1.0,-0.2); P2=(1.1,1.6); PT=(5.1,5.6); PD=(7.0,7.5)
HZ={'H':(7.6,8.0),'M':(8.1,8.5),'S':(8.6,9.0),'D':(9.1,9.5)}
def cyl(x,y,z0,z1,r): return cq.Workplane("XY").workplane(offset=z0).center(x,y).circle(r).extrude(z1-z0)
def gear_cq(z,z0,z1,phase):
    pts=gear.gear_poly(z,tth=TTH,phase=phase)
    return cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1-z0)
def U(*a):
    r=a[0]
    for x in a[1:]: r=r.union(x)
    return r
def tr(w,x,y): return w.translate((x,y,0))
MESHES=[('B','G1',0),('G1','M',1),('M','X1',2),('X1','X2',3),('X2','X3',4),('X3','S',5),('M','I',6),('I','H',7),('H','J',7),('J','D',6)]
def phases(build):
    g=L.gears(build); gg={'B':{0:96}}; gg.update(g)
    ph={('B',0):0.0}
    for (P,C,s) in MESHES:
        zD=gg[P][s]; zN=gg[C][s]
        pD=ph.setdefault((P,s),0.0)
        d=pos[C]-pos[P]; phi=math.atan2(d[1],d[0])
        dD=(phi-pD)*zD/(2*math.pi)
        ph[(C,s)]=phi+math.pi+(2*math.pi/zN)*(dD+0.5)
    return ph
def hand(x,y,z0,z1,L_,rh,bore,w,a=90):
    hub=cq.Workplane("XY").workplane(offset=z0).circle(rh).extrude(z1-z0)
    bar=cq.Workplane("XY").workplane(offset=z0).center(L_/2,0).rect(L_,w).extrude(z1-z0)
    h=hub.union(bar).cut(cq.Workplane("XY").workplane(offset=z0-1).circle(bore).extrude(z1-z0+2))
    return h.rotate((0,0,0),(0,0,1),a).translate((x,y,0))
def mobiles(build,sfx):
    g=L.gears(build); ph=phases(build); out={}
    G=lambda m,s: tr(gear_cq(g[m][s],slot(s)[0],slot(s)[1],ph[(m,s)]),*pos[m])
    col=lambda m,s: cyl(*pos[m],*slot(s),0.85)
    x,y=pos['G1']
    out['g1'+sfx]=U(cyl(x,y,-0.9,5.4,0.5),tr(gear_cq(24,0.0,0.9,ph[('G1',0)]),x,y),G('G1',1),col('G1',5))
    x,y=pos['M']
    out['m_arb'+sfx]=U(cyl(x,y,1.2,5.7,0.6),cyl(x,y,5.7,8.1,0.5),cyl(x,y,8.1,8.5,0.4),G('M',1),G('M',2))
    if sfx=='_8':
        mp=tr(gear_cq(15,slot(6)[0],slot(6)[1],ph[('M',6)]),x,y).cut(cyl(x,y,5,7,0.5))
        out['m_mp']=mp
        out['m_hand']=hand(x,y,*HZ['M'],5.4,1.0,0.4,0.8)
    def simple(name,m,bot,top,gl,cols):
        x,y=pos[m]
        parts_=[cyl(x,y,bot,top,0.5)]+[G(m,s) for s in gl]+[col(m,s) for s in cols]
        out[name]=U(*parts_)
    if sfx=='_8':
        simple('x1','X1',1.2,5.4,[2,3],[1,5]); simple('x2','X2',1.2,5.4,[3,4],[1,5]); simple('x3','X3',1.2,5.4,[4,5],[1])
        x,y=pos['S']
        out['s_body']=U(cyl(x,y,1.2,8.6,0.5),cyl(x,y,8.6,9.0,0.4),G('S',5),col('S',1))
        out['s_hand']=hand(x,y,*HZ['S'],5.4,1.0,0.4,0.8)
        simple('i_body','I',5.2,7.1,[6,7],[])
        simple('j_body','J',5.2,7.1,[6,7],[])
        x,y=pos['D']
        out['d_body']=U(cyl(x,y,5.2,9.1,0.5),cyl(x,y,9.1,9.5,0.4),G('D',6),col('D',7))
        out['d_hand']=hand(x,y,*HZ['D'],3.4,0.9,0.4,0.7)
        x,y=pos['H']
        hb=U(G('H',7),cyl(x,y,6.4,7.6,1.0),cyl(x,y,7.6,8.0,0.8)).cut(cyl(x,y,6.3,8.1,0.55))
        out['h_body']=hb
        out['h_hand']=hand(x,y,*HZ['H'],5.2,1.3,0.8,1.0)
    return out
# ----- frame
def legs_choice(obst, zlo, zhi, n=3, rleg=1.0, rmax=18.8):
    # obst: list of (x,y,r); candidate points on grid in disc around cc
    cands=[]
    for r in np.arange(8,rmax+1e-6,0.4):
        for a in np.arange(0,2*math.pi,math.radians(3)):
            p=np.round(cc+r*np.array([math.cos(a),math.sin(a)]),2)
            c=min(np.hypot(*(p-np.array([ox,oy])))-orr-rleg for ox,oy,orr in obst)
            cands.append((c,p,a))
    cands.sort(key=lambda t:-t[0])
    sel=[]
    for c,p,a in cands:
        if all(abs((a-b+math.pi)%(2*math.pi)-math.pi)>math.radians(70) for _,_,b in sel) or not sel:
            sel.append((c,p,a))
        if len(sel)==n: break
    return sel
def obstacles():
    o={}
    gs=[L.gears(8),L.gears(6)]
    low=[(pos['B'][0],pos['B'][1],9.8+0.2),(pos['G1'][0],pos['G1'][1],2.6+0.25)]
    mid=[];up=[]
    for g in gs:
        for m,gg in g.items():
            for s,z in gg.items():
                r=0.1*z+0.2+0.25
                (mid if s<=5 else up).append((pos[m][0],pos[m][1],r))
    for m in ['G1','M','X1','X2','X3','S']: mid.append((pos[m][0],pos[m][1],1.15))
    for m in ['M','I','J','D','S']: up.append((pos[m][0],pos[m][1],1.15))
    up.append((pos['H'][0],pos['H'][1],1.3))
    # collars at slot 7 of D etc covered; hand/tube
    return low,mid,up
def frame():
    low,mid,up=obstacles(); fr={}
    plate=lambda z0,z1: cyl(cc[0],cc[1],z0,z1,RF)
    legs_info={}
    def addlegs(w,sel,z0,z1):
        for c,p,a in sel: w=w.union(cyl(p[0],p[1],z0,z1,1.0))
        return w
    sl=legs_choice(low,-0.2,1.1); sm=legs_choice(mid,1.6,5.1); su=legs_choice(up,5.6,7.0)
    legs_info=dict(low=[(float(c),p.tolist()) for c,p,a in sl],mid=[(float(c),p.tolist()) for c,p,a in sm],up=[(float(c),p.tolist()) for c,p,a in su])
    p1=plate(*P1).cut(cyl(0,0,-1.5,0,0.55)).cut(cyl(*pos['G1'],-1.5,0,0.55))
    p2=plate(*P2).cut(cyl(0,0,1,2,0.55)).cut(cyl(*pos['G1'],1,2,2.75)).cut(cyl(*pos['M'],1,2,0.65))
    for m in ['X1','X2','X3','S']: p2=p2.cut(cyl(*pos[m],1,2,0.55))
    p2=addlegs(p2,sl,-0.2,1.1)
    pt=plate(*PT)
    for m in ['G1','X1','X2','X3','S','I','J','D']: pt=pt.cut(cyl(*pos[m],5,6,0.55))
    pt=pt.cut(cyl(*pos['M'],5,6,0.65)); pt=addlegs(pt,sm,1.6,5.1)
    pd=plate(*PD)
    for m in ['S','I','J','D']: pd=pd.cut(cyl(*pos[m],6.9,7.6,0.55))
    pd=pd.cut(cyl(*pos['H'],6.9,7.6,1.05)); pd=addlegs(pd,su,5.6,7.0)
    fr={'plate_low':p1,'plate_mid':p2,'plate_top':pt,'plate_dial':pd}
    return fr,legs_info
if __name__=='__main__':
    allparts={}
    fr,li=frame(); print(li); allparts.update(fr)
    m8,=[mobiles(8,'_8')]; allparts.update(m8)
    m6=mobiles(6,'_6'); allparts.update(m6)
    for n,w in allparts.items():
        k.write_step(f'{OUT}/parts/{n}.step',w); print('wrote',n,flush=True)
    json.dump(dict(cc=cc.tolist(),pos={a:b.tolist() for a,b in pos.items()},legs=li),open('/tmp/claude-0/runs/smoke2_sonnet/app/work/info.json','w'))
