import math, random, json
import numpy as np
tip=lambda z:0.1*z+0.2
# gears: mobile -> {slot: teeth}; two builds differ in G1.b1 / M.m1
def gears(build):
    b1,m1=(14,14) if build==8 else (12,16)
    return {
     'G1':{0:12,1:b1},
     'M':{1:m1,2:30,6:15},
     'X1':{2:12,3:32},
     'X2':{3:12,4:36},
     'X3':{4:12,5:36},
     'S':{5:12},
     'I':{6:45,7:12},
     'H':{7:48},
     'J':{7:36,6:12},
     'D':{6:32},
    }
parent={'G1':('B',10.8),'M':('G1',None),'X1':('M',4.2),'X2':('X1',4.4),'X3':('X2',4.8),'S':('X3',4.8),'I':('M',6.0),'J':('M',8.4),'D':('J',4.4)}
def dist_gm(build): return 0.1*(14+14 if build==8 else 28)
HAND={'M':5.4,'H':5.2,'S':5.4,'D':3.4}
HLEV={'H':1,'M':2,'S':3,'D':4}   # hand level order (low->high); mobile M and H share axis
def place(ang,build):
    pos={'B':np.array([0.,0.])}
    pos['G1']=pos['B']+10.8*np.array([math.cos(ang['G1']),math.sin(ang['G1'])])
    for k in ['M','X1','X2','X3','S','I','J','D']:
        p,d=parent[k]
        if k=='M': d=2.8
        pos[k]=pos[p]+d*np.array([math.cos(ang[k]),math.sin(ang[k])])
    return pos
def enclosing(points_r):
    P=np.array([p for p,r in points_r]); R=np.array([r for p,r in points_r])
    c=P.mean(0); step=3.0
    f=lambda c:(np.hypot(*(P-c).T)+R)
    for i in range(60):
        v=f(c); j=v.argmax()
        d=P[j]-c; n=np.linalg.norm(d)
        if n>1e-9: c=c+step*d/n
        step*=0.9
    return c,f(c).max()
def score(ang,verbose=False):
    pen=0; worst=0
    info={}
    allpos=None
    rmax=0
    pts=[]
    for build in (8,6):
        g=gears(build); pos=place(ang,build); pos['H']=pos['M']
        mob={k:v for k,v in pos.items() if k!='B'}
        # mobile radii
        Rm={}
        for k,gg in g.items():
            r=max(tip(z) for z in gg.values()); 
            if k in HAND: r=max(r,HAND[k]+0.6)
            Rm[k]=r
        Rm['B']=9.8
        # column radii at slot for mobile X: gear there? 0.7 : (collar 1.0 at slots 1 and 7) else 0.7
        def col(X,s):
            if X=='B': return None
            if s in g[X]: return tip(g[X][s])
            return 1.05 if s in (1,7) else 0.7
        for A,gg in g.items():
            for s,z in gg.items():
                R=tip(z)+0.12
                for X in list(g.keys()):
                    if X==A: continue
                    d=np.linalg.norm(pos[A]-pos[X])
                    if X=='H' and A!='M' and False: pass
                    if X in gg and False: pass
                    if s in g[X]:
                        # gear-gear same slot: allowed only if meshing partner
                        need=R+tip(g[X][s])+0.12
                        partner=((A,X) in MESH.get(s,[]) or (X,A) in MESH.get(s,[]))
                        if partner: continue
                        if d<need: pen+=need-d+0.5
                    else:
                        need=R+col(X,s)
                        if d<need and not (X=='H' and A=='M') and not (X=='M' and A=='H'):
                            pen+=need-d+0.5
                # barrel disc vs gears at slot0 only G1
        # collars at bands 1 and 7 vs each other (non-gear): collar-collar
        for s in (1,7):
            cl=[X for X in g if s not in g[X] and X!='H']
            for i in range(len(cl)):
                for j in range(i+1,len(cl)):
                    d=np.linalg.norm(pos[cl[i]]-pos[cl[j]])
                    if d<2.3: pen+=2.3-d+0.5
        # coaxial H vs M pair: gear conflicts for H (slot 7 gear 48) covering others handled; M col at slot 7?: M has no gear at 7 -> collar? skip: M has no collar at 7
        # hands
        hl=['H','M','S','D']
        for a in hl:
            for b in hl:
                if a==b: continue
                if HLEV[b]>HLEV[a]:
                    d=np.linalg.norm(pos[a]-pos[b])
                    if a in('H','M') and b in('H','M'): continue
                    need=HAND[a]+0.4+1.05
                    if d<need: pen+=need-d+0.5
        # D axis >=6.5 from H axis
        d=np.linalg.norm(pos['D']-pos['H'])
        if d<6.8: pen+=6.8-d+0.5
        pts_b=[(pos['B'],9.8)]+[(pos[k],Rm[k]) for k in g]
        c,R=enclosing(pts_b)
        info[build]=(c,R)
        pen+=max(0,R-20.0)*3
        pts+=pts_b
    c,R=enclosing(pts)
    if verbose: print(info,c,R)
    return pen+max(0,R-19.9)*3, c, R
MESH={}
def addm(s,a,b): MESH.setdefault(s,[]).append((a,b))
addm(0,'B','G1'); addm(1,'G1','M'); addm(2,'M','X1'); addm(3,'X1','X2'); addm(4,'X2','X3'); addm(5,'X3','S')
addm(6,'M','I'); addm(7,'I','H'); addm(7,'H','J'); addm(6,'J','D')
KEYS=['G1','M','X1','X2','X3','S','I','J','D']
def search(seed):
    random.seed(seed); np.random.seed(seed)
    best=None
    for rst in range(25):
        ang={k:random.uniform(0,2*math.pi) for k in KEYS}
        s=score(ang)[0]
        T=1.0
        for it in range(250):
            k=random.choice(KEYS); old=ang[k]
            ang[k]=old+random.gauss(0,0.5*(1-it/250)+0.05)
            s2=score(ang)[0]
            if s2<=s: s=s2
            else: ang[k]=old
            if s<1e-9: break
        if best is None or s<best[0]: best=(s,dict(ang))
        if s<1e-9: break
    return best
if __name__=='__main__':
    import sys
    b=search(int(sys.argv[1]))
    print(b[0]); print(json.dumps(b[1]))
    sc,c,R=score(b[1],True); print(c,R)
