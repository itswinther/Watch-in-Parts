from fractions import Fraction as F
import itertools
best=[]
R=range(12,40)
for mb in range(20,36):
  for x1a in range(12,22):
    for x1b in range(12,40):
      if x1b>mb+x1a-9.9: continue
      for x2a in range(12,22):
        for x2b in range(12,40):
          if x2b>x1b+x2a-9.9: continue
          for x3a in range(12,22):
            r=F(mb,x1a)*F(x1b,x2a)*F(x2b,x3a)
            need=60/r  # x3b/sa
            if need<1 or need>5: continue
            for x3b in range(12,40):
              if x3b>x2b+x3a-9.9: continue
              sa=F(x3b)/need
              if sa.denominator==1 and sa>=12:
                best.append((mb,x1a,x1b,x2a,x2b,x3a,x3b,int(sa)))
best.sort(key=lambda s:(max(s),sum(s)))
print(len(best)); print(best[:10])
