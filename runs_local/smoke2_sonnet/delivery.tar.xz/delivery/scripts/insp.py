import sys, json, math, itertools, time
from fractions import Fraction as F
import numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools'); sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/work')
import kernel as k, meshtest
import manifold3d as m3
D='/tmp/claude-0/runs/smoke2_sonnet/app/delivery'
_cache={}
def part(n):
    if n not in _cache:
        _cache[n]=k.load_step_part(f'{D}/parts/{n}.step',16777216,200000,0.001,0.1,500,120,4096,0.005)
    return _cache[n]
BAR=k.tris_to_manifold(k.read_stl('/tmp/claude-0/runs/smoke2_sonnet/app/supplied/barrel.stl',10**7,10**9))
def rot(man,axis,deg): return meshtest.rot_about(man,axis,deg)
def load(fn):
    J=json.load(open(f'{D}/{fn}'))
    fixed=[part(n) for n in J['fixed']]
    mob={'barrel':dict(axis=(0.,0.),parts=[BAR],names=['barrel'])}
    for m,v in J['mobiles'].items(): mob[m]=dict(axis=tuple(v['axis']),parts=[part(n) for n in v['parts']],names=v['parts'])
    for m in mob: mob[m]['solid']=k.union(mob[m]['parts'])
    return J,fixed,mob
def speeds(J,rate):  # rev/h cw positive
    sp={'barrel':rate}; changed=True; bad=False
    meshes=J['meshes']
    while changed:
        changed=False
        for e in meshes:
            a,b=e['driver'],e['driven']; za,zb=e['driver_teeth'],e['driven_teeth']
            for x,y,zx,zy in ((a,b,za,zb),(b,a,zb,za)):
                if x in sp:
                    v=-sp[x]*F(zx,zy)
                    if y not in sp: sp[y]=v; changed=True
                    elif sp[y]!=v: bad=True
    return sp,bad
def run(fn,rate,quick=False):
    t0=time.time(); res={}
    J,fixed,mob=load(fn)
    frame=k.union(fixed)
    names=list(mob)
    # C2
    c2=[]
    solids=[('frame',frame)]+[(m,mob[m]['solid']) for m in names]
    for (a,A),(b,B) in itertools.combinations(solids,2):
        v=k.ivol(A,B)
        if v>0.01: c2.append(('solid',a,b,v))
    for i,j in itertools.combinations(range(len(fixed)),2):
        v=k.ivol(fixed[i],fixed[j])
        if v>0.01: c2.append(('fixed',J['fixed'][i],J['fixed'][j],v))
    for m in names:
        ps=mob[m]['parts']
        for i,j in itertools.combinations(range(len(ps)),2):
            v=k.ivol(ps[i],ps[j])
            if v>0.01: c2.append(('part',m,mob[m]['names'][i],mob[m]['names'][j],v))
    # fixed connectivity
    n=len(fixed); seen={0}; st=[0]
    while st:
        i=st.pop()
        for j in range(n):
            if j not in seen and k.min_distance(fixed[i],fixed[j],0.05)<=0.01: seen.add(j); st.append(j)
    if len(seen)!=n: c2.append(('frame not connected',sorted(set(range(n))-seen)))
    res['C2']=c2; print('C2',c2,time.time()-t0,flush=True)
    # check1
    f1=[]
    for m in names:
        S=mob[m]['solid']; ax=mob[m]['axis']
        worst=0
        for i in range(72):
            v=k.ivol(rot(S,ax,5*i),frame); worst=max(worst,v)
        if worst>0.01: f1.append((m,worst))
    res['1 free']=f1; print('free',f1,time.time()-t0,flush=True)
    # check2 held
    held={m:{} for m in names}
    dirs={'+x':(.3,0,0),'-x':(-.3,0,0),'+y':(0,.3,0),'-y':(0,-.3,0),'+z':(0,0,.3),'-z':(0,0,-.3)}
    f2=[]
    for dn,dv in dirs.items():
        h={}
        inter={}
        for m in names: h[m]=k.ivol(mob[m]['solid'].translate(list(dv)),frame)>0.01
        for a in names:
            for b in names:
                if a<b and math.dist(mob[a]['axis'],mob[b]['axis'])<=0.01:
                    pass
        ch=True
        while ch:
            ch=False
            for a in names:
                if h[a]: continue
                for b in names:
                    if b!=a and h[b] and math.dist(mob[a]['axis'],mob[b]['axis'])<=0.01:
                        if k.ivol(mob[a]['solid'].translate(list(dv)),mob[b]['solid'])>0.01: h[a]=True; ch=True; break
        for m in names:
            if not h[m]: f2.append((m,dn))
    res['2 held']=f2; print('held',f2,time.time()-t0,flush=True)
    # check3 seated
    f3=[]
    for m in names:
        ps=mob[m]['parts']
        if len(ps)<2 or m=='barrel': continue
        for i,p in enumerate(ps):
            others=k.union([q for j,q in enumerate(ps) if j!=i])
            for dn in ('+x','-x','+y','-y'):
                if k.ivol(p.translate(list(dirs[dn])),others)<=0.01: f3.append((m,mob[m]['names'][i],dn))
            if all(k.ivol(p.translate(list(dirs[dn])),others)<=0.01 for dn in ('+z','-z')): f3.append((m,mob[m]['names'][i],'z'))
        # connected chain
        nn=len(ps); seen={0}; st=[0]
        while st:
            i=st.pop()
            for j in range(nn):
                if j not in seen and k.min_distance(ps[i],ps[j],0.05)<=0.02: seen.add(j); st.append(j)
        if len(seen)!=nn: f3.append((m,'not one piece'))
    res['3 seated']=f3; print('seated',f3,time.time()-t0,flush=True)
    # speeds + meshes
    sp,bad=speeds(J,F(1,rate))
    res['speeds']={m:str(v) for m,v in sp.items()}; print('speeds',res['speeds'],bad)
    f4=[]
    if bad: f4.append('two speeds')
    for m in names:
        if m not in sp: f4.append(('unreached',m))
    mt={}
    for idx,e in enumerate(J['meshes']):
        a,b=e['driver'],e['driven']
        for sh,lab in ((0,'nom'),(0.03,'away'),(-0.03,'toward')):
            r=meshtest.mesh_test(mob[a]['solid'],mob[a]['axis'],e['driver_teeth'],mob[b]['solid'],mob[b]['axis'],e['driven_teeth'],shift=sh)
            mt[(idx,lab)]=(r['fail'][:2],r['minVH']/r['thr'] if r['thr'] else 0)
            if r['fail']: f4.append(('mesh',idx,a,b,lab,r['fail'][:2]))
        print('mesh',idx,a,b,{l:mt[(idx,l)][1] for l in ('nom','away','toward')},time.time()-t0,flush=True)
    res['4/5 mesh']=f4; print('mesh fails',f4)
    # check 6
    f6=[]
    meshed={frozenset((e['driver'],e['driven'])) for e in J['meshes']}
    for a,b in itertools.combinations(names,2):
        if frozenset((a,b)) in meshed: continue
        wa=float(sp.get(a,0))*360; wb=float(sp.get(b,0))*360   # deg per hour (sign: cw positive -> negative angle)
        fast=max(abs(wa),abs(wb))
        if fast==0:
            if k.ivol(mob[a]['solid'],mob[b]['solid'])>0.01: f6.append((a,b)); 
            continue
        worst=0
        # quick reject: bbox of full rotation discs
        for i in range(144):
            t=i/144*360/fast
            A=rot(mob[a]['solid'],mob[a]['axis'],-wa*t); B=rot(mob[b]['solid'],mob[b]['axis'],-wb*t)
            worst=max(worst,k.ivol(A,B))
        if wa!=wb:
            rel=abs(wa-wb)
            for i in range(144):
                t=i/144*360/rel
                A=rot(mob[a]['solid'],mob[a]['axis'],-wa*t); B=rot(mob[b]['solid'],mob[b]['axis'],-wb*t)
                worst=max(worst,k.ivol(A,B))
        if worst>0.01: f6.append((a,b,worst))
    res['6 nothing else']=f6; print('check6',f6,time.time()-t0,flush=True)
    return res
if __name__=='__main__':
    fn=sys.argv[1]; rate=int(sys.argv[2])
    r=run(fn,rate)
    json.dump({k_:str(v) for k_,v in r.items()},open(f'/tmp/claude-0/runs/smoke2_sonnet/app/work/res_{fn}.json','w'),indent=1)
