import json,sys
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/work')
info=json.load(open('info.json')); pos=info['pos']; cc=info['cc']
OUT='/tmp/claude-0/runs/smoke2_sonnet/app/delivery'
fixed=['plate_low','plate_mid','plate_top','plate_dial']
def mov(b):
    s='_8' if b==8 else '_6'
    mob={}
    def ax(m): return [round(pos[m][0],6),round(pos[m][1],6)]
    mob['G1']={'axis':ax('G1'),'parts':['g1'+s]}
    mob['M']={'axis':ax('M'),'parts':['m_arb'+s,'m_mp','m_hand']}
    for n,m in [('X1','x1'),('X2','x2'),('X3','x3'),('I','i_body'),('J','j_body')]:
        mob[n]={'axis':ax(n),'parts':[m]}
    mob['S']={'axis':ax('S'),'parts':['s_body','s_hand']}
    mob['D']={'axis':ax('D'),'parts':['d_body','d_hand']}
    mob['H']={'axis':ax('M'),'parts':['h_body','h_hand']}
    g1b,m1=(30,15) if b==8 else (27,18)
    meshes=[('barrel',96,'G1',24),('G1',g1b,'M',m1),('M',32,'X1',14),('X1',35,'X2',12),('X2',36,'X3',12),('X3',36,'S',12),
            ('M',15,'I',45),('I',12,'H',48),('H',48,'J',32),('J',12,'D',36)]
    return {'case_centre':cc,'fixed':fixed,'mobiles':mob,
      'meshes':[{'driver':a,'driver_teeth':za,'driven':c,'driven_teeth':zc} for a,za,c,zc in meshes],
      'hands':{'hour':{'mobile':'H','part':'h_hand'},'minute':{'mobile':'M','part':'m_hand'},'seconds':{'mobile':'S','part':'s_hand'},'day':{'mobile':'D','part':'d_hand'}}}
json.dump(mov(8),open(OUT+'/movement.json','w'),indent=1)
json.dump(mov(6),open(OUT+'/variant_6h.json','w'),indent=1)
