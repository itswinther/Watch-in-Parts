import sys, math, numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/smoke2_sonnet/app/tools')
import kernel as k
import manifold3d as m3
def rot_about(man, axis, deg):
    # rotate about vertical line through axis (ccw positive)
    return man.translate([-axis[0],-axis[1],0]).rotate([0,0,deg]).translate([axis[0],axis[1],0])
def mesh_test(D, aD, zD, N, aN, zN, shift=0.0, verbose=False, steps_limit=None):
    a=math.dist(aD,aN); m=2*a/(zD+zN)
    if shift:
        dx=np.array(aN)-np.array(aD); u=dx/np.linalg.norm(dx) if np.linalg.norm(dx)>0 else np.array([1.,0])
        aN=(aN[0]+shift*u[0], aN[1]+shift*u[1]); N=N.translate([shift*u[0],shift*u[1],0])
    nst=8*max(zD,zN); res=dict(maxint=0,fail=[], minV=1e9, minVH=1e9)
    def pos(i):
        ang=i*360/(8*zD)
        return rot_about(D,aD,ang), rot_about(N,aN,-ang*zD/zN)
    for i in range(nst):
        ids=[i]
        if i%8==0: ids+= [i+1/3,i+1/5]
        for j in ids:
            d,n=pos(j); v=k.ivol(d,n); res['maxint']=max(res['maxint'],v)
            if v>0.01: res['fail'].append(('jam',j,v))
        if i%4==0:
            d,n=pos(i)
            if k.ivol(d,n)<=1e-12 and k.min_distance(d,n,1.0)>0.1: res['fail'].append(('engage',i))
        if i%8==0:
            d,n=pos(i)
            ang=i*360/(8*zD)+90/zD
            d2=rot_about(D,aD,ang)
            reg=(d2^n)-d
            V=reg.volume()
            bb=reg.bounding_box() if not reg.is_empty() else None
            H=(bb[5]-bb[2]) if bb is not None else 0
            vh=V/H if H>0 else 0
            res['minV']=min(res['minV'],V); res['minVH']=min(res['minVH'],vh)
            if V<0.001 or vh<=0.5*m*m: res['fail'].append(('drive',i,V,vh))
        if len(res['fail'])>5: break
    res['thr']=0.5*m*m
    return res
