import math, numpy as np
import manifold3d as m3
M=0.2; PA=math.radians(25)
def involute_pts(rb, r0, r1, n=8):
    # returns list of (r, polar angle) of involute from r0 to r1 (angle of involute relative to start at base circle)
    out=[]
    for i in range(n+1):
        r=r0+(r1-r0)*i/n
        t=math.sqrt(max(r*r/(rb*rb)-1,0))
        out.append((r, t-math.atan(t)))
    return out
def gear_poly(z, tth=None, m=M, pa=PA, add=1.0, ded=1.25, phase=0.0, tip_land=True):
    """closed polygon (list of xy), tooth centred on angle `phase` (rad). tth = tooth thickness arc on pitch circle."""
    rp=m*z/2; rb=rp*math.cos(pa); ra=rp+add*m; rr=rp-ded*m
    if tth is None: tth=math.pi*m/2
    # half tooth angle at pitch circle
    inv_p=math.tan(pa)-pa
    half_p=tth/(2*rp)
    # angle of involute start (at base circle) relative to tooth centre: half_p + inv_p
    off=half_p+inv_p
    r_start=max(rb,rr)
    pts=[]
    for k in range(z):
        c=phase+2*math.pi*k/z
        flank=involute_pts(rb,r_start,ra,10)
        # right flank (ccw side): angle = c - off + inv(r)... tooth centre c; involute angle phi(r)=inv(r); points at angle c+off-inv? 
        # at pitch r: inv=inv_p -> angle offset = half_p. general: offset = off - inv(r)
        right=[(r, c-(off-inv)) for r,inv in flank]      # from root to tip on the cw side
        left=[(r, c+(off-inv)) for r,inv in reversed(flank)]
        seq=[]
        # root point on cw side
        if rr<r_start-1e-9: seq.append((rr, c-off))
        seq+=right+left
        if rr<r_start-1e-9: seq.append((rr, c+off))
        # root arc to next tooth
        c2=phase+2*math.pi*(k+1)/z
        a0=c+off; a1=c2-off
        n=4
        for j in range(1,n):
            seq.append((rr, a0+(a1-a0)*j/n))
        pts+=seq
    return [(r*math.cos(a), r*math.sin(a)) for r,a in pts]
def gear_man(z, z0, z1, **kw):
    cs=m3.CrossSection([gear_poly(z,**kw)])
    return m3.Manifold.extrude(cs.to_polygons() and cs, z1-z0).translate([0,0,z0])
