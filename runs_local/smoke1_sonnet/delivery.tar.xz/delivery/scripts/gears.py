import numpy as np, cadquery as cq
PA=np.radians(25.0)
def inv(a): return np.tan(a)-a
def gear_pts(m,z,phase,t_arc=None,nfl=8):
    """polygon (ccw) of external involute spur gear; tooth centred at angle `phase`+k*2pi/z."""
    rp=m*z/2; rb=rp*np.cos(PA); rt=rp+m; rr=rp-1.25*m
    if t_arc is None: t_arc=np.pi*m/2-0.025
    th_p=t_arc/(2*rp)
    def th(r): return th_p+inv(PA)-inv(np.arccos(min(1.0,rb/r)))
    r0=max(rr,rb)
    rs=np.linspace(r0,rt,nfl)
    pts=[]
    for k in range(z):
        psi=phase+2*np.pi*k/z
        right=[]
        if rr<rb: right.append((rr,psi-th(rb)))
        for r in rs: right.append((r,psi-th(r)))
        left=[(r,psi+th(r)) for r in rs[::-1]]
        if rr<rb: left.append((rr,psi+th(rb)))
        pts+=right+left
        # root arc to next tooth
        a0=left[-1][1]; a1=(phase+2*np.pi*(k+1)/z)-th(rb if rr<rb else r0)
        for f in (0.25,0.5,0.75): pts.append((rr, a0+(a1-a0)*f))
    P=np.array([(r*np.cos(a),r*np.sin(a)) for r,a in pts])
    return P
def gear_solid(cx,cy,z0,z1,m,z,phase):
    P=gear_pts(m,z,phase)+np.array([cx,cy])
    return cq.Workplane("XY").workplane(offset=z0).polyline([tuple(p) for p in P]).close().extrude(z1-z0)
def cyl(cx,cy,z0,z1,r):
    return cq.Workplane("XY").workplane(offset=z0).center(cx,cy).circle(r).extrude(z1-z0)
def frustum(cx,cy,z0,z1,r0,r1):
    w=cq.Workplane("XZ").polyline([(0,z0),(r0,z0),(r1,z1),(0,z1)]).close().revolve(360,(0,0,0),(0,1,0))
    return w.translate((cx,cy,0))
