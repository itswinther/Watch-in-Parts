#!/bin/bash
cd /tmp/claude-0/runs/smoke1_sonnet/app/delivery/scripts
export PYTHONPATH=.
python3 run1.py movement.json > f_run1_mov.log 2>&1
python3 run1.py variant_6h.json > f_run1_var.log 2>&1
python3 run3.py movement.json 8 > f_run3_mov.log 2>&1
python3 run3.py variant_6h.json 6 > f_run3_var.log 2>&1
python3 run2.py movement.json 1 > f_run2_mov.log 2>&1
python3 run2.py variant_6h.json 1 > f_run2_var.log 2>&1
python3 run4.py > f_run4.log 2>&1
cd /tmp/claude-0/runs/smoke1_sonnet/app && python3 tools/check_format.py > delivery/scripts/f_format.log 2>&1
echo ALLDONE > delivery/scripts/f_done.log
