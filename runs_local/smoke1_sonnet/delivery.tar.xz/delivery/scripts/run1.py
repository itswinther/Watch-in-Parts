import time
from wtests import *
import sys
fn=sys.argv[1]
t=time.time(); mv=Mov(fn); print('loaded',time.time()-t,flush=True)
print('C2',c2(mv),flush=True)
print('check1',check1(mv,10),flush=True)
print('check2',check2(mv),flush=True)
print('check3',check3(mv),flush=True)
