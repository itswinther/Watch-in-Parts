import sys, os, json, numpy as np, cadquery as cq
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
ROOT=os.path.abspath(os.path.join(HERE,'..')); sys.path.insert(0,os.path.join(ROOT,'..','tools'))
from layout import *
from gears import *
import kernel
c,POS=json.load(open(os.path.join(HERE,'found_1.json')))
POS={k:np.array(v) for k,v in POS.items()}
C=np.array(c)
ZP0,ZP1=-1.6,-0.05          # plate
ZB1=6.5                      # bridge top
THK=0.3
# ---------- phases ----------
def ang(a,b): d=b-a; return np.arctan2(d[1],d[0])
PH={}   # (mobile,gear)->phase
def solve_phase(dname,dg,nname,ng,posd,posn,phd,mod_z):
    (zd,m)=mod_z[0]; (zn,_)=mod_z[1]
    psi=ang(posd,posn); rd=m*zd/2; rn=m*zn/2; Parc=np.pi*m
    ud=phd-psi; pn=2*np.pi/zn
    un=-(rd*ud+Parc/2)/rn
    un=(un+pn/2)%pn-pn/2
    return psi+np.pi+un
def gear_info(mob,g):
    x=[q for q in GEARS[mob] if q[0]==g][0]; return x[1],x[2]
def compute_phases(builds):
    PH.clear()
    # barrel -> A
    A=builds
    for a,ga,b,gb in MESH_B(A):
        pass
def MESH_B(A):
    return [('barrel','B',A,'Aw')]+[(a if a!='A8' else A,ga,b,gb) for a,ga,b,gb in MESH]
def phases_for(A):
    ph={}
    pos=dict(POS)
    ph[('barrel','B')]=0.0
    meshes=[('barrel','B',A,'Aw')]+[(A if a=='A8' else a,ga,b,gb) for a,ga,b,gb in MESH]
    for a,ga,b,gb in meshes:
        if a=='barrel': zd,m=96,0.2; pa=np.zeros(2)
        else: zd,m=gear_info(a,ga); pa=pos[a]
        zn,mn=gear_info(b,gb); pb=pos[b]
        assert abs(m-mn)<1e-9,(a,b)
        d=np.hypot(*(pb-pa)); assert abs(d-m*(zd+zn)/2)<1e-6,(a,b,d,m*(zd+zn)/2)
        ph[(b,gb)]=solve_phase(a,ga,b,gb,pa,pb,ph.setdefault((a,ga),ang(pa,pb)),[(zd,m),(zn,m)])
    return ph
# ---------- solids ----------
def cone_top(x,y,zc,r0,r1,dz=0.6): return frustum(x,y,zc,zc+dz,r0,r1)
def hand_solid(x,y,zc,Rhub,r0,r1,L,w0=0.9,w1=0.3,z0=None):
    z0=zc+0.05 if z0 is None else z0
    hub=cyl(x,y,z0,z0+THK,Rhub)
    arm=(cq.Workplane("XY").workplane(offset=z0).polyline([(x-w0/2,y+0.3),(x+w0/2,y+0.3),(x+w1/2,y+L),(x-w1/2,y+L)]).close().extrude(THK))
    h=hub.union(arm)
    bore=frustum(x,y,zc-0.01 if False else zc,zc+0.6,r0,r1)
    # extend bore slightly below/above hub with same cone slope
    s=(r1-r0)/0.6
    bore=frustum(x,y,z0-0.05,z0+THK+0.05,r0+s*(z0-0.05-zc),r0+s*(z0+THK+0.05-zc))
    return h.cut(bore)
GZ={}
def build_mobile_parts(name,A):
    """returns dict partname -> cq solid for the mobile"""
    ph=PH
    key=name
    x,y=POS[name.upper() if name!='a' else A]
    out={}
    def gears(mob):
        s=None
        for g,z,m,(z0,z1) in [(q[0],q[1],q[2],q[3]) for q in GEARS[mob]]:
            gs=gear_solid(x,y,z0,z1,m,z,ph.get((mob,g),0.0))
            s=gs if s is None else s.union(gs)
        return s
    top=ZB+0.3
    if name=='a':
        s=gears(A).union(cyl(x,y,-1.2,top,RA)).union(cyl(x,y,ZB-0.55,ZB-0.05,0.75))
        out['wheel_'+A.lower()]=s
    elif name in('i','j','x1','x2','x3'):
        mob=name.upper()
        s=gears(mob).union(cyl(x,y,-1.2,top,RA)).union(cyl(x,y,0.0,0.5,0.7))
        if name in('i','j','x1','x2'): s=s.union(cyl(x,y,ZB-0.55,ZB-0.05,0.75))
        out[{'i':'arbor_i','j':'idler_j','x1':'wheel_x1','x2':'wheel_x2','x3':'wheel_x3'}[name]]=s
    elif name=='s':
        zc=STAFF_TOP['S']-0.6
        s=gears('S').union(cyl(x,y,-1.2,zc,RA)).union(cone_top(x,y,zc,RA,RA-0.2)).union(cyl(x,y,0.0,0.5,0.7))
        out['staff_s']=s
        out['hand_sec']=hand_solid(x,y,zc,1.0,RA,RA-0.2,HAND_LEN['S'])
    elif name=='d':
        zc=STAFF_TOP['D']-0.6
        s=gears('D').union(cyl(x,y,-1.2,zc,RA)).union(cone_top(x,y,zc,RA,RA-0.2)).union(cyl(x,y,0.0,0.5,0.7)).union(cyl(x,y,ZB-0.55,ZB-0.05,0.75))
        out['staff_d']=s
        out['hand_day']=hand_solid(x,y,zc,1.0,RA,RA-0.2,HAND_LEN['D'],w0=0.8,w1=0.3)
    elif name=='m':
        zc=STAFF_TOP['M']-0.6
        s=gears('M').union(cyl(x,y,-1.2,zc,RA)).union(cone_top(x,y,zc,RA,RA-0.2)).union(cyl(x,y,0.0,0.5,0.7))
        out['staff_m']=s
        out['hand_min']=hand_solid(x,y,zc,1.0,RA,RA-0.2,HAND_LEN['M'])
    elif name=='h':
        zc=STAFF_TOP['H']-0.6
        s=gears('H').union(cyl(x,y,2.85,zc,1.1)).union(cone_top(x,y,zc,1.1,0.9)).union(cyl(x,y,ZB-0.55,ZB-0.05,1.6))
        s=s.cut(cyl(x,y,2.8,STAFF_TOP['H']+0.1,0.55))
        out['tube_h']=s
        out['hand_hour']=hand_solid(x,y,zc,1.7,1.1,0.9,HAND_LEN['H'],w0=1.0,w1=0.3)
    return out

# ---------- frame ----------
RPLATE=20.4
BORES=[('barrel',np.zeros(2),0.55)]+[(k,POS[k],0.55) for k in ('A8','A6','I','X1','X2','X3','S','J','D')]+[('M',POS['M'],1.15)]
def pillar_positions():
    # candidates on circle/grid, clear of every cylinder of any mobile and barrel
    cands=[]
    allcyl=[]
    for m in POS:
        if m=='H': continue
        for cc in cylinders(m,POS[m]): 
            if cc[5]!='hand': allcyl.append(cc)
    allcyl.append((0,0,9.8,0,1,'d')); allcyl.append((11.3,0,1.0+0.3,-1,3,'post')); allcyl.append((5.6,0,1.3,-1,3,'arm'))
    for gx in np.arange(-30,15,0.5):
        for gy in np.arange(-25,25,0.5):
            p=np.array([gx,gy])
            if np.hypot(*(p-C))>RPLATE-1.2: continue
            if all(np.hypot(gx-q[0],gy-q[1])>q[2]+1.0+0.25 for q in allcyl): cands.append(p)
    cands=np.array(cands)
    # choose 3 spread: farthest-point
    ch=[cands[np.argmax(np.hypot(*(cands-C).T))]]
    for _ in range(3):
        d=np.min([np.hypot(*(cands-q).T) for q in ch],axis=0); ch.append(cands[np.argmax(d)])
    return ch
def frame_parts():
    pil=pillar_positions()
    plate=cyl(C[0],C[1],ZP0,ZP1,RPLATE)
    for nm,p,r in BORES: plate=plate.cut(cyl(p[0],p[1],ZP0-0.1,ZP1+0.1,0.55))
    for p in pil: plate=plate.union(cyl(p[0],p[1],ZP1-0.0,ZB,1.0))
    bridge=cyl(C[0],C[1],ZB,ZB1,RPLATE)
    for nm,p,r in BORES: bridge=bridge.cut(cyl(p[0],p[1],ZB-0.1,ZB1+0.1,r))
    # barrel arm: post + bar + disc over the arbor
    px=11.3
    arm=cyl(px,0,ZP1,2.15,0.9).union(cq.Workplane("XY").workplane(offset=1.65).polyline([(0,-0.8),(px,-0.8),(px,0.8),(0,0.8)]).close().extrude(0.5)).union(cyl(0,0,1.65,2.15,1.0))
    return {'plate':plate,'bridge':bridge,'barrel_arm':arm}, [p.tolist() for p in pil]

def build_all(outdir):
    os.makedirs(os.path.join(outdir,'parts'),exist_ok=True)
    fr,pil=frame_parts()
    parts=dict(fr)
    mob={}
    desc={}
    for A,tag in (('A8','8'),('A6','6')):
        if A=='A8':
            PH.clear(); PH.update(phases_for(A)); ph8=dict(PH)
        else:
            PH.clear(); PH.update(ph8)
            PH[('A6','Aw')]=solve_phase('barrel','B','A6','Aw',np.zeros(2),POS['A6'],0.0,[(96,0.2),(32,0.2)])
            PH[('A6','Ap')]=solve_phase('M','Mg','A6','Ap',POS['M'],POS['A6'],ph8[('M','Mg')],[(20,0.25),(40,0.25)])
        for nm in ('a','m','h','i','j','d','x1','x2','x3','s'):
            if A=='A6' and nm!='a': continue
            for pn,sol in build_mobile_parts(nm,A).items(): parts[pn]=sol; mob.setdefault((A,nm),[]).append(pn)
    for pn,sol in parts.items():
        kernel.write_step(os.path.join(outdir,'parts',pn+'.step'),sol)
        print('wrote',pn,flush=True)
    return pil,mob
if __name__=='__main__':
    pil,mob=build_all(ROOT)
    json.dump({'pillars':pil,'mob':{a+'_'+b:v for (a,b),v in mob.items()}},open(os.path.join(HERE,'built.json'),'w'))
