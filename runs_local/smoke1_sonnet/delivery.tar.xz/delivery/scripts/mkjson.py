import json,os,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from build import POS,C,ROOT
def mv(A):
    ax=lambda k:[round(float(POS[k][0]),9),round(float(POS[k][1]),9)]
    a_teeth=24 if A=='A8' else 32
    d={
     "case_centre":[round(float(C[0]),9),round(float(C[1]),9)],
     "fixed":["plate","bridge","barrel_arm"],
     "mobiles":{
       "a":{"axis":ax(A),"parts":["wheel_a8" if A=='A8' else "wheel_a6"]},
       "m":{"axis":ax('M'),"parts":["staff_m","hand_min"]},
       "h":{"axis":ax('M'),"parts":["tube_h","hand_hour"]},
       "i":{"axis":ax('I'),"parts":["arbor_i"]},
       "j":{"axis":ax('J'),"parts":["idler_j"]},
       "d":{"axis":ax('D'),"parts":["staff_d","hand_day"]},
       "x1":{"axis":ax('X1'),"parts":["wheel_x1"]},
       "x2":{"axis":ax('X2'),"parts":["wheel_x2"]},
       "x3":{"axis":ax('X3'),"parts":["wheel_x3"]},
       "s":{"axis":ax('S'),"parts":["staff_s","hand_sec"]}},
     "meshes":[
       {"driver":"barrel","driver_teeth":96,"driven":"a","driven_teeth":a_teeth},
       {"driver":"a","driver_teeth":40,"driven":"m","driven_teeth":20},
       {"driver":"m","driver_teeth":15,"driven":"i","driven_teeth":45},
       {"driver":"i","driver_teeth":12,"driven":"h","driven_teeth":48},
       {"driver":"h","driver_teeth":24,"driven":"j","driven_teeth":34},
       {"driver":"j","driver_teeth":34,"driven":"d","driven_teeth":48},
       {"driver":"m","driver_teeth":48,"driven":"x1","driven_teeth":12},
       {"driver":"x1","driver_teeth":36,"driven":"x2","driven_teeth":12},
       {"driver":"x2","driver_teeth":30,"driven":"x3","driven_teeth":12},
       {"driver":"x3","driver_teeth":24,"driven":"s","driven_teeth":12}],
     "hands":{"hour":{"mobile":"h","part":"hand_hour"},"minute":{"mobile":"m","part":"hand_min"},
              "seconds":{"mobile":"s","part":"hand_sec"},"day":{"mobile":"d","part":"hand_day"}}}
    return d
json.dump(mv('A8'),open(os.path.join(ROOT,'movement.json'),'w'),indent=1)
json.dump(mv('A6'),open(os.path.join(ROOT,'variant_6h.json'),'w'),indent=1)
