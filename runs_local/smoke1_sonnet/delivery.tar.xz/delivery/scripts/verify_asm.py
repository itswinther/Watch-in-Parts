import json,sys,time
from wtests import *
mv=Mov('movement.json')
solid={n:part(n) for n in mv.fixed}
for k,v in mv.mparts.items():
    if k!='barrel':
        for p in v: solid[p]=part(p)
solid['barrel']=barrel()
A=json.load(open(ROOT+'/delivery/assembly.json'))
order=[];[order.append(n) for n in A['order'] if n in solid and n not in order]
print('order',order,'missing',set(solid)-set(order))
allb=np.array([solid[n].bounding_box() for n in solid]); lo=allb[:,:3].min(0)-5; hi=allb[:,3:].max(0)+5
bad=0;placed=[]
for n in order:
    poses=[np.array(p) for p in A['paths'][n]]
    ok=True
    if not(2<=len(poses)<=1500): ok=False;print(n,'len',len(poses))
    for p in poses:
        R=p[:3,:3]
        if not np.isfinite(p).all() or np.abs(R.T@R-np.eye(3)).max()>1e-6 or abs(np.linalg.det(R)-1)>1e-6 or np.abs(p[3]-[0,0,0,1]).max()>1e-6: ok=False;print(n,'bad matrix')
    if np.abs(poses[-1]-np.eye(4)).max()>1e-6: ok=False;print(n,'last not identity')
    V=K.verts(solid[n])
    W=lambda p:V@p[:3,:3].T+p[:3,3]
    w0=W(poses[0]); b0=np.r_[w0.min(0),w0.max(0)]
    if not any(b0[i]>=hi[i] or b0[i+3]<=lo[i] for i in range(3)): ok=False;print(n,'first pose not outside')
    for a,b in zip(poses[:-1],poses[1:]):
        if np.linalg.norm(W(a)-W(b),axis=1).max()>0.2: ok=False;print(n,'step too big');break
    worst=0
    for p in poses:
        m=solid[n].transform(p[:3,:4].tolist())
        for q in placed:
            v=K.ivol(m,solid[q])
            if v>worst: worst=v
    if worst>0.01: ok=False; print(n,'collision',worst)
    print(n,'ok' if ok else 'FAIL',len(poses),round(worst,5),flush=True)
    bad+= not ok; placed.append(n)
print('installed',len(order)-bad,'of',len(solid))
