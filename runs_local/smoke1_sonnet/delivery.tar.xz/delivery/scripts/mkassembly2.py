import sys,os,json,time
from wtests import *
mv=Mov('movement.json')
solid={}
for n in mv.fixed: solid[n]=part(n)
for k,v in mv.mparts.items():
    if k!='barrel':
        for p in v: solid[p]=part(p)
solid['barrel']=barrel()
allnames=list(solid)
bbs={n:np.array(solid[n].bounding_box()) for n in allnames}
lo=np.min([b[:3] for b in bbs.values()],0); hi=np.max([b[3:] for b in bbs.values()],0)
G=(lo-5.0,hi+5.0)
def disjoint(bb):
    return any(bb[i]>=G[1][i] or bb[i+3]<=G[0][i] for i in range(3))
STEP=0.1
def start_dist(n,d):
    bb=bbs[n]; s=0.0
    while True:
        sh=bb+np.array(list(np.array(d)*s)*2)
        if disjoint(sh): return s+STEP
        s+=0.5
def ang_of(a,b): return math.degrees(math.atan2(b[1]-a[1],b[0]-a[0]))
axes={k:np.array(v) for k,v in mv.axis.items()}
part_mob={}
for k,v in mv.mparts.items():
    for p in v: part_mob[p]=k
def candidates(n):
    c=[('down',(0,0,1)),('up',(0,0,-1))]
    angs=[]
    mo=part_mob.get(n)
    if mo and mo in axes:
        for k,ax in axes.items():
            if k!=mo:
                a=ang_of(axes[mo],ax); angs+= [a,a+180]
        for a in range(0,360,30): angs.append(a)
    for a in angs:
        r=math.radians(a); c.append(('h%.1f'%a,(math.cos(r),math.sin(r),0)))
    # dedupe
    return c
def check_path(n,d,placed,full=True):
    S=start_dist(n,d); k=int(math.ceil(S/STEP)); S=k*STEP*1.0
    dd=np.array(d,float)
    ss=range(k,-1,-1) if full else range(k,-1,-5)
    P=solid[n]
    for i in ss:
        off=dd*(S*i/k)
        bb=bbs[n]+np.tile(off,2)
        mv_=None
        for q in placed:
            bq=bbs[q]
            if bb[0]>=bq[3] or bq[0]>=bb[3] or bb[1]>=bq[4] or bq[1]>=bb[4] or bb[2]>=bq[5] or bq[2]>=bb[5]: continue
            if mv_ is None: mv_=P.translate(list(off))
            if K.ivol(mv_,solid[q])>0.004: return None
    return (S,k,dd)
def plan(order):
    placed=[];paths={};log=[]
    for n in order:
        ok=None
        for nm,d in candidates(n):
            r=check_path(n,d,placed,full=False)
            if r is None: continue
            r=check_path(n,d,placed,full=True)
            if r is not None: ok=(nm,r);break
        if ok is None: log.append((n,'NO PATH')); 
        else:
            nm,(S,k,dd)=ok
            poses=[]
            for i in range(k,-1,-1):
                T=np.eye(4); T[:3,3]=dd*(S*i/k); poses.append(T)
            poses[-1]=np.eye(4)
            paths[n]=[p.tolist() for p in poses]; log.append((n,nm,len(poses)))
        placed.append(n)
    return paths,log
if __name__=='__main__':
    order=sys.argv[1].split(',')
    t=time.time()
    paths,log=plan(order)
    for l in log: print(l,flush=True)
    json.dump({'order':order,'paths':paths},open(ROOT+'/delivery/assembly.json','w'))
    print('time',time.time()-t)
