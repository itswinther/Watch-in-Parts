"""2D/3D envelope layout of the calibre. Shared constants + random search for axis positions."""
import numpy as np, itertools, json, sys
ZB = 5.9          # bridge underside
LAYER = lambda k: (1.1+0.6*(k-1), 1.6+0.6*(k-1))
RA = 0.5          # arbor radius
def tip(m,z): return m*z/2+m
def pitch_r(m,z): return m*z/2

# mobile gear specs: name -> list of (gear_id, teeth, module, layer or (z0,z1))
GEARS = {
 'A8': [('Aw',24,0.2,(0.1,0.6)),('Ap',40,0.25,LAYER(1))],
 'A6': [('Aw',32,0.2,(0.1,0.6)),('Ap',40,0.25,LAYER(1))],
 'M':  [('Mg',20,0.25,LAYER(1)),('Mp',15,0.2,LAYER(2)),('Mg2',48,0.2,LAYER(3))],
 'I':  [('Iw',45,0.2,LAYER(2)),('Ip',12,0.2,LAYER(4))],
 'H':  [('Hw',48,0.2,LAYER(4)),('Hg',24,0.2,LAYER(5))],
 'J':  [('Jw',34,0.2,LAYER(5))],
 'D':  [('Dg',48,0.2,LAYER(5))],
 'X1': [('X1p',12,0.2,LAYER(3)),('X1w',36,0.2,LAYER(6))],
 'X2': [('X2p',12,0.2,LAYER(6)),('X2w',30,0.2,LAYER(7))],
 'X3': [('X3p',12,0.2,LAYER(7)),('X3w',24,0.2,LAYER(8))],
 'S':  [('Sp',12,0.2,LAYER(8))],
}
# meshes: (driver, gear, driven, gear)
MESH = [('A8','Ap','M','Mg'),('M','Mp','I','Iw'),('I','Ip','H','Hw'),('H','Hg','J','Jw'),('J','Jw','D','Dg'),
        ('M','Mg2','X1','X1p'),('X1','X1w','X2','X2p'),('X2','X2w','X3','X3p'),('X3','X3w','S','Sp')]
def dist(name_a,ga,name_b,gb):
    f=lambda n,g:[x for x in GEARS[n] if x[0]==g][0]
    a=f(name_a,ga);b=f(name_b,gb)
    assert a[2]==b[2] or True
    return (pitch_r(a[2],a[1])+pitch_r(b[2],b[1]))
HAND_LEN={'S':5.2,'D':3.2,'H':5.2,'M':7.5}
HAND_Z={'S':(6.6,7.0),'D':(7.3,7.7),'H':(8.0,8.4),'M':(8.7,9.1)}
STAFF_TOP={'S':7.2,'D':7.9,'H':8.6,'M':9.3}

def cylinders(name, ax):
    """list of (x,y,r,z0,z1,tag) of mobile `name` at axis ax"""
    x,y=ax; cs=[]
    top=STAFF_TOP.get(name, ZB+0.3)
    rr = 1.1 if name=='H' else RA
    cs.append((x,y,RA,-1.2,top,'arbor'))
    if name=='H': cs.append((x,y,1.1,2.85,STAFF_TOP['H'],'tube'))
    if name!='H': cs.append((x,y,1.0,0.0,0.5,'boss'))
    if name not in ('M','H','A8','A6','S'): cs.append((x,y,1.0,ZB-0.55,ZB-0.05,'collar'))
    if name in ('A8','A6'): cs.append((x,y,1.0,ZB-0.55,ZB-0.05,'collar'))
    if name=='H': cs.append((x,y,1.6,ZB-0.55,ZB-0.05,'collar'))
    for g,z,m,(z0,z1) in [(g[0],g[1],g[2],g[3]) for g in GEARS[name]]:
        cs.append((x,y,tip(m,z)+0.0,z0,z1,'gear:'+g))
    if name in HAND_LEN:
        z0,z1=HAND_Z[name]; cs.append((x,y,HAND_LEN[name]+0.3,z0,z1,'hand'))
    return cs

def clash(cs_a, cs_b, name_a, name_b, mesh_pairs, margin=0.15):
    for (x1,y1,r1,a0,a1,t1) in cs_a:
        for (x2,y2,r2,b0,b1,t2) in cs_b:
            if a1 <= b0-0.05 or b1 <= a0-0.05: continue
            d=np.hypot(x1-x2,y1-y2)
            if d < r1+r2+margin:
                if t1.startswith('gear:') and t2.startswith('gear:') and (t1[5:],t2[5:]) in mesh_pairs: continue
                return True
    return False

if __name__=='__main__':
    pass
