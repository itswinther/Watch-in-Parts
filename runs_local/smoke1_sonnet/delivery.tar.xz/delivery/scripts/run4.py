import sys,glob,os
from wtests import *
from multiprocessing import Pool
H=0.05; OFF=0.0113-0.025
def job(name):
    man=part(name); bb=man.bounding_box()
    lo=np.array(bb[:3])-0.3; hi=np.array(bb[3:])+0.3
    origin=np.floor((lo-OFF)/H)*H+OFF
    shape=tuple(int(v) for v in np.ceil((hi-origin)/H).astype(int)+1)
    n,dev=K.opening_test_slabs(man,tuple(origin),shape,H,1.5,1.0,4.0)
    return name,n,dev
if __name__=='__main__':
    names=sorted(os.path.basename(f)[:-5] for f in glob.glob(ROOT+'/delivery/parts/*.step'))
    with Pool(4) as p:
        for r in p.imap_unordered(job,names): print(r,flush=True)
