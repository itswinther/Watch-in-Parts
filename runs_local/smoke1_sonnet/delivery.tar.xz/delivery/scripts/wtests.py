import sys, os, json, math, itertools, time
import numpy as np
ROOT='/tmp/claude-0/runs/smoke1_sonnet/app'
sys.path.insert(0,ROOT+'/tools')
import kernel as K
import manifold3d as m3
from fractions import Fraction
LD,AD=0.001,0.1
_cache={}
import pickle,hashlib
def part(name):
    if name not in _cache:
        fp=f'{ROOT}/delivery/parts/{name}.step'
        h=hashlib.md5(open(fp,'rb').read()).hexdigest()
        cf=f'/tmp/claude-0/-tmp-claude-0-runs-smoke1-sonnet-app/c645ff9d-a47e-431f-995c-a3294ca0c3f2/scratchpad/cache/cache_{name}_{h}.pkl'
        if os.path.exists(cf): tris=pickle.load(open(cf,'rb'))
        else:
            tris=K.read_step(fp,16777216,200000,LD,AD,500,120,4096); pickle.dump(tris,open(cf,'wb'))
        _cache[name]=K.tris_to_part(tris,0.005)
    return _cache[name]
def barrel():
    if 'barrel' not in _cache:
        _cache['barrel']=K.tris_to_part(K.read_stl(ROOT+'/supplied/barrel.stl',10**7,10**9),0.005)
    return _cache['barrel']
def rotz(man,ax,deg):
    a=math.radians(deg); c,s=math.cos(a),math.sin(a)
    x,y=ax
    # p' = R(p-ax)+ax
    M=[[c,-s,0,x-c*x+s*y],[s,c,0,y-s*x-c*y],[0,0,1,0]]
    return man.transform(M)
def tr(man,d): return man.translate(list(d))
class Mov:
    def __init__(self,fn):
        self.j=json.load(open(f'{ROOT}/delivery/{fn}'))
        j=self.j
        self.fixed={n:part(n) for n in j['fixed']}
        self.frame=K.union(list(self.fixed.values()))
        self.mob={}
        self.axis={'barrel':(0.0,0.0)}
        self.mparts={'barrel':['barrel']}
        self.mob['barrel']=barrel()
        for k,v in j['mobiles'].items():
            self.mparts[k]=v['parts']; self.axis[k]=tuple(v['axis'])
            self.mob[k]=K.union([part(p) for p in v['parts']])
        self.meshes=j['meshes']
    def speeds(self,period_h):
        sp={'barrel':Fraction(1,period_h)}  # rev/h cw positive
        ch=True
        adj={}
        for m in self.meshes:
            adj.setdefault(m['driver'],[]).append((m['driven'],m['driver_teeth'],m['driven_teeth']))
            adj.setdefault(m['driven'],[]).append((m['driver'],m['driven_teeth'],m['driver_teeth']))
        st=['barrel']
        while st:
            a=st.pop()
            for b,za,zb in adj.get(a,[]):
                v=-sp[a]*Fraction(za,zb)
                if b in sp:
                    if sp[b]!=v: ch=False
                else: sp[b]=v; st.append(b)
        return sp,ch
def vol(a,b): return K.ivol(a,b)
def c2(mv):
    res=[]
    solids={'frame':mv.frame}; solids.update(mv.mob)
    for a,b in itertools.combinations(solids,2):
        v=vol(solids[a],solids[b])
        if v>0.01: res.append(('mobile-mobile',a,b,v))
    for a,b in itertools.combinations(mv.fixed,2):
        v=vol(mv.fixed[a],mv.fixed[b])
        if v>0.01: res.append(('fixed-fixed',a,b,v))
    for k,ps in mv.mparts.items():
        if k=='barrel': continue
        for a,b in itertools.combinations(ps,2):
            v=vol(part(a),part(b))
            if v>0.01: res.append(('in-mobile',a,b,v))
    # joined
    names=list(mv.fixed); adj={n:set() for n in names}
    for a,b in itertools.combinations(names,2):
        d=K.min_distance(mv.fixed[a],mv.fixed[b],0.02)
        if d<=0.01: adj[a].add(b); adj[b].add(a)
    seen={names[0]}; st=[names[0]]
    while st:
        x=st.pop()
        for y in adj[x]:
            if y not in seen: seen.add(y); st.append(y)
    if len(seen)!=len(names): res.append(('frame-not-joined',sorted(set(names)-seen)))
    return res
def check1(mv,step=5):
    bad=[]
    for k,m in mv.mob.items():
        worst=0;wa=None
        for i in range(0,72,max(1,step//5)):
            v=vol(rotz(m,mv.axis[k],5*i),mv.frame)
            if v>worst: worst=v;wa=5*i
        if worst>0.01: bad.append((k,worst,wa))
    return bad
def check2(mv):
    dirs=[(0.3,0,0),(-0.3,0,0),(0,0.3,0),(0,-0.3,0),(0,0,0.3),(0,0,-0.3)]
    held={}
    names=list(mv.mob)
    out={}
    for di,d in enumerate(dirs):
        hf={}; moved={k:tr(m,d) for k,m in mv.mob.items()}
        direct={k:vol(moved[k],mv.frame)>0.01 for k in names}
        h=dict(direct)
        ch=True
        while ch:
            ch=False
            for a in names:
                if h[a]: continue
                for b in names:
                    if a==b or not h[b]: continue
                    if math.hypot(mv.axis[a][0]-mv.axis[b][0],mv.axis[a][1]-mv.axis[b][1])<=0.01:
                        if vol(moved[a],mv.mob[b])>0.01: h[a]=True; ch=True; break
        for k in names: out.setdefault(k,[]).append(h[k])
    return {k:v for k,v in out.items() if not all(v)}
def check3(mv):
    bad=[]
    for k,ps in mv.mparts.items():
        if k=='barrel' or len(ps)<2: continue
        for p in ps:
            others=K.union([part(q) for q in ps if q!=p])
            P=part(p)
            for d in [(0.3,0,0),(-0.3,0,0),(0,0.3,0),(0,-0.3,0)]:
                v=vol(tr(P,d),others)
                if v<=0.01: bad.append((k,p,d,v))
            vz=[vol(tr(P,d),others) for d in [(0,0,0.3),(0,0,-0.3)]]
            if max(vz)<=0.01: bad.append((k,p,'z',vz))
        # chain
        n=len(ps); adj={p:[] for p in ps}
        for a,b in itertools.combinations(ps,2):
            if K.min_distance(part(a),part(b),0.03)<=0.02: adj[a].append(b);adj[b].append(a)
        seen={ps[0]};st=[ps[0]]
        while st:
            x=st.pop()
            for y in adj[x]:
                if y not in seen: seen.add(y);st.append(y)
        if len(seen)!=n: bad.append((k,'not one piece'))
    return bad
def mesh_test(D,N,axD,axN,zD,zN,off=0.0,stride=1,verbose=False):
    """returns (ok, info). D,N manifolds; off: move N along centre line by off (positive away)."""
    axD=np.array(axD);axN=np.array(axN)
    u=axN-axD; dist=np.hypot(*u)
    if dist<1e-9: u=np.array([1.0,0.0])
    else: u=u/dist
    axN2=axN+u*off
    if off!=0: N=tr(N,(u[0]*off,u[1]*off,0))
    m=2*dist/(zD+zN)
    nsteps=8*max(zD,zN)
    info={'maxint':0,'maxgap':0,'minV':1e9,'minVH':1e9,'fail':[]}
    def pose(x):
        a=x*360/(8*zD)
        d=rotz(D,axD,a); n=rotz(N,axN2,-a*zD/zN)
        return d,n
    idx=range(0,nsteps,stride)
    for i in idx:
        d,n=pose(i)
        v=vol(d,n)
        info['maxint']=max(info['maxint'],v)
        if v>0.01: info['fail'].append(('jam',i,v)); 
        if i%4==0 and v==0 :
            g=K.min_distance(d,n,0.2)
            info['maxgap']=max(info['maxgap'],g)
            if g>0.1: info['fail'].append(('gap',i,g))
        if i%8==0:
            for f in (1/3,1/5):
                dd,nn=pose(i+f); v2=vol(dd,nn); info['maxint']=max(info['maxint'],v2)
                if v2>0.01: info['fail'].append(('jam+',i+f,v2))
            # teeth drive
            d0=d
            d1=rotz(D,axD,i*360/(8*zD)+90/zD)
            reg=(d1^n)-d0
            V=reg.volume()
            if V<=0: info['fail'].append(('drive0',i,V)); info['minV']=min(info['minV'],V);continue
            bb=reg.bounding_box(); H=bb[5]-bb[2]
            info['minV']=min(info['minV'],V); info['minVH']=min(info['minVH'],V/H/(0.5*m*m))
            if V<0.001 or V/H<=0.5*m*m: info['fail'].append(('drive',i,V,V/H,0.5*m*m))
    return (len(info['fail'])==0),info
