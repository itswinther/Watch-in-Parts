import time,sys
from wtests import *
from multiprocessing import Pool
fn=sys.argv[1]; stride=int(sys.argv[2])
def job(args):
    idx,off=args
    mv=Mov(fn); m=mv.meshes[idx]
    D=mv.mob[m['driver']];N=mv.mob[m['driven']]
    t=time.time()
    ok,info=mesh_test(D,N,mv.axis[m['driver']],mv.axis[m['driven']],m['driver_teeth'],m['driven_teeth'],off=off,stride=stride)
    return idx,off,ok,{k:(v if k!='fail' else v[:3]) for k,v in info.items()},time.time()-t
if __name__=='__main__':
    mv=Mov(fn)
    jobs=[(i,o) for i in range(len(mv.meshes)) for o in (0.0,0.03,-0.03)]
    with Pool(4) as p:
        for r in p.imap_unordered(job,jobs): print(r,flush=True)
