import time,sys
from wtests import *
from multiprocessing import Pool
fn=sys.argv[1]; per=int(sys.argv[2])
def centroid(man):
    m=man.to_mesh(); v=np.asarray(m.vert_properties)[:,:3].astype(float); t=np.asarray(m.tri_verts)
    a,b,c=v[t[:,0]],v[t[:,1]],v[t[:,2]]
    vv=np.einsum('ij,ij->i',a,np.cross(b,c))/6.0
    cen=(a+b+c)/4.0
    return (vv[:,None]*cen).sum(0)/vv.sum()
def pair_job(args):
    a,b=args
    mv=Mov(fn); sp,_=mv.speeds(per)
    wa,wb=float(sp[a]),float(sp[b])   # cw rev/h
    A,B=mv.mob[a],mv.mob[b]; ax,bx=mv.axis[a],mv.axis[b]
    worst=0
    wf=max(abs(wa),abs(wb))
    for k in range(145):
        f=k/144.0
        # faster does one full turn
        aa=-360*f*wa/wf; bb=-360*f*wb/wf
        v=vol(rotz(A,ax,aa),rotz(B,bx,bb)); worst=max(worst,v)
    if wa!=wb:
        rel=wa-wb
        for k in range(145):
            f=k/144.0
            aa=-360*f*wa/abs(rel); bb=-360*f*wb/abs(rel)
            v=vol(rotz(A,ax,aa),rotz(B,bx,bb)); worst=max(worst,v)
    return a,b,worst
if __name__=='__main__':
    mv=Mov(fn); sp,ch=mv.speeds(per)
    print('consistent',ch); print({k:str(v) for k,v in sp.items()})
    j=mv.j
    # hands
    for h,e in j['hands'].items():
        print(h,e,'speed rev/h',sp[e['mobile']])
    # 11
    top=max(K.verts(f)[:,2].max() for f in mv.fixed.values())
    print('frame top',top)
    for h,e in j['hands'].items():
        P=part(e['part']); ax=mv.axis[e['mobile']]
        vs=K.verts(P); r=np.hypot(vs[:,0]-ax[0],vs[:,1]-ax[1]).max(); cen=centroid(P)
        print(h,'reach',r,'low z',vs[:,2].min(),'centroid dist',np.hypot(cen[0]-ax[0],cen[1]-ax[1]))
    ha=mv.axis[j['hands']['hour']['mobile']]; da=mv.axis[j['hands']['day']['mobile']]
    print('day-hour dist',np.hypot(ha[0]-da[0],ha[1]-da[1]),'min-hour', np.hypot(*(np.array(mv.axis[j['hands']['minute']['mobile']])-np.array(ha))))
    # 12
    cc=np.array(j['case_centre']); mx=0
    for f in mv.fixed.values():
        vs=K.verts(f); mx=max(mx,np.hypot(vs[:,0]-cc[0],vs[:,1]-cc[1]).max())
    print('fixed max r',mx)
    for k,m in mv.mob.items():
        ax=np.array(mv.axis[k]); vs=K.verts(m); r=np.hypot(vs[:,0]-ax[0],vs[:,1]-ax[1]).max()
        print(k,'r',round(r,3),'total',round(r+np.hypot(*(ax-cc)),3))
    zs=[K.verts(m)[:,2] for m in list(mv.mob.values())+list(mv.fixed.values())]
    print('z range',min(z.min() for z in zs),max(z.max() for z in zs))
    meshpairs={frozenset((m['driver'],m['driven'])) for m in mv.meshes}
    prs=[(a,b) for a,b in itertools.combinations(mv.mob,2) if frozenset((a,b)) not in meshpairs]
    with Pool(4) as p:
        for r in p.imap_unordered(pair_job,prs):
            if r[2]>0.005: print('PAIR',r)
    print('check6 done')
