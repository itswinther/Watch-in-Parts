"""Plans assembly.json for movement.json: every part is lowered straight down along -z into place,
in an order found by trying each remaining part and keeping the first whose drop hits nothing placed."""
import json
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import verify          # noqa: E402
import kernel          # noqa: E402

STEP = 0.19
TOL = 0.01


def drop_path(start_dz):
    n = int(np.ceil(start_dz / STEP))
    zs = np.linspace(start_dz, 0.0, n + 1)
    return [np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, z], [0, 0, 0, 1]], float) for z in zs]


def check_path(P, path, placed, parts):
    for T in path:
        Pm = kernel.apply(P, T)
        for q in placed:
            if kernel.ivol(Pm, parts[q]) > TOL:
                return q, float(T[2, 3])
    return None


def main():
    mv = verify.Mv("movement.json")
    parts = mv.parts
    names = list(parts)                     # fixed, barrel, mobile parts
    bbs = np.array([parts[n].bounding_box() for n in names])
    lo, hi = bbs[:, :3].min(0) - 5, bbs[:, 3:].max(0) + 5
    first = ["main_plate", "barrel", "intermediate_arbor", "deck", "intermediate_wheel_8h"]
    later_fixed = ["bridge"]
    hands = ["day_hand", "seconds_hand", "hour_hand", "minute_hand"]
    middle = [n for n in names if n not in first + later_fixed + hands]
    order, paths = [], {}

    def place(n):
        b = parts[n].bounding_box()
        dz = hi[2] - b[2] + 0.5          # first pose: wholly above the grown box
        path = drop_path(dz)
        hit = check_path(parts[n], path, order, parts)
        return path, hit
    for n in first:
        path, hit = place(n)
        if hit:
            raise RuntimeError("%s hits %s" % (n, hit))
        order.append(n)
        paths[n] = path
    # blocks[y] = parts that, once placed, stop y's drop: y must go before them
    blocks = {}
    for y in middle:
        b = parts[y].bounding_box()
        path = drop_path(hi[2] - b[2] + 0.5)
        blocks[y] = set()
        for x in middle:
            if x != y and check_path(parts[y], path, [x], parts):
                blocks[y].add(x)
        if check_path(parts[y], path, order, parts):
            raise RuntimeError("%s blocked by the first parts" % y)
    todo = list(middle)
    while todo:
        # a part can go now if no part still to be placed must precede it, i.e. no t in todo with n in blocks[t]
        ready = [n for n in todo if not any(n in blocks[t] for t in todo if t != n)]
        if not ready:
            raise RuntimeError("cyclic order %s" % {t: sorted(blocks[t]) for t in todo})
        n = ready[0]
        path, hit = place(n)
        assert not hit, (n, hit)
        order.append(n)
        paths[n] = path
        todo.remove(n)
        print("placed", n, flush=True)
    for n in later_fixed + hands:
        path, hit = place(n)
        if hit:
            raise RuntimeError("%s hits %s" % (n, hit))
        order.append(n)
        paths[n] = path
        print("placed", n, flush=True)
    doc = {"order": order, "paths": {n: [[[round(float(v), 6) for v in row] for row in T] for T in p]
                                     for n, p in paths.items()}}
    with open(os.path.join(verify.DELIV, "assembly.json"), "w") as f:
        json.dump(doc, f)
    print("order", order)
    print("poses", {n: len(p) for n, p in paths.items()})


if __name__ == "__main__":
    main()
