import json, sys, os, numpy as np
sys.path.insert(0,'.')
import verify, kernel
mv=verify.Mv('movement.json'); parts=mv.parts
a=json.load(open(os.path.join(verify.DELIV,'assembly.json')))
bbs=np.array([parts[n].bounding_box() for n in parts]); lo=bbs[:,:3].min(0)-5; hi=bbs[:,3:].max(0)+5
seen=[]; installed=0
for n in a['order']:
    if n not in parts or n in seen: continue
    P=a['paths'][n]; ok=True; why=''
    Ts=[np.array(T,float) for T in P]
    if not (2<=len(Ts)<=1500): ok=False; why='count'
    for T in Ts:
        R=T[:3,:3]
        if not (np.allclose(R.T@R,np.eye(3),atol=1e-6) and abs(np.linalg.det(R)-1)<1e-6 and np.allclose(T[3],[0,0,0,1],atol=1e-6)): ok=False; why='matrix'
    if not np.allclose(Ts[-1],np.eye(4),atol=1e-6): ok=False; why='last'
    b=kernel.apply(parts[n],Ts[0]).bounding_box()
    if not any(b[i+3]<lo[i] or b[i]>hi[i] for i in range(3)): ok=False; why='start inside'
    V=kernel.verts(parts[n]); Vh=np.c_[V,np.ones(len(V))]
    for T0,T1 in zip(Ts,Ts[1:]):
        if np.max(np.linalg.norm(Vh@(T1-T0).T,axis=1))>0.2: ok=False; why='step'; break
    for T in Ts:
        Pm=kernel.apply(parts[n],T)
        for q in seen:
            v=kernel.ivol(Pm,parts[q])
            if v>0.01: ok=False; why=('hit',q,v); break
        if not ok: break
    seen.append(n); installed+=ok
    if not ok: print('FAIL',n,why)
missing=[n for n in parts if n not in a['order']]
print('installed',installed,'of',len(parts),'missing',missing)
