"""Local re-implementation of the mesh test (instruction Part 1, check 4/5) on manifold3d solids."""
import math
import sys
import os
import numpy as np
import manifold3d as m3

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
import kernel  # noqa: E402


def rotz(man, deg, ax):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    x, y = ax
    # rotate about vertical line through (x, y)
    T = [[c, -s, 0, x - c * x + s * y], [s, c, 0, y - s * x - c * y], [0, 0, 1, 0]]
    return man.transform(T)


def extrude(poly, z0, z1):
    cs = m3.CrossSection([np.asarray(poly, float).tolist()])
    return m3.Manifold.extrude(cs, z1 - z0).translate([0, 0, z0])


def mesh_test(D, Dax, zD, N, Nax, zN, shift=0.0, drawn_dist=None, verbose=False, full=True):
    """Returns dict: ok, max_int, max_gap, min_ratio, min_V."""
    Dax = np.asarray(Dax, float)
    Nax0 = np.asarray(Nax, float)
    d = Nax0 - Dax
    dist = np.linalg.norm(d)
    u = d / dist if dist > 1e-9 else np.array([1.0, 0.0])
    Nax1 = Nax0 + shift * u
    Nm = N.translate([shift * u[0], shift * u[1], 0]) if shift else N
    m = 2 * dist / (zD + zN)
    nsteps = 8 * max(zD, zN)
    res = dict(max_int=0.0, max_gap=0.0, min_ratio=1e9, min_V=1e9, ok=True, fails=[])

    def pose(i):
        a = i * 360.0 / (8 * zD)
        return rotz(D, a, Dax), rotz(Nm, -a * zD / zN, Nax1)
    steps = range(nsteps) if full else range(0, nsteps, 8)
    for i in steps:
        Di, Ni = pose(i)
        v = kernel.ivol(Di, Ni)
        res["max_int"] = max(res["max_int"], v)
        if v > 0.01:
            res["ok"] = False
            res["fails"].append(("jam", i, v))
        if i % 4 == 0 and v == 0.0:
            g = float(Di.min_gap(Ni, 1.0))
            res["max_gap"] = max(res["max_gap"], g)
            if g > 0.1:
                res["ok"] = False
                res["fails"].append(("gap", i, g))
        if i % 8 == 0:
            for f in (1 / 3, 1 / 5):
                Df, Nf = pose(i + f)
                v2 = kernel.ivol(Df, Nf)
                res["max_int"] = max(res["max_int"], v2)
                if v2 > 0.01:
                    res["ok"] = False
                    res["fails"].append(("jam+", i + f, v2))
            Dx = rotz(Di, 90.0 / zD, Dax)
            reg = (Dx - Di) ^ Ni
            V = reg.volume()
            if V > 0:
                bb = reg.bounding_box()
                H = bb[5] - bb[2]
                ratio = V / H / (m * m)
            else:
                ratio = 0.0
            res["min_ratio"] = min(res["min_ratio"], ratio)
            res["min_V"] = min(res["min_V"], V)
            if V < 0.001 or ratio <= 0.5:
                res["ok"] = False
                res["fails"].append(("drive", i, V, ratio))
        if verbose and i % 64 == 0:
            print(i, res["max_int"], res["max_gap"], res["min_ratio"])
    return res
