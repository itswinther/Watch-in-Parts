"""Builds every part (STEP), movement.json, variant_6h.json. Run from this folder."""
import json
import math
import os
import sys
import numpy as np
import cadquery as cq

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel          # noqa: E402
import gearlib         # noqa: E402
import layout as L     # noqa: E402
import phase           # noqa: E402
import bl              # noqa: E402

DELIV = os.path.join(APP, "delivery")
PARTS = os.path.join(DELIV, "parts")

# ---------------- radii / z of the common arbor ----------------
PIV_R, PIV_HOLE = 0.30, 0.35      # pivots and their holes
BODY_R = 0.45
DZ0 = L.DECK[1] + 0.1             # body bottom (1.8)
BZ0 = L.BRIDGE[0] - 0.1           # body top (4.5)
PIV_LO = (L.DECK[1] - 0.35, DZ0)  # bottom pivot in the deck's blind hole
DECK_BLIND = (L.DECK[1] - 0.45, L.DECK[1])
PIV_HI = (BZ0, L.BRIDGE[1] - 0.1)
M_UP_R = 0.25                     # minute arbor inside the hour pipe
H_BORE = 0.30
H_PIPE = 0.80
H_PIPE_HOLE = 0.85
A_LOW_R, A_LOW_HOLE = 0.30, 0.35  # A pivot in the main plate
A_MID_R, A_DECK_HOLE = 0.45, 0.50
A_UP_R, A_UP_HOLE = 0.35, 0.40
BARREL_HOLE = 0.60
HAND_SEAT = 0.25                  # depth of the bore that seats a hand on its arbor

HAND_LEN = {"minute": 7.5, "hour": 5.4, "seconds": 5.6, "day": 3.6}
HAND_ANG = {"minute": 50.0, "hour": 160.0, "seconds": 250.0, "day": 20.0}


def wp(z0):
    return cq.Workplane("XY").workplane(offset=z0)


def cyl(c, r, z0, z1):
    return wp(z0).center(float(c[0]), float(c[1])).circle(r).extrude(z1 - z0)


def ring(c, r0, r1, z0, z1):
    return wp(z0).center(float(c[0]), float(c[1])).circle(r1).circle(r0).extrude(z1 - z0)


def prism(poly, z0, z1):
    pts = [(float(x), float(y)) for x, y in poly]
    return wp(z0).polyline(pts).close().extrude(z1 - z0)


def one_solid(w):
    v = w.val()
    if isinstance(v, cq.Compound) or v.ShapeType() != "Solid":
        sol = w.solids().vals()
        if len(sol) != 1:
            raise RuntimeError("not one solid: %d" % len(sol))
        v = sol[0]
    return v


# ---------------- phases ----------------
def tooth_s(mob, gear):
    return L.S_P1 if (mob, gear) == ("A", "p1") else L.S_OWN


def compute_phases(build):
    """phase (deg) of tooth 0 of every gear, and eps used, following the meshes from the barrel."""
    G = L.gears(build)
    ph = {("barrel", None): 0.0}
    eps_used = {}
    t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 7, 10 ** 9)
    Bcs = kernel.tris_to_part(t, 0.005).slice(0.5)
    for dr, dg, zd, dn, ng, zn in L.meshes(build):
        Dax = L.O if dr == "barrel" else L.AX[dr]
        Nax = L.AX[dn]
        if (dr, dg) not in ph:
            ph[(dr, dg)] = 0.0
        beta = math.degrees(math.atan2(Nax[1] - Dax[1], Nax[0] - Dax[0]))
        if dr == "barrel":
            Dcs = Bcs
        else:
            Dcs = bl.cs(gearlib.gear_profile(zd, L.M, L.ALPHA, s=tooth_s(dr, dg), phase_deg=ph[(dr, dg)], centre=Dax))
        p0 = phase.driven_phase(beta, ph[(dr, dg)], zd, zn, 0.0)
        Ncs = bl.cs(gearlib.gear_profile(zn, L.M, L.ALPHA, s=tooth_s(dn, ng), phase_deg=p0, centre=Nax))
        r = bl.backlash(Dcs, Dax, Ncs, Nax, zd, zn, shift=-0.03, steps=4)
        hi = min(b for a, b in r)
        lo = max(a for a, b in r)
        eps = lo + 0.62 * (hi - lo)
        eps_used[(dr, dn)] = (round(lo, 4), round(hi, 4), round(eps, 4))
        ph[(dn, ng)] = p0 + eps
    return ph, eps_used


def gear_prism(build, ph, mob, gear, z, lay_z):
    poly = gearlib.gear_profile(z, L.M, L.ALPHA, s=tooth_s(mob, gear), phase_deg=ph[(mob, gear)], centre=L.AX[mob])
    return prism(poly, *lay_z)


# ---------------- parts ----------------
def standard_arbor(mob, top):
    c = L.AX[mob]
    w = cyl(c, PIV_R, PIV_LO[0], PIV_LO[1])
    w = w.union(cyl(c, BODY_R, DZ0, BZ0))
    w = w.union(cyl(c, PIV_R, BZ0, top))
    return w


def part_mobile(build, ph, mob):
    G = L.gears(build)[mob]
    if mob in ("S", "D"):
        hz = L.HANDZ["seconds" if mob == "S" else "day"]
        top = hz[0] + HAND_SEAT
    else:
        top = PIV_HI[1]
    w = standard_arbor(mob, top)
    for name, z, lay in G:
        w = w.union(gear_prism(build, ph, mob, name, z, L.LAYERS[lay]))
    return one_solid(w)


def part_M(build, ph):
    c = L.AX["M"]
    G = dict((n, (z, l)) for n, z, l in L.gears(build)["M"])
    top_cannon = L.LAYERS[G["cannon"][1]][1]
    w = cyl(c, PIV_R, PIV_LO[0], PIV_LO[1])
    w = w.union(cyl(c, BODY_R, DZ0, top_cannon))
    w = w.union(cyl(c, M_UP_R, top_cannon, L.HANDZ["minute"][0] + HAND_SEAT))
    for name, (z, lay) in G.items():
        w = w.union(gear_prism(build, ph, "M", name, z, L.LAYERS[lay]))
    return one_solid(w)


def part_H(build, ph):
    c = L.AX["H"]
    z, lay = [(z, l) for n, z, l in L.gears(build)["H"] if n == "Wh"][0]
    lz = L.LAYERS[lay]
    w = gear_prism(build, ph, "H", "Wh", z, lz)
    w = w.union(cyl(c, H_PIPE, lz[0], L.HANDZ["hour"][0] + HAND_SEAT))
    w = w.cut(cyl(c, H_BORE, lz[0] - 1, L.HANDZ["hour"][1] + 1))
    return one_solid(w)


def part_A_lower(ph):
    c = L.AX["A"]
    w = cyl(c, A_LOW_R, L.PLATE[0] + 0.3, 0.0)
    w = w.union(prism(gearlib.gear_profile(24, L.M, L.ALPHA, s=L.S_P1, phase_deg=ph[("A", "p1")], centre=c), 0.0, 1.0))
    w = w.union(cyl(c, A_MID_R, 1.0, L.LAYERS[1][0]))
    w = w.union(cyl(c, A_UP_R, L.LAYERS[1][0], PIV_HI[1]))
    return one_solid(w)


def part_A_upper(build, ph):
    c = L.AX["A"]
    z = [z for n, z, l in L.gears(build)["A"] if n == "W2"][0]
    w = gear_prism(build, ph, "A", "W2", z, L.LAYERS[1])
    w = w.cut(cyl(c, A_UP_R, L.LAYERS[1][0] - 1, L.LAYERS[1][1] + 1))
    return one_solid(w)


def hand(kind, c, bore_r, hub_r, cbore=None):
    z0, z1 = L.HANDZ[kind]
    ln, a = HAND_LEN[kind], math.radians(HAND_ANG[kind])
    wdt = 0.55 if kind in ("hour", "minute") else 0.45
    u = np.array([math.cos(a), math.sin(a)])
    n = np.array([-u[1], u[0]])
    c = np.asarray(c, float)
    tail = 0.0
    pts = [c - tail * u + n * wdt / 2, c + (ln - 0.4) * u + n * wdt / 2, c + ln * u,
           c + (ln - 0.4) * u - n * wdt / 2, c - tail * u - n * wdt / 2]
    w = prism(pts, z0, z1).union(cyl(c, hub_r, z0, z1))
    if cbore is None:
        w = w.cut(cyl(c, bore_r, z0 - 1, z0 + HAND_SEAT))
    else:
        w = w.cut(cyl(c, bore_r, z0 - 1, z1 + 1))
        w = w.cut(cyl(c, cbore, z0 - 1, z0 + HAND_SEAT))
    return one_solid(w)


def mobiles_above_deck():
    return ["M", "MW", "I", "D", "T1", "T2", "T3", "S"]


def part_mainplate():
    w = cyl(L.Q, L.RING[1], L.PLATE[0], L.PLATE[1])
    w = w.union(ring(L.Q, L.RING[0], L.RING[1], L.PLATE[1], L.DECK[0]))
    w = w.cut(cyl(L.O, BARREL_HOLE, L.PLATE[0] - 1, L.PLATE[1] + 0.01))
    w = w.cut(cyl(L.AX["A"], A_LOW_HOLE, L.PLATE[0] - 1, L.PLATE[1] + 0.01))
    return one_solid(w)


def part_deck():
    w = cyl(L.Q, L.RING[1], L.DECK[0], L.DECK[1])
    w = w.union(ring(L.Q, L.RING[0], L.RING[1], L.DECK[1], L.BRIDGE[0]))
    w = w.cut(cyl(L.O, BARREL_HOLE, L.DECK[0] - 1, L.DECK[1] + 1))
    w = w.cut(cyl(L.AX["A"], A_DECK_HOLE, L.DECK[0] - 1, L.DECK[1] + 1))
    for mob in mobiles_above_deck():
        w = w.cut(cyl(L.AX[mob], PIV_HOLE, DECK_BLIND[0], DECK_BLIND[1] + 0.01))
    return one_solid(w)


def part_bridge():
    w = cyl(L.Q, L.RING[1], L.BRIDGE[0], L.BRIDGE[1])
    w = w.cut(cyl(L.AX["A"], A_UP_HOLE, L.BRIDGE[0] - 1, L.BRIDGE[1] + 1))
    w = w.cut(cyl(L.AX["H"], H_PIPE_HOLE, L.BRIDGE[0] - 1, L.BRIDGE[1] + 1))
    for mob in mobiles_above_deck():
        if mob == "M":
            continue
        w = w.cut(cyl(L.AX[mob], PIV_HOLE, L.BRIDGE[0] - 1, L.BRIDGE[1] + 1))
    return one_solid(w)


# ---------------- names ----------------
MOB_NAMES = {"A": "intermediate", "M": "centre", "H": "hour", "MW": "minute_wheel", "I": "day_idler",
             "D": "day", "T1": "third", "T2": "fourth", "T3": "fifth", "S": "seconds"}


def build_all(only=None):
    os.makedirs(PARTS, exist_ok=True)
    out = {}
    docs = {}
    eps_all = {}
    for build in ("8h", "6h"):
        ph, eps = compute_phases(build)
        eps_all[build] = eps
        parts = {}                                   # name -> (shape-thunk)
        mob_parts = {}
        sfx = "_" + build
        parts["main_plate"] = part_mainplate
        parts["deck"] = part_deck
        parts["bridge"] = part_bridge
        parts["intermediate_arbor"] = lambda ph=ph: part_A_lower(ph)
        parts["intermediate_wheel" + sfx] = lambda ph=ph, b=build: part_A_upper(b, ph)
        mob_parts["A"] = ["intermediate_arbor", "intermediate_wheel" + sfx]
        parts["centre_arbor" + sfx] = lambda ph=ph, b=build: part_M(b, ph)
        parts["minute_hand"] = lambda: hand("minute", L.AX["M"], M_UP_R, 0.6)
        mob_parts["M"] = ["centre_arbor" + sfx, "minute_hand"]
        parts["hour_wheel"] = lambda ph=ph, b=build: part_H(b, ph)
        parts["hour_hand"] = lambda: hand("hour", L.AX["H"], H_BORE, 1.15, cbore=H_PIPE)
        mob_parts["H"] = ["hour_wheel", "hour_hand"]
        for mob in ("MW", "I", "D", "T1", "T2", "T3", "S"):
            nm = MOB_NAMES[mob] + "_mobile"
            parts[nm] = lambda ph=ph, b=build, mob=mob: part_mobile(b, ph, mob)
            mob_parts[mob] = [nm]
        parts["seconds_hand"] = lambda: hand("seconds", L.AX["S"], PIV_R, 0.6)
        mob_parts["S"].append("seconds_hand")
        parts["day_hand"] = lambda: hand("day", L.AX["D"], PIV_R, 0.6)
        mob_parts["D"].append("day_hand")
        for n, f in parts.items():
            if n in out:
                continue
            if only is not None and n not in only:
                out[n] = None
                continue
            shp = f()
            kernel.write_step(os.path.join(PARTS, n + ".step"), shp)
            out[n] = True
            print("wrote", n, flush=True)
        doc = {
            "case_centre": [float(L.Q[0]), float(L.Q[1])],
            "fixed": ["main_plate", "deck", "bridge"],
            "mobiles": {MOB_NAMES[m]: {"axis": [float(L.AX[m][0]), float(L.AX[m][1])], "parts": mob_parts[m]}
                        for m in ("A", "M", "H", "MW", "I", "D", "T1", "T2", "T3", "S")},
            "meshes": [{"driver": "barrel" if dr == "barrel" else MOB_NAMES[dr], "driver_teeth": zd,
                        "driven": MOB_NAMES[dn], "driven_teeth": zn} for dr, dg, zd, dn, ng, zn in L.meshes(build)],
            "hands": {"hour": {"mobile": "hour", "part": "hour_hand"},
                      "minute": {"mobile": "centre", "part": "minute_hand"},
                      "seconds": {"mobile": "seconds", "part": "seconds_hand"},
                      "day": {"mobile": "day", "part": "day_hand"}},
        }
        docs[build] = doc
    with open(os.path.join(DELIV, "movement.json"), "w") as f:
        json.dump(docs["8h"], f, indent=1)
    with open(os.path.join(DELIV, "variant_6h.json"), "w") as f:
        json.dump(docs["6h"], f, indent=1)
    print(json.dumps({b: {"%s->%s" % k: v for k, v in e.items()} for b, e in eps_all.items()}, indent=1))


if __name__ == "__main__":
    build_all(set(sys.argv[1:]) or None)
