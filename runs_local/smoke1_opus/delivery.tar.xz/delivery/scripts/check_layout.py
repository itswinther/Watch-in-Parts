import sys, math, itertools, numpy as np
sys.path.insert(0,'.')
import layout as L
ARB=0.45
def radii(build):
    G=L.gears(build); out={}
    for mob,gl in G.items():
        d={}
        for name,z,lay in gl: d[lay]=(L.M*z/2+L.M, name)
        out[mob]=d
    return out
def check(build):
    R=radii(build); ms=L.meshes(build); bad=[]
    meshpairs={}
    for dr,dg,zd,dn,ng,zn in ms:
        if dr=='barrel': continue
        lay=[l for n,z,l in L.gears(build)[dr] if n==dg][0]
        meshpairs[frozenset((dr,dn))]=lay
        dist=np.linalg.norm(L.AX[dr]-L.AX[dn]); want=L.cd(zd,zn)
        if abs(dist-want)>1e-9: bad.append(('cd',dr,dn,dist,want))
    mobs=list(R)
    for X,Y in itertools.combinations(mobs,2):
        if {X,Y}=={'M','H'}: continue
        dist=np.linalg.norm(L.AX[X]-L.AX[Y])
        for lay in (1,2,3,4):
            if meshpairs.get(frozenset((X,Y)))==lay: continue
            rx=R[X].get(lay,(ARB,'arb'))[0] if not (X=='H' and lay<4) else (ARB if X=='H' else 0)
            ry=R[Y].get(lay,(ARB,'arb'))[0] if not (Y=='H' and lay<4) else 0
            if X=='H' and lay<4: rx=0
            if X=='A' and lay>1: rx=0.35
            if Y=='A' and lay>1: ry=0.35
            if dist < rx+ry+0.15: bad.append(('overlap',X,Y,lay,round(dist,3),round(rx+ry+0.15,3)))
    for X in mobs:
        rm=max(r for r,_ in R[X].values())
        if np.linalg.norm(L.AX[X]-L.Q)+rm>L.RING[0]-0.15: bad.append(('case',X))
    dSC=np.linalg.norm(L.AX['S']-L.C); dDC=np.linalg.norm(L.AX['D']-L.C); dDS=np.linalg.norm(L.AX['D']-L.AX['S'])
    print(build,'S-C',round(dSC,2),'D-C',round(dDC,2),'D-S',round(dDS,2),'S-Q+5.5',round(np.linalg.norm(L.AX['S']-L.Q)+5.5,2))
    return bad
for b in ('8h','6h'):
    for x in check(b): print(x)
for k,v in L.AX.items(): print(k, np.round(v,3), round(float(np.linalg.norm(v-L.C)),3))
