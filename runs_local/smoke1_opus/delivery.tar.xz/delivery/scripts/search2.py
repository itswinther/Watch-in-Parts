import sys, itertools, numpy as np, io, contextlib
sys.path.insert(0,'.')
with contextlib.redirect_stdout(io.StringIO()):
    import layout as L, check_layout as CL
def slack(build, detail=False):
    R=CL.radii(build); mp={}
    for dr,dg,zd,dn,ng,zn in L.meshes(build):
        if dr!='barrel': mp[frozenset((dr,dn))]=[l for n,z,l in L.gears(build)[dr] if n==dg][0]
    out=[]
    for X,Y in itertools.combinations(list(R),2):
        if {X,Y}=={'M','H'}: continue
        dist=np.linalg.norm(L.AX[X]-L.AX[Y])
        for lay in (1,2,3,4):
            if mp.get(frozenset((X,Y)))==lay: continue
            def rr(Z):
                if Z=='H' and lay<4: return 0
                if Z=='A' and lay>1: return 0.35
                return R[Z].get(lay,(0.45,))[0]
            out.append((dist-rr(X)-rr(Y)-0.15,X,Y,lay))
    for X in R:
        rm=max(r for r,*_ in R[X].values())
        out.append((L.RING[0]-0.15-np.linalg.norm(L.AX[X]-L.Q)-rm,X,'ring',0))
    out.sort()
    return out if detail else out[0][0]
if __name__=='__main__':
    best=[]
    for a_i in range(40,100,6):
      for a_d in range(-60,61,15):
        L.AX["I"] = L.polar(L.C, L.cd(48, 32), L.ang_A + a_i)
        L.AX["D"] = L.polar(L.AX["I"], L.cd(12, 36), L.ang_A + a_i + a_d)
        if np.linalg.norm(L.AX['D']-L.C)<7: continue
        best.append((round(min(slack('8h'),slack('6h')),3),a_i,a_d))
    best.sort(reverse=True); print(best[:5])
