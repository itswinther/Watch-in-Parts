"""Local re-implementation of the acceptance checks (as read from the instruction), for self-checking.
usage: python3 verify.py movement.json|variant_6h.json [checks...]"""
import json
import math
import os
import sys
import itertools
from fractions import Fraction as F
import numpy as np
import manifold3d as m3

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.abspath(os.path.join(HERE, "..", ".."))
DELIV = os.path.join(APP, "delivery")
CACHE = os.path.join(APP, "work", "vcache")
sys.path.insert(0, os.path.join(APP, "tools"))
sys.path.insert(0, HERE)
import kernel          # noqa: E402
import meshsim         # noqa: E402

TOL = 0.01


def load(name):
    if name == "barrel":
        t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 7, 10 ** 9)
        return kernel.tris_to_part(t, 0.005)
    p = os.path.join(DELIV, "parts", name + ".step")
    os.makedirs(CACHE, exist_ok=True)
    c = os.path.join(CACHE, name + ".npz")
    if os.path.exists(c) and os.path.getmtime(c) > os.path.getmtime(p):
        d = np.load(c)
        return m3.Manifold(m3.Mesh(vert_properties=d["v"], tri_verts=d["t"]))
    man = kernel.load_step_part(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096, 0.005)
    mesh = man.to_mesh()
    np.savez(c, v=np.asarray(mesh.vert_properties, np.float32), t=np.asarray(mesh.tri_verts, np.uint32))
    return man


class Mv:
    def __init__(self, fn):
        self.doc = json.load(open(os.path.join(DELIV, fn)))
        self.fn = fn
        d = self.doc
        self.parts = {}
        for n in d["fixed"]:
            self.parts[n] = load(n)
        self.mob_parts = {"barrel": ["barrel"]}
        self.axis = {"barrel": np.array([0.0, 0.0])}
        self.parts["barrel"] = load("barrel")
        for k, m in d["mobiles"].items():
            self.mob_parts[k] = m["parts"]
            self.axis[k] = np.array(m["axis"], float)
            for n in m["parts"]:
                self.parts[n] = load(n)
        self.frame = kernel.union([self.parts[n] for n in d["fixed"]])
        self.mob = {k: kernel.union([self.parts[n] for n in v]) for k, v in self.mob_parts.items()}
        self.barrel_period = 8 if fn == "movement.json" else 6

    def speeds(self, only_ok=None):
        """rev/h, signed (+ = CCW), as Fractions; None for unreached; 'conflict' flags."""
        sp = {"barrel": F(-1, self.barrel_period)}
        conflict = False
        changed = True
        meshes = self.doc["meshes"] if only_ok is None else [e for i, e in enumerate(self.doc["meshes"]) if only_ok[i]]
        while changed:
            changed = False
            for e in meshes:
                a, b = e["driver"], e["driven"]
                for x, y, zx, zy in ((a, b, e["driver_teeth"], e["driven_teeth"]), (b, a, e["driven_teeth"], e["driver_teeth"])):
                    if x in sp:
                        v = -sp[x] * zx / zy
                        if y not in sp:
                            sp[y] = v
                            changed = True
                        elif sp[y] != v:
                            conflict = True
        return sp, conflict


def rot(man, deg, ax):
    return meshsim.rotz(man, deg, ax)


def c2(mv):
    bad = []
    names = list(mv.mob)
    solids = [("frame", mv.frame)] + [(k, mv.mob[k]) for k in names]
    for (a, A), (b, B) in itertools.combinations(solids, 2):
        v = kernel.ivol(A, B)
        if v > TOL:
            bad.append(("solid-int", a, b, v))
    fx = mv.doc["fixed"]
    for a, b in itertools.combinations(fx, 2):
        v = kernel.ivol(mv.parts[a], mv.parts[b])
        if v > TOL:
            bad.append(("fixed-int", a, b, v))
    for k, ps in mv.mob_parts.items():
        for a, b in itertools.combinations(ps, 2):
            v = kernel.ivol(mv.parts[a], mv.parts[b])
            if v > TOL:
                bad.append(("mob-int", a, b, v))
    # frame connectivity
    joined = {fx[0]}
    changed = True
    while changed:
        changed = False
        for n in fx:
            if n in joined:
                continue
            if any(kernel.min_distance(mv.parts[n], mv.parts[j], 1.0) <= TOL for j in joined):
                joined.add(n)
                changed = True
    if len(joined) != len(fx):
        bad.append(("frame-not-joined", sorted(set(fx) - joined)))
    return bad


def free_turn(mv):
    bad = []
    for k, S in mv.mob.items():
        for i in range(72):
            v = kernel.ivol(rot(S, 5 * i, mv.axis[k]), mv.frame)
            if v > TOL:
                bad.append((k, 5 * i, v))
                break
    return bad


DIRS = [(0.3, 0, 0), (-0.3, 0, 0), (0, 0.3, 0), (0, -0.3, 0), (0, 0, 0.3), (0, 0, -0.3)]


def held(mv):
    bad = []
    for d in DIRS:
        held = set()
        moved = {k: S.translate(list(d)) for k, S in mv.mob.items()}
        for k in mv.mob:
            if kernel.ivol(moved[k], mv.frame) > TOL:
                held.add(k)
        changed = True
        while changed:
            changed = False
            for k in mv.mob:
                if k in held:
                    continue
                for j in list(held):
                    if np.linalg.norm(mv.axis[k] - mv.axis[j]) <= 0.01 and kernel.ivol(moved[k], mv.mob[j]) > TOL:
                        held.add(k)
                        changed = True
                        break
        for k in mv.mob:
            if k not in held:
                bad.append((k, d))
    return bad


def seated(mv):
    bad = []
    for k, ps in mv.mob_parts.items():
        if k == "barrel" or len(ps) < 2:
            continue
        for p in ps:
            others = kernel.union([mv.parts[q] for q in ps if q != p])
            for d in DIRS[:4]:
                if kernel.ivol(mv.parts[p].translate(list(d)), others) <= TOL:
                    bad.append((k, p, d))
            if all(kernel.ivol(mv.parts[p].translate(list(d)), others) <= TOL for d in DIRS[4:]):
                bad.append((k, p, "z"))
        linked = {ps[0]}
        changed = True
        while changed:
            changed = False
            for p in ps:
                if p not in linked and any(kernel.min_distance(mv.parts[p], mv.parts[q], 1.0) <= 0.02 for q in linked):
                    linked.add(p)
                    changed = True
        if len(linked) != len(ps):
            bad.append((k, "not linked"))
    return bad


def mesh_one(mv, i, shift):
    e = mv.doc["meshes"][i]
    D, N = e["driver"], e["driven"]
    return meshsim.mesh_test(mv.mob[D], mv.axis[D], e["driver_teeth"], mv.mob[N], mv.axis[N], e["driven_teeth"],
                             shift=shift)


def nothing_else(mv):
    sp, _ = mv.speeds()
    pairs = set(frozenset((e["driver"], e["driven"])) for e in mv.doc["meshes"])
    bad = []
    for a, b in itertools.combinations(list(mv.mob), 2):
        if frozenset((a, b)) in pairs:
            continue
        A, B = mv.mob[a], mv.mob[b]
        if not kernel.bbox_overlap(A.translate([0, 0, 0]), B):
            # bounding cylinders could still meet when turning: test swept-radius quickly
            pass
        wa, wb = float(sp.get(a, 0)), float(sp.get(b, 0))
        # quick reject: revolution envelopes
        ra = np.max(np.linalg.norm(kernel.verts(A)[:, :2] - mv.axis[a], axis=1))
        rb = np.max(np.linalg.norm(kernel.verts(B)[:, :2] - mv.axis[b], axis=1))
        if np.linalg.norm(mv.axis[a] - mv.axis[b]) > ra + rb + 0.01:
            continue
        ba, bb = A.bounding_box(), B.bounding_box()
        if ba[5] < bb[2] or bb[5] < ba[2]:
            continue
        fast = max(abs(wa), abs(wb))
        seqs = []
        if fast > 0:
            seqs.append([(360 * wa / fast * i / 144, 360 * wb / fast * i / 144) for i in range(144)])
        if wa != wb:
            rel = abs(wa - wb)
            seqs.append([(360 * wa / rel * i / 144, 360 * wb / rel * i / 144) for i in range(144)])
        if not seqs:
            seqs = [[(0, 0)]]
        worst = 0
        for seq in seqs:
            for ta, tb in seq:
                v = kernel.ivol(rot(A, ta, mv.axis[a]), rot(B, tb, mv.axis[b]))
                worst = max(worst, v)
        if worst > TOL:
            bad.append((a, b, worst))
    return bad


def hands(mv, ok_meshes):
    sp, conflict = mv.speeds(ok_meshes)
    want = {"hour": F(-1, 12), "minute": F(-1), "seconds": F(-60), "day": F(-1, 24)}
    res = {}
    for h, w in want.items():
        e = mv.doc["hands"][h]
        res[h] = (sp.get(e["mobile"]) == w) and not conflict
    return res, sp


def hand_geom(mv):
    out = {}
    top = max(mv.parts[n].bounding_box()[5] for n in mv.doc["fixed"])
    for h, e in mv.doc["hands"].items():
        P = mv.parts[e["part"]]
        ax = mv.axis[e["mobile"]]
        v = kernel.verts(P)
        reach = np.max(np.linalg.norm(v[:, :2] - ax, axis=1))
        low = P.bounding_box()[2]
        # centre of volume
        mesh = P.to_mesh()
        V = np.asarray(mesh.vert_properties)[:, :3]
        T = np.asarray(mesh.tri_verts)
        a, b, c = V[T[:, 0]], V[T[:, 1]], V[T[:, 2]]
        vol = np.einsum("ij,ij->i", a, np.cross(b, c)) / 6
        cen = ((a + b + c) / 4 * vol[:, None]).sum(0) / vol.sum()
        out[h] = dict(reach=round(float(reach), 3), above=bool(low >= top), cov=round(float(np.linalg.norm(cen[:2] - ax)), 3))
    out["coaxial"] = float(np.linalg.norm(mv.axis[mv.doc["hands"]["hour"]["mobile"]] - mv.axis[mv.doc["hands"]["minute"]["mobile"]]))
    out["day_dist"] = float(np.linalg.norm(mv.axis[mv.doc["hands"]["day"]["mobile"]] - mv.axis[mv.doc["hands"]["hour"]["mobile"]]))
    return out


def case_fit(mv):
    q = np.array(mv.doc["case_centre"], float)
    worst = 0
    for n in mv.doc["fixed"]:
        v = kernel.verts(mv.parts[n])
        worst = max(worst, np.max(np.linalg.norm(v[:, :2] - q, axis=1)))
    for k, S in mv.mob.items():
        v = kernel.verts(S)
        worst = max(worst, np.max(np.linalg.norm(v[:, :2] - mv.axis[k], axis=1)) + np.linalg.norm(mv.axis[k] - q))
    zs = [mv.parts[n].bounding_box() for n in mv.parts]
    h = max(b[5] for b in zs) - min(b[2] for b in zs)
    return dict(radius=round(float(worst), 4), height=round(float(h), 4))


def printable(man):
    h = 0.05
    bb = man.bounding_box()
    lo = np.array(bb[:3]) - 2 * h
    hi = np.array(bb[3:]) + 2 * h
    # voxel centres at 0.05k + 0.0113 -> origin = centre - h/2
    k0 = np.floor((lo - 0.0113) / h)
    origin = k0 * h + 0.0113 - h / 2
    shape = tuple(int(x) for x in np.ceil((hi - origin) / h).astype(int) + 1)
    n, dev = kernel.opening_test_slabs(man, origin, shape, h, 1.5, 1.0, 6.0)
    return n, dev * h


if __name__ == "__main__":
    fn = sys.argv[1]
    what = sys.argv[2:] or ["c2", "free", "held", "seated", "else", "hands", "case"]
    mv = Mv(fn)
    if "c2" in what:
        print("C2", c2(mv), flush=True)
    if "free" in what:
        print("free", free_turn(mv), flush=True)
    if "held" in what:
        print("held", held(mv), flush=True)
    if "seated" in what:
        print("seated", seated(mv), flush=True)
    if "else" in what:
        print("nothing-else", nothing_else(mv), flush=True)
    if "hands" in what:
        print("speeds", hands(mv, None))
        print("handgeom", hand_geom(mv))
    if "case" in what:
        print("case", case_fit(mv))
