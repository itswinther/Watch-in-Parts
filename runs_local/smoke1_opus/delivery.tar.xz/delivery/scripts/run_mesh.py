import sys, os
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verify
MV = {}
def job(args):
    fn, i, sh = args
    if fn not in MV: MV[fn] = verify.Mv(fn)
    mv = MV[fn]; e = mv.doc["meshes"][i]
    r = verify.mesh_one(mv, i, sh)
    return (fn, e["driver"], e["driven"], sh, r["ok"], round(r["max_int"], 5), round(r["max_gap"], 4), round(r["min_ratio"], 3), r["fails"][:2])
if __name__ == "__main__":
    fns = sys.argv[1:] or ["movement.json"]
    jobs = []
    for fn in fns:
        n = len(verify.Mv(fn).doc["meshes"]) if False else 10
        for i in range(n):
            for sh in (0.0, 0.03, -0.03):
                jobs.append((fn, i, sh))
    jobs.sort(key=lambda j: j[1] == 0, reverse=True)
    with Pool(4) as p:
        for r in p.imap_unordered(job, jobs):
            print(r, flush=True)
