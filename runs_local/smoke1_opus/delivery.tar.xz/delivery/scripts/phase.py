import math
def driven_phase(beta_deg, phiD_deg, zD, zN, eps_deg=0.0):
    """Tooth-0 phase of N (deg) so that it meshes with D; eps rotates N CCW by eps."""
    pD = 360.0 / zD; pN = 360.0 / zN
    th = (beta_deg - phiD_deg) % pD
    return beta_deg + 180.0 + pN / 2 + th * zD / zN + eps_deg
