import sys, os, json
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verify
def job(n):
    import time; t=time.time()
    k, dev = verify.printable(verify.load(n))
    return n, k, round(dev,4), dev <= 0.2 + 1e-9 and k >= 1, round(time.time()-t,1)
if __name__ == "__main__":
    names=[]
    for fn in ("movement.json","variant_6h.json"):
        d=json.load(open(os.path.join(verify.DELIV,fn)))
        for n in d["fixed"]+[p for m in d["mobiles"].values() for p in m["parts"]]:
            if n not in names: names.append(n)
    with Pool(2) as p:
        for r in p.imap_unordered(job, names): print(r, flush=True)
