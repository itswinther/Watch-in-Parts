import sys, numpy as np
sys.path.insert(0,'.')
import search2 as S, layout as L
rng=np.random.default_rng(1)
def setp(p):
    a_mw,a_i,a_d,a0,a1,a2,a3=p
    L.AX["MW"]=L.polar(L.C, L.cd(15,45), L.ang_A+a_mw)
    L.AX["I"] = L.polar(L.C, L.cd(48, 32), L.ang_A + a_i)
    L.AX["D"] = L.polar(L.AX["I"], L.cd(12, 36), L.ang_A + a_i + a_d)
    L.AX["T1"] = L.polar(L.C, L.cd(48, 12), L.ang_A + a0)
    L.AX["T2"] = L.polar(L.AX["T1"], L.cd(35, 14), L.ang_A + a0+a1)
    L.AX["T3"] = L.polar(L.AX["T2"], L.cd(36, 12), L.ang_A + a0+a1+a2)
    L.AX["S"] = L.polar(L.AX["T3"], L.cd(24, 12), L.ang_A + a0+a1+a2+a3)
def score(p):
    setp(p)
    s=min(S.slack('8h'),S.slack('6h'))
    dSC=np.linalg.norm(L.AX['S']-L.C); dDC=np.linalg.norm(L.AX['D']-L.C)
    pen=0
    if dSC<8: pen+=8-dSC
    if np.linalg.norm(L.AX['S']-L.Q)+5.6>20.5: pen+=np.linalg.norm(L.AX['S']-L.Q)+5.6-20.5
    if dDC<7: pen+=7-dDC
    if np.linalg.norm(L.AX['D']-L.Q)+3.6>20.5: pen+=1
    if np.linalg.norm(L.AX['D']-L.AX['S'])<10: pen+=10-np.linalg.norm(L.AX['D']-L.AX['S'])
    return min(s,0.8)-pen
best=None
for it in range(20000):
    if best is None or rng.random()<0.3:
        p=np.array([rng.uniform(90,200),rng.uniform(40,120),rng.uniform(-90,90),rng.uniform(-170,-60),rng.uniform(-120,120),rng.uniform(-150,150),rng.uniform(-150,150)])
    else:
        p=best[1]+rng.normal(0,5,7)
    sc=score(p)
    if best is None or sc>best[0]: best=(sc,p)
print(best[0], np.round(best[1],1).tolist())
setp(best[1])
for x in S.slack('8h',True)[:6]: print(x)
for k,v in L.AX.items(): print(k,np.round(v,3), round(float(np.linalg.norm(v-L.C)),2))
