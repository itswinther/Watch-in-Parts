import sys, math, numpy as np, manifold3d as m3
sys.path.insert(0,'.'); sys.path.insert(0,'../../tools')
import kernel, gearlib, phase
def cs(P): return m3.CrossSection([np.asarray(P,float).tolist()])
def rot2(c, deg, ax):
    return c.translate([-ax[0],-ax[1]]).rotate(deg).translate([ax[0],ax[1]])
def backlash(Dcs, Dax, Ncs, Nax, zD, zN, shift=0.0, steps=8):
    """for D at angles over one pitch, find N's free eps range [lo,hi] (deg, N CCW)."""
    Dax=np.asarray(Dax); Nax=np.asarray(Nax); u=(Nax-Dax)/np.linalg.norm(Nax-Dax)
    Nax1=Nax+shift*u; Nc=Ncs.translate([shift*u[0],shift*u[1]])
    out=[]
    for i in range(steps):
        a=i*360/(zD*steps)
        Di=rot2(Dcs,a,Dax); Ni=rot2(Nc,-a*zD/zN,Nax1)
        def area(e): return (Di ^ rot2(Ni,e,Nax1)).area()
        def edge(sgn):
            lo,hi=0.0,sgn*360/zN/2
            if area(0)>1e-9: return None
            for _ in range(40):
                mid=(lo+hi)/2
                if area(mid)>1e-9: hi=mid
                else: lo=mid
            return lo
        out.append((edge(-1),edge(1)))
    return out
