"""Involute spur gear profiles (2D) and helpers."""
import math
import numpy as np


def inv(a):
    return math.tan(a) - a


def gear_profile(z, m, alpha_deg=25.0, s=None, ha=1.0, hf=1.25, phase_deg=0.0, n_flank=8, n_tip=2, n_root=3,
                 centre=(0.0, 0.0)):
    """Closed CCW polygon (N x 2) of an external involute spur gear.
    s: tooth thickness (arc) on the pitch circle. Tooth 0 is centred at phase_deg from +x."""
    al = math.radians(alpha_deg)
    r = m * z / 2.0
    rb = r * math.cos(al)
    ra = r + ha * m
    rf = r - hf * m
    if s is None:
        s = math.pi * m / 2
    psi = s / (2 * r)                      # half angle at pitch circle

    def half(rho):
        if rho <= rb:
            return psi + inv(al)
        return psi + inv(al) - inv(math.acos(rb / rho))
    r0 = max(rf, rb)
    radii = np.linspace(r0, ra, n_flank)
    # if root below base circle: radial segment from rf to rb
    pitch = 2 * math.pi / z
    pts = []
    th_tip = half(ra)
    th_root = half(r0)
    gap_half = pitch / 2 - th_root           # half angle of the gap at root
    for k in range(z):
        c = math.radians(phase_deg) + k * pitch
        # root arc from previous gap centre to start of this tooth's right flank (angle c - th_root)
        a0 = c - pitch / 2
        a1 = c - th_root
        for t in np.linspace(a0, a1, n_root)[:-1]:
            pts.append((rf * math.cos(t), rf * math.sin(t)))
        if rf < rb:
            pts.append((rf * math.cos(a1), rf * math.sin(a1)))
        # right flank (lower angle side) going up
        for rho in radii:
            t = c - half(rho)
            pts.append((rho * math.cos(t), rho * math.sin(t)))
        # tip arc
        for t in np.linspace(c - th_tip, c + th_tip, n_tip + 2)[1:-1]:
            pts.append((ra * math.cos(t), ra * math.sin(t)))
        # left flank going down
        for rho in radii[::-1]:
            t = c + half(rho)
            pts.append((rho * math.cos(t), rho * math.sin(t)))
        if rf < rb:
            pts.append((rf * math.cos(c + th_root), rf * math.sin(c + th_root)))
        # root arc to the gap centre
        for t in np.linspace(c + th_root, c + pitch / 2, n_root)[1:-1]:
            pts.append((rf * math.cos(t), rf * math.sin(t)))
    P = np.array(pts) + np.asarray(centre)
    # remove consecutive duplicates
    keep = np.ones(len(P), bool)
    d = np.linalg.norm(np.diff(np.vstack([P, P[:1]]), axis=0), axis=1)
    keep[1:] = d[:-1] > 1e-7
    return P[keep]


def gear_dims(z, m, alpha_deg=25.0):
    r = m * z / 2.0
    return dict(r=r, ra=r + m, rf=r - 1.25 * m, rb=r * math.cos(math.radians(alpha_deg)))
