"""Layout of the calibre: axes, gears, layers, z levels. Shared by both builds."""
import math
import numpy as np

M = 0.2                 # module of every gear
ALPHA = 25.0
S_OWN = math.pi * M / 2 - 0.0275    # tooth thickness of our gears (barrel: 0.284, ours meshing it: 0.289)
S_P1 = 0.289

C = np.array([8.0, 0.0])          # centre (minute/hour) axis = case centre
Q = C.copy()
O = np.array([0.0, 0.0])          # barrel


def polar(base, r, deg):
    return np.asarray(base, float) + r * np.array([math.cos(math.radians(deg)), math.sin(math.radians(deg))])


def cd(z1, z2):
    return M * (z1 + z2) / 2


# ---- z levels ----
PLATE = (-1.2, -0.1)        # main plate
DECK = (1.1, 1.7)           # deck over the barrel
FACE = 0.5
LAYERS = {1: (1.85, 2.35), 2: (2.55, 3.05), 3: (3.25, 3.75), 4: (3.95, 4.45)}
BRIDGE = (4.6, 5.1)
HANDZ = {"day": (5.2, 5.65), "seconds": (5.8, 6.25), "hour": (6.4, 6.85), "minute": (7.0, 7.45)}
RING = (18.7, 20.4)         # frame ring walls (radii about Q)

# ---- axes ----
A_ = np.array([10.75, math.sqrt(144 - 10.75 ** 2)])
ang_A = math.degrees(math.atan2(A_[1] - C[1], A_[0] - C[0]))
AX = {}
AX["A"] = A_
AX["M"] = C.copy()
AX["H"] = C.copy()
P_ANG = [159.3, 59.1, 37.5, -95.3, -28.4, 113.3, 38.6]   # from the layout search (search3.py)
AX["MW"] = polar(C, cd(15, 45), ang_A + P_ANG[0])
AX["I"] = polar(C, cd(48, 32), ang_A + P_ANG[1])
AX["D"] = polar(AX["I"], cd(12, 36), ang_A + P_ANG[1] + P_ANG[2])
AX["T1"] = polar(C, cd(48, 12), ang_A + P_ANG[3])
AX["T2"] = polar(AX["T1"], cd(35, 14), ang_A + sum(P_ANG[3:5]))
AX["T3"] = polar(AX["T2"], cd(36, 12), ang_A + sum(P_ANG[3:6]))
AX["S"] = polar(AX["T3"], cd(24, 12), ang_A + sum(P_ANG[3:7]))

# gears: mobile -> list of (gear name, teeth, layer)   layer 0 = under the deck (barrel level)
def gears(build):
    w2, p2 = (40, 20) if build == "8h" else (36, 24)
    return {
        "A": [("p1", 24, 0), ("W2", w2, 1)],
        "M": [("p2", p2, 1), ("Gs", 48, 2), ("cannon", 15, 3)],
        "H": [("Wh", 48, 4)],
        "MW": [("W", 45, 3), ("p", 12, 4)],
        "I": [("W", 32, 4), ("p", 12, 2)],
        "D": [("W", 36, 2)],
        "T1": [("p", 12, 2), ("W", 35, 3)],
        "T2": [("p", 14, 3), ("W", 36, 1)],
        "T3": [("p", 12, 1), ("W", 24, 2)],
        "S": [("p", 12, 2)],
    }


def meshes(build):
    w2, p2 = (40, 20) if build == "8h" else (36, 24)
    return [  # (driver, driver gear, driven, driven gear)
        ("barrel", None, 96, "A", "p1", 24),
        ("A", "W2", w2, "M", "p2", p2),
        ("M", "Gs", 48, "T1", "p", 12),
        ("T1", "W", 35, "T2", "p", 14),
        ("T2", "W", 36, "T3", "p", 12),
        ("T3", "W", 24, "S", "p", 12),
        ("M", "cannon", 15, "MW", "W", 45),
        ("MW", "p", 12, "H", "Wh", 48),
        ("H", "Wh", 48, "I", "W", 32),
        ("I", "p", 12, "D", "W", 36),
    ]
