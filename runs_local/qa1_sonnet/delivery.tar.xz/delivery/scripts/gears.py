import math, numpy as np
import manifold3d as m3
ALPHA = math.radians(25)
def inv(a): return math.tan(a) - a

def gear_poly(z, m, thin=0.0, phase=0.0, alpha=ALPHA, nflank=14, add=1.0, ded=1.25, root_clear=0.0):
    """CCW polygon, tooth 0 centred at angle `phase` (rad). thin = reduction of tooth arc thickness at pitch circle."""
    rp = m*z/2; rb = rp*math.cos(alpha); ra = rp + add*m; rr = rp - ded*m - root_clear
    s = math.pi*m/2 - thin
    thp = s/(2*rp)
    def th(r):
        return thp + inv(alpha) - inv(math.acos(min(1.0, rb/r)))
    r0 = max(rb, rr)
    thb = th(r0)
    pts = []
    pitch = 2*math.pi/z
    rs = rb*np.sqrt(1 + np.linspace(math.sqrt((r0/rb)**2-1), math.sqrt((ra/rb)**2-1), nflank)**2)
    for k in range(z):
        a0 = phase + k*pitch
        # root start (right flank bottom)
        pts.append((rr, a0 - thb))
        for r in rs:
            pts.append((r, a0 - th(r)))
        # tip arc
        tt = th(ra)
        for f in (-0.5, 0.0, 0.5):
            pts.append((ra, a0 + f*2*tt))
        for r in rs[::-1]:
            pts.append((r, a0 + th(r)))
        pts.append((rr, a0 + thb))
        # root arc to next tooth
        a1 = a0 + pitch - thb
        nroot = 3
        for i in range(1, nroot+1):
            pts.append((rr, a0 + thb + (a1 - (a0+thb))*i/(nroot+1)))
    P = np.array([(r*math.cos(a), r*math.sin(a)) for r, a in pts])
    # drop duplicate consecutive points
    keep = [0]
    for i in range(1, len(P)):
        if np.hypot(*(P[i]-P[keep[-1]])) > 1e-6: keep.append(i)
    P = P[keep]
    if np.hypot(*(P[0]-P[-1])) < 1e-6: P = P[:-1]
    return P

def rot(P, ang, c=(0, 0)):
    ca, sa = math.cos(ang), math.sin(ang)
    R = np.array([[ca, -sa], [sa, ca]])
    return (np.asarray(P) - c) @ R.T + c

def cs(P): return m3.CrossSection([np.asarray(P, float).tolist()])
def area(c): return c.area()
