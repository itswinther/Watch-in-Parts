import sys, json, math, itertools, collections
sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work')
from spec import *
DEL='/tmp/claude-0/runs/qa1_sonnet/app/delivery'
MAT='AD-C100-HT'
def movement(build):
    A='mob_A8' if build=='8' else 'mob_A6'; M='mob_M8' if build=='8' else 'mob_M6'
    zAw,zMa=(30,30) if build=='8' else (24,32)
    mob={}
    def add(name,parts): mob[name]={"axis":[round(POS[name][0],9),round(POS[name][1],9)],"parts":parts,"material":MAT}
    add('A',[A]); add('M',[M,'hand_min']); add('T',['mob_T']); add('U',['mob_U']); add('V',['mob_V'])
    add('S',['mob_S','hand_sec']); add('I',['mob_I']); add('H',['mob_H','hand_hour']); add('D',['mob_D','hand_day'])
    meshes=[
     {"driver":"barrel","driver_teeth":96,"driven":"A","driven_teeth":12},
     {"driver":"A","driver_teeth":zAw,"driven":"M","driven_teeth":zMa},
     {"driver":"M","driver_teeth":40,"driven":"T","driven_teeth":12},
     {"driver":"T","driver_teeth":36,"driven":"U","driven_teeth":12},
     {"driver":"U","driver_teeth":36,"driven":"V","driven_teeth":12},
     {"driver":"V","driver_teeth":24,"driven":"S","driven_teeth":12},
     {"driver":"M","driver_teeth":12,"driven":"I","driven_teeth":48},
     {"driver":"I","driver_teeth":12,"driven":"H","driven_teeth":36},
     {"driver":"I","driver_teeth":12,"driven":"D","driven_teeth":72}]
    return {"case_centre":list(CASE_C),"fixed":["frame_base","frame_bridge"],"mobiles":mob,"meshes":meshes,
      "hands":{"hour":{"mobile":"H","part":"hand_hour"},"minute":{"mobile":"M","part":"hand_min"},
               "seconds":{"mobile":"S","part":"hand_sec"},"day":{"mobile":"D","part":"hand_day"}}}
if __name__=='__main__':
    json.dump(movement('8'),open(DEL+'/movement.json','w'),indent=1)
    json.dump(movement('6'),open(DEL+'/variant_6h.json','w'),indent=1)
