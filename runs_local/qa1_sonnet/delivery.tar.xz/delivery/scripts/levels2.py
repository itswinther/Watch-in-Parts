import math, itertools, sys, random, collections
src=open('levels.py').read().split("best=None")[0]
exec(src)
import os
NL=int(sys.argv[1])
RELAX=os.environ.get('RELAX','')
TOP=NL-1
random.seed(int(sys.argv[2]) if len(sys.argv)>2 else 0)
elem_of={}  # class -> list of gears
order=classes[:]
def elems(sol):
    el=[]
    for c,L in sol.items():
        for n in members[c]:
            if n=='B' : continue
            el.append((n,gm[n],L,gr[n]))
    return el
def edges_of(el):
    e=set()
    for (n1,m1,l1,r1),(n2,m2,l2,r2) in itertools.combinations(el,2):
        if m1==m2 or frozenset((n1,n2)) in mates: continue
        if dist(m1,m2)<r1+r2+0.1 and l1!=l2:
            e.add((m1,m2) if l1<l2 else (m2,m1))
    return e
def acyclic(e):
    nodes=set(gm.values())|{'H'}
    adj=collections.defaultdict(set); indeg={n:0 for n in nodes}
    for a,b in e:
        if b not in adj[a]: adj[a].add(b); indeg[b]+=1
    q=[n for n in nodes if indeg[n]==0]; cnt=0
    while q:
        n=q.pop(); cnt+=1
        for b in adj[n]:
            indeg[b]-=1
            if indeg[b]==0: q.append(b)
    return cnt==len(nodes)
sol={}
found=[]
def leaf():
    el=elems(sol)
    for (n1,m1,l1,r1),(n2,m2,l2,r2) in itertools.combinations(el,2):
        if m1==m2 or frozenset((n1,n2)) in mates: continue
        if l1==l2 and dist(m1,m2)<r1+r2+0.3: return False
    # M top gear directly below H wheel
    Lh=sol['I_p2']; Mtop=max(sol['A_w'],sol['M_t'],sol['M_p'])
    if Mtop!=Lh-1: return False
    # bosses
    for mob in 'ATUVSDI':
        Lt=max(l for n,m,l,r in el if m==mob)
        for l in range(Lt+1,NL):
            for n2,m2,l2,r2 in el:
                if l2==l and m2!=mob and dist(mob,m2)<1.1+r2+0.2: return False
    e=edges_of(el)
    if 'noacyc' not in RELAX and not acyclic(e): return False
    return True
def rec(i):
    if i==len(order):
        if leaf():
            found.append(dict(sol)); return True
        return False
    c=order[i]
    Ls=list(range(NL)); random.shuffle(Ls)
    for L in Ls:
        if c=='A_p' and L!=0: continue
        if 'nobar' not in RELAX and L==0 and c!='A_p' and barrel_conflict(c): continue
        if L==TOP and False: pass
        ok=True
        for c2,L2 in sol.items():
            if L2==L and (conflict_same_level(c,c2) or same_mob(c,c2)): ok=False;break
        if not ok: continue
        # same mobile gears at distinct levels across classes (also different classes sharing mobile)
        sol[c]=L
        if 'I_p2' in sol:
            for mc in ('M_a','M_t','M_p','A_w'):
                pass
        okH=True
        if 'I_p2' in sol:
            Hl=sol['I_p2']
            for mc in ('A_w','M_t','M_p'):
                if mc in sol:
                    # M gears: A_w class includes M_a
                    if not sol[mc]<Hl: okH=False
        if okH and rec(i+1): return True
        del sol[c]
    return False
print(rec(0), found[:1])
