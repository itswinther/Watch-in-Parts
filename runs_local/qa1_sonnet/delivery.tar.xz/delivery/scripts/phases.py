import sys, json; sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work'); sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/tools')
from mesh2d import *
import kernel

def barrel_poly():
    tris = kernel.read_stl('/tmp/claude-0/runs/qa1_sonnet/app/supplied/barrel.stl', 2_000_000, 100_000_000)
    man = kernel.tris_to_manifold(tris)
    polys = man.slice(0.5).to_polygons()
    polys = sorted(polys, key=lambda p: -len(p))
    return np.asarray(polys[0], float)

def score_phase(PD, zD, zN, m, a, thin_N, ph, H):
    PN = gear_poly(zN, m, thin=thin_N, phase=math.pi+ph)
    r = mesh_eval(PD, PN, zD, zN, a)
    thr = 0.5*m*m
    jam = max(v[0] for v in r.values())
    V = min(v[1] for v in r.values())
    return jam, V, thr, r

def search(PD, zD, zN, m, a, thin_N, H=0.8, n=48):
    best=None
    pitch = 2*math.pi/zN
    for ph in np.linspace(0, pitch, n, endpoint=False):
        jam,V,thr,r = score_phase(PD,zD,zN,m,a,thin_N,ph,H)
        ok = jam*H <= 0.003
        sc = (V/thr) if ok else -jam
        if best is None or sc>best[0]: best=(sc,ph,jam,V,thr)
    # refine
    sc,ph0,_,_,_=best
    for ph in np.linspace(ph0-pitch/n, ph0+pitch/n, 17):
        jam,V,thr,r = score_phase(PD,zD,zN,m,a,thin_N,ph,H)
        ok = jam*H <= 0.003
        s2 = (V/thr) if ok else -jam
        if s2>best[0]: best=(s2,ph,jam,V,thr)
    return best
if __name__=='__main__':
    # test barrel mesh
    PB = barrel_poly()
    m=0.2; zN=12; a=10.8
    for thin in (0.0, 0.01, 0.02):
        print('barrel-A thin',thin, search(PB,96,zN,m,a,thin,H=1.0,n=24))
