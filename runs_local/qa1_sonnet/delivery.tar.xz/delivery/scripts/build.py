import sys, json, math, os
sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work'); sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/tools')
import numpy as np, cadquery as cq
from spec import *
from gears import gear_poly
import kernel
PH=json.load(open('/tmp/claude-0/runs/qa1_sonnet/app/work/phases.json'))
OUT='/tmp/claude-0/runs/qa1_sonnet/app/delivery/parts'
os.makedirs(OUT,exist_ok=True)
ARB=0.5
def prism(poly,z0,z1):
    pts=[(float(x),float(y)) for x,y in poly]
    return cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1-z0)
def cyl(r,z0,z1,x=0,y=0):
    return cq.Workplane("XY").workplane(offset=z0).center(x,y).circle(r).extrude(z1-z0)
def U(a,b): return a.union(b)
def gz(g):
    if g=='A_p': return (0.0,1.0)
    return lz(LEV[g])
GEARS={ # gear -> (teeth, module, thin)
 'A_p':(12,0.2,0.005),'A_w8':(30,0.2,THIN),'A_w6':(24,M6,THIN),'M_a8':(30,0.2,THIN),'M_a6':(32,M6,THIN),
 'M_t':(40,0.2,THIN),'T_p':(12,0.2,THIN),'T_w':(36,0.15,THIN),'U_p':(12,0.15,THIN),'U_w':(36,0.15,THIN),
 'V_p':(12,0.15,THIN),'V_w':(24,0.15,THIN),'S_p':(12,0.15,THIN),'M_p':(12,0.16,THIN),'I_w':(48,0.16,THIN),
 'I_p2':(12,0.2,THIN),'H_w':(36,0.2,THIN),'I_i2':(12,0.15,THIN),'D_w':(72,0.15,THIN)}
# gear phase: (mesh key, role)
GP={'A_p':('m_bA','N'),'A_w8':('m_AM8','D'),'A_w6':('m_AM6','D'),'M_a8':('m_AM8','N'),'M_a6':('m_AM6','N'),
 'M_t':('m_MT','D'),'T_p':('m_MT','N'),'T_w':('m_TU','D'),'U_p':('m_TU','N'),'U_w':('m_UV','D'),'V_p':('m_UV','N'),
 'V_w':('m_VS','D'),'S_p':('m_VS','N'),'M_p':('m_MI','D'),'I_w':('m_MI','N'),'I_p2':('m_IH','D'),'H_w':('m_IH','N'),
 'I_i2':('m_ID','D'),'D_w':('m_ID','N')}
def gphase(g):
    k,role=GP[g]; psi=MESHES[k]['psi']
    return psi if role=='D' else psi+math.pi+PH[k]['ph']
def gear_plate(g, bore=None):
    z,m,thin=GEARS[g]
    z0,z1=gz(g.replace('8','').replace('6','')) if g[-1] in '86' and g[:-1] in ('A_w','M_a') else gz(g)
    # level lookup uses base name
    base=g[:-1] if g in ('A_w8','A_w6','M_a8','M_a6') else g
    z0,z1=gz(base)
    P=gear_poly(z,m,thin=thin,phase=gphase(g))
    s=prism(P,z0,z1)
    return s
def at(solid,mob):
    x,y=POS[mob]; return solid.translate((x,y,0))
def step(name,solid):
    kernel.write_step('%s/%s.step'%(OUT,name),solid)
def arbor(z0,z1,r=ARB): return cyl(r,z0,z1)

# ---------- mobiles ----------
BR={}  # boss bottoms
def top_gear_top(gs): return max(gz(g[:-1] if g in ('A_w8','A_w6','M_a8','M_a6') else g)[1] for g in gs)
SPEC={ # mobile -> gears
 'A':{'8':['A_p','A_w8'],'6':['A_p','A_w6']},
 'M':{'8':['M_a8','M_t','M_p'],'6':['M_a6','M_t','M_p']},
 'T':{'*':['T_p','T_w']},'U':{'*':['U_p','U_w']},'V':{'*':['V_p','V_w']},'S':{'*':['S_p']},
 'I':{'*':['I_w','I_p2','I_i2']},'H':{'*':['H_w']},'D':{'*':['D_w']}}
ZB=6.0   # bridge underside
ZT=7.0   # bridge top
for mob in 'ATUVSD': 
    gs=SPEC[mob].get('8',SPEC[mob].get('*'))
    BR[mob]=top_gear_top(gs)+0.1
BR['I']=ZB
def mobile(mob,build):
    gs=SPEC[mob].get(build,SPEC[mob].get('*'))
    if mob=='H':
        z0,z1=gz('H_w')
        s=cyl(1.1,z0,7.3)
        s=s.union(gear_plate('H_w'))
        s=s.union(cyl(0.9,7.3,7.71))
        s=s.cut(cyl(0.6,z0-0.1,8.0))
        return s
    top = {'M':8.41,'S':9.11,'D':9.11}.get(mob)
    if mob in ('M','S','D'):
        stepz={'M':8.0,'S':8.7,'D':8.7}[mob]
        s=cyl(ARB,-1.0,stepz).union(cyl(0.35,stepz,top))
    else:
        s=cyl(ARB,-1.0,BR[mob]+0.2)
    for g in gs: s=s.union(gear_plate(g))
    return at(s,mob)
# H needs positioning too
def build_mobile(mob,build):
    s=mobile(mob,build)
    if mob=='H': s=at(s,'H')
    return s
# ---------- hands ----------
def hand(bore,hub_r,z0,z1,L,hw0,hw1,ang,mob,tail=0.0):
    s=cyl(hub_r,z0,z1)
    pts=[(0,-hw0),(L,-hw1),(L,hw1),(0,hw0)]
    p=cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1-z0)
    s=s.union(p)
    s=s.cut(cyl(bore,z0-0.1,z1+0.1))
    s=s.rotate((0,0,0),(0,0,1),math.degrees(ang))
    return at(s,mob)
HANDS={
 'hand_hour':lambda: hand(0.91,1.4,7.31,7.71,5.4,0.55,0.28,math.radians(60),'H'),
 'hand_min': lambda: hand(0.36,0.9,8.01,8.41,7.0,0.45,0.25,math.radians(100),'M'),
 'hand_sec': lambda: hand(0.36,0.8,8.71,9.11,5.4,0.4,0.25,math.radians(90),'S'),
 'hand_day': lambda: hand(0.36,0.8,8.71,9.11,3.4,0.45,0.28,math.radians(135),'D'),
}
# ---------- frame ----------
RP=20.6
def pillar_positions():
    pts=[]
    from levels import P as _P
    return None
PILLARS=[]
def choose_pillars():
    import itertools
    el=[]
    for g,(zt,m,t) in GEARS.items(): pass
    # use disc radii per mobile (all gears) conservative
    rad={'A':3.7,'M':4.3,'T':3.0,'U':3.0,'V':3.0,'S':1.2,'I':4.2,'D':5.7,'H':4.0}
    res=[]
    for adeg in range(0,360,3):
        a=math.radians(adeg); r=19.0
        p=(CASE_C[0]+r*math.cos(a), CASE_C[1]+r*math.sin(a))
        ok=True
        for mob,R in rad.items():
            if math.dist(p,POS[mob])<R+1.0+0.6: ok=False
        if math.dist(p,POS['B'])<9.8+1.0+0.6: ok=False
        if ok: res.append(adeg)
    return res
def frame_base():
    s=cyl(RP,-1.9,-0.1,*CASE_C)
    for mob in ['B','A','M','T','U','V','S','I','D']:
        x,y=POS[mob]
        s=s.cut(cyl(0.6,-1.1,0.0,x,y))
    for (x,y) in PILLARS:
        s=s.union(cyl(1.0,-0.1,ZB,x,y))
    return s
def frame_bridge():
    s=cyl(RP,ZB,ZT,*CASE_C)
    for mob in 'ATUVSD':
        x,y=POS[mob]
        s=s.union(cyl(1.1,BR[mob],ZB,x,y))
    s=s.union(cyl(1.4,5.0,ZB,0,0))
    # barrel pocket
    s=s.cut(cyl(0.6,5.0,5.7,0,0))
    for mob in 'ATUV':
        x,y=POS[mob]; s=s.cut(cyl(0.6,BR[mob],BR[mob]+0.4,x,y))
    x,y=POS['I']; s=s.cut(cyl(0.6,ZB,ZB+0.4,x,y))
    for mob in 'SD':
        x,y=POS[mob]; s=s.cut(cyl(0.6,BR[mob]-0.1,ZT+0.1,x,y))
    x,y=POS['M']; s=s.cut(cyl(1.2,ZB-0.1,ZT+0.1,x,y))
    return s

def build_all():
    global PILLARS
    PILLARS=[(CASE_C[0]+19.0*math.cos(math.radians(a)), CASE_C[1]+19.0*math.sin(math.radians(a))) for a in (30,150,270)]
    parts={}
    parts['frame_base']=frame_base()
    parts['frame_bridge']=frame_bridge()
    parts['mob_A8']=build_mobile('A','8'); parts['mob_A6']=build_mobile('A','6')
    parts['mob_M8']=build_mobile('M','8'); parts['mob_M6']=build_mobile('M','6')
    for mob in 'TUVSIHD': parts['mob_'+mob]=build_mobile(mob,'8')
    for k,f in HANDS.items(): parts[k]=f()
    return parts
if __name__=='__main__':
    import time
    t=time.time()
    parts=build_all()
    for n,s in parts.items():
        step(n,s); print(n, 'ok', round(time.time()-t,1), flush=True)
