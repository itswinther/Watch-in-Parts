import sys, json; sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work')
from spec import *
from phases import *
out={}
PB=barrel_poly()
for k,v in MESHES.items():
    m=v['m']; zD=v['zD']; zN=v['zN']; a=v['a']
    if v['D']=='B':
        PD=PB; thinN=0.005; H=1.0
    else:
        PD=gear_poly(zD,m,thin=THIN,phase=0); thinN=THIN; H=0.8
    best=search(PD,zD,zN,m,a,thinN,H=H,n=36)
    sc,ph,jam,V,thr=best
    out[k]=dict(ph=float(ph),score=float(sc),jam=float(jam),V=float(V),thr=float(thr),thinN=thinN,thinD=(None if v['D']=='B' else THIN))
    print(k,out[k],flush=True)
json.dump(out,open('phases.json','w'),indent=1)
