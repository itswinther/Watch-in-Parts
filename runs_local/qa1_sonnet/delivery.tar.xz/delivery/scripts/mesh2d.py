import sys; sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work')
from gears import *

def poses(PD, PN, zD, zN, a, dN=0.0, i=0.0, extra=0.0):
    """D at origin, N at (a+dN, 0). returns cross sections after turning D ccw by i steps + extra pitches."""
    th = math.radians(i*360/(8*zD)) + extra*2*math.pi/zD
    D = rot(PD, th)
    N = rot(PN, -th*zD/zN) + np.array([a+dN, 0])
    return D, N

def mesh_eval(PD, PN, zD, zN, a, nsteps=8, extra_pts=(1/3,1/5), full=False):
    res = {}
    ids = list(range(nsteps)) + list(extra_pts)
    out = {}
    for tag, dN in (('nom',0.0),('away',0.03),('towards',-0.03)):
        jam = 0.0; 
        for i in ids:
            D,N = poses(PD,PN,zD,zN,a,dN,i)
            ov = cs(D)^cs(N)
            jam = max(jam, ov.area())
        D0,N0 = poses(PD,PN,zD,zN,a,dN,0)
        D1,N1 = poses(PD,PN,zD,zN,a,dN,0,extra=0.25)
        V = ((cs(D1)^cs(N0)) - cs(D0)).area()
        out[tag] = (jam, V)
    return out
