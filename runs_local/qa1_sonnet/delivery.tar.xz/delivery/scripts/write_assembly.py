import sys, json, math, itertools, collections
sys.path.insert(0,'/tmp/claude-0/runs/qa1_sonnet/app/work')
from spec import *
DEL='/tmp/claude-0/runs/qa1_sonnet/app/delivery'
def tip(z,m): return m*z/2+m
G={'A_p':('A',12,.2),'A_w':('A',30,.2),'M_a':('M',30,.2),'M_t':('M',40,.2),'T_p':('T',12,.2),'T_w':('T',36,.15),'U_p':('U',12,.15),'U_w':('U',36,.15),
 'V_p':('V',12,.15),'V_w':('V',24,.15),'S_p':('S',12,.15),'M_p':('M',12,.16),'I_w':('I',48,.16),'I_p2':('I',12,.2),'H_w':('H',36,.2),'I_i2':('I',12,.15),'D_w':('D',72,.15)}
mates={frozenset(p) for p in [('A_w','M_a'),('M_t','T_p'),('T_w','U_p'),('U_w','V_p'),('V_w','S_p'),('M_p','I_w'),('I_p2','H_w'),('I_i2','D_w')]}
el=[(n,m,LEV[n],tip(z,mod)) for n,(m,z,mod) in G.items()]
edges=set()
for (n1,m1,l1,r1),(n2,m2,l2,r2) in itertools.combinations(el,2):
    if m1==m2 or frozenset((n1,n2)) in mates: continue
    if math.dist(POS[m1],POS[m2])<r1+r2+0.1 and l1!=l2:
        edges.add((m1,m2) if l1<l2 else (m2,m1))
edges.add(('M','H'))
nodes=list('AMTUVSIHD')
adj=collections.defaultdict(set); indeg={n:0 for n in nodes}
for a,b in edges:
    if b not in adj[a]: adj[a].add(b); indeg[b]+=1
order=[]; q=sorted([n for n in nodes if indeg[n]==0])
while q:
    n=q.pop(0); order.append(n)
    for b in sorted(adj[n]):
        indeg[b]-=1
        if indeg[b]==0: q.append(b)
assert len(order)==len(nodes),(order,edges)
print('mobile order',order)
PART={'A':'mob_A8','M':'mob_M8','T':'mob_T','U':'mob_U','V':'mob_V','S':'mob_S','I':'mob_I','H':'mob_H','D':'mob_D'}
ZMIN={'frame_base':-1.9,'barrel':-1.0,'frame_bridge':2.0,'mob_A8':-1.0,'mob_M8':-1.0,'mob_T':-1.0,'mob_U':-1.0,'mob_V':-1.0,'mob_S':-1.0,'mob_I':-1.0,'mob_H':5.1,
 'mob_D':-1.0,'hand_hour':7.31,'hand_min':8.01,'hand_sec':8.71,'hand_day':8.71}
TOP=9.11
STEP=0.19
def path(zmin):
    lift=TOP+5.6-zmin
    n=int(math.ceil(lift/STEP))
    st=lift/n
    poses=[]
    for k in range(n,-1,-1):
        T=[[1,0,0,0],[0,1,0,0],[0,0,1,k*st if k>0 else 0.0],[0,0,0,1]]
        poses.append(T)
    return poses
def main():
    seq=['frame_base','barrel']+[PART[m] for m in order]+['frame_bridge','hand_hour','hand_min','hand_sec','hand_day']
    # mobile order: M parts include hand later
    # ensure all minute-hand etc after bridge
    paths={n:path(ZMIN[n]) for n in seq}
    json.dump({"order":seq,"paths":paths},open(DEL+'/assembly.json','w'))
    print(seq, {n:len(p) for n,p in paths.items()})
main()
