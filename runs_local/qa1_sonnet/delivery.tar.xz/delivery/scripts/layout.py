import math, random, itertools, json
import numpy as np
R_CASE=20.7
# gears: name -> (mobile, teeth, module)
# mesh list (driver->driven): (mobile1, z1, mobile2, z2, module)
MODS = {}
def D(a,b): return math.hypot(a[0]-b[0], a[1]-b[1])
# distances
dBA = 0.2*(96+12)/2          # 10.8
dAM = 6.0
import os
MMT,MTU,MUV,MVS=[float(x) for x in os.environ.get('MODS','0.2,0.15,0.15,0.15').split(',')]
dMT = MMT*(40+12)/2
dTU = MTU*(36+12)/2
dUV = MUV*(36+12)/2
dVS = MVS*(24+12)/2
dMI = 0.16*(12+48)/2
dID = 0.15*(12+72)/2
print(dBA,dAM,dMT,dTU,dUV,dVS,dMI,dID)
# gear discs (mobile, tip radius) 6h worst-case radii for A/M
def tip(z,m): return m*z/2+m
discs = {
 'A':[tip(12,.2), tip(30,.2)],
 'M':[3.64, tip(40,MMT), tip(12,.16)],
 'T':[tip(12,MMT), tip(36,MTU)],
 'U':[tip(12,MTU), tip(36,MUV)],
 'V':[tip(12,MUV), tip(24,MVS)],
 'S':[tip(12,MVS)],
 'I':[tip(48,.16), tip(12,.2), tip(12,.15)],
 'H':[tip(36,.2)],
 'D':[tip(72,.15)],
}
Rmax = {k:max(v) for k,v in discs.items()}
Rmax['M']=max(Rmax['M'],7.0); Rmax['H']=max(Rmax['H'],5.4); Rmax['S']=max(Rmax['S'],5.4); Rmax['D']=max(Rmax['D'],3.4)
B=(0,0)
def build(ang):
    A=(dBA,0.0)
    M=(A[0]+dAM*math.cos(ang[0]), A[1]+dAM*math.sin(ang[0]))
    T=(M[0]+dMT*math.cos(ang[1]), M[1]+dMT*math.sin(ang[1]))
    U=(T[0]+dTU*math.cos(ang[2]), T[1]+dTU*math.sin(ang[2]))
    V=(U[0]+dUV*math.cos(ang[3]), U[1]+dUV*math.sin(ang[3]))
    S=(V[0]+dVS*math.cos(ang[4]), V[1]+dVS*math.sin(ang[4]))
    I=(M[0]+dMI*math.cos(ang[5]), M[1]+dMI*math.sin(ang[5]))
    Dd=(I[0]+dID*math.cos(ang[6]), I[1]+dID*math.sin(ang[6]))
    return dict(A=A,M=M,T=T,U=U,V=V,S=S,I=I,D=Dd,H=M)
mates = {frozenset(p) for p in [('A','M'),('M','T'),('T','U'),('U','V'),('V','S'),('M','I'),('I','H'),('I','D')]}
def score(ang, ret=False):
    P=build(ang); viol=0.0; msgs=[]
    mob=list(P)
    # arbors away from barrel disc
    for k in mob:
        if k=='H': continue
        d=D(P[k],B)
        if d<10.4: viol+=10.4-d; msgs.append(('barrel',k,d))
    # arbor not inside foreign disc (any gear of other mobile), arbor r .5 (+margin .3) ; collar .95 at top
    for k in mob:
        for j in mob:
            if j==k or (j in('H',) ) : continue
            if k=='H' and j=='M': continue
            if k=='M' and j=='H': continue
            for r in discs[j]:
                need=r+0.5+0.2
                if frozenset((j,k)) in mates and False: pass
                d=D(P[k],P[j])
                if d<need and frozenset((j,k)) not in mates:
                    viol+=need-d; msgs.append(('arb',k,'in',j,round(d,2),r))
                elif frozenset((j,k)) in mates and d<(need-0.2) :
                    viol+=need-0.2-d; msgs.append(('mate',k,j))
    # hub of H inside nothing; H disc vs others arbor
    for k in mob:
        if k in ('H','M'): continue
        d=D(P[k],P['M'])
        for r in discs['H']:
            need=r+0.8
            if d<need and frozenset(('H',k)) not in mates and k!='I':
                viol+=need-d; msgs.append(('arbH',k,round(d,2)))
    # D at least 6.5 from M; seconds hand ok: S far from M by hands: |S-M|>= 5.4+? 
    d=D(P['D'],P['M']); 
    if d<6.8: viol+=6.8-d; msgs.append(('Dfar',d))
    # case centre
    best=None
    pts=[(P[k],Rmax[k]) for k in mob]
    # choose c to minimise max radius: simple grid search
    gx,gy=np.meshgrid(np.arange(-5,30,1.0),np.arange(-25,25,1.0))
    E=np.maximum.reduce([np.hypot(gx-p[0],gy-p[1])+r for p,r in pts]+[np.hypot(gx,gy)+9.8])
    i=np.argmin(E); c=(gx.flat[i],gy.flat[i]); bv=E.flat[i]
    if bv>20.0: viol+=bv-20.0; msgs.append(('case',bv))
    if ret: return viol,msgs,P,c,bv
    return viol
if __name__=='__main__':
    random.seed(1)
    best=None
    for trial in range(300):
        ang=[random.uniform(0,2*math.pi) for _ in range(7)]
        s=score(ang)
        step=0.5
        for it in range(400):
            j=random.randrange(7)
            a2=list(ang); a2[j]+=random.gauss(0,step)
            s2=score(a2)
            if s2<=s: ang,s=a2,s2
            if it%100==99: step*=0.6
            if s<1e-9: break
        if best is None or s<best[0]: best=(s,ang); print(trial,s)
        if s<1e-9: break
    s,ang=best
    v,msgs,P,c,bv=score(ang,True)
    print(v,msgs); print({k:tuple(round(x,2) for x in p) for k,p in P.items()}, c, bv)
    json.dump({'ang':ang},open('layout_ang.json','w'))
