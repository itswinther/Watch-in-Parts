import math, json
ANG=json.load(open('/tmp/claude-0/runs/qa1_sonnet/app/work/layout_ang.json'))['ang']
def _pos():
    dBA=10.8; dAM=6.0; dMT=0.2*(40+12)/2; dTU=.15*(36+12)/2; dUV=.15*(36+12)/2; dVS=.15*(24+12)/2; dMI=.16*(12+48)/2; dID=.15*(12+72)/2
    A=(dBA,0.0)
    M=(A[0]+dAM*math.cos(ANG[0]), A[1]+dAM*math.sin(ANG[0]))
    T=(M[0]+dMT*math.cos(ANG[1]), M[1]+dMT*math.sin(ANG[1]))
    U=(T[0]+dTU*math.cos(ANG[2]), T[1]+dTU*math.sin(ANG[2]))
    V=(U[0]+dUV*math.cos(ANG[3]), U[1]+dUV*math.sin(ANG[3]))
    S=(V[0]+dVS*math.cos(ANG[4]), V[1]+dVS*math.sin(ANG[4]))
    I=(M[0]+dMI*math.cos(ANG[5]), M[1]+dMI*math.sin(ANG[5]))
    D=(I[0]+dID*math.cos(ANG[6]), I[1]+dID*math.sin(ANG[6]))
    return dict(B=(0.0,0.0),A=A,M=M,T=T,U=U,V=V,S=S,I=I,D=D)
POS=_pos()
POS['H']=POS['M']
CASE_C=(9.0,0.0)
# levels (index) of each gear
LEV={'A_p':0,'A_w':1,'M_a':1,'I_i2':3,'D_w':3,'I_p2':5,'H_w':5,'M_p':4,'I_w':4,'M_t':2,'T_p':2,'T_w':4,'U_p':4,'U_w':0,'V_p':0,'V_w':1,'S_p':1}
def lz(L): return (0.1+L, 0.9+L)
M6=2*6.0/(24+32)
# meshes: name, driver mobile, driver gear, zD, mD, driven mobile, driven gear, zN, mN(same module), centre dist, build
MESHES={
 'm_bA':  dict(D='B',Dg='B',zD=96,N='A',Ng='A_p',zN=12,m=0.2,builds=('8','6')),
 'm_AM8': dict(D='A',Dg='A_w',zD=30,N='M',Ng='M_a',zN=30,m=0.2,builds=('8',)),
 'm_AM6': dict(D='A',Dg='A_w',zD=24,N='M',Ng='M_a',zN=32,m=M6,builds=('6',)),
 'm_MT':  dict(D='M',Dg='M_t',zD=40,N='T',Ng='T_p',zN=12,m=0.2,builds=('8','6')),
 'm_TU':  dict(D='T',Dg='T_w',zD=36,N='U',Ng='U_p',zN=12,m=0.15,builds=('8','6')),
 'm_UV':  dict(D='U',Dg='U_w',zD=36,N='V',Ng='V_p',zN=12,m=0.15,builds=('8','6')),
 'm_VS':  dict(D='V',Dg='V_w',zD=24,N='S',Ng='S_p',zN=12,m=0.15,builds=('8','6')),
 'm_MI':  dict(D='M',Dg='M_p',zD=12,N='I',Ng='I_w',zN=48,m=0.16,builds=('8','6')),
 'm_IH':  dict(D='I',Dg='I_p2',zD=12,N='H',Ng='H_w',zN=36,m=0.2,builds=('8','6')),
 'm_ID':  dict(D='I',Dg='I_i2',zD=12,N='D',Ng='D_w',zN=72,m=0.15,builds=('8','6')),
}
for k,v in MESHES.items():
    a=math.dist(POS[v['D']],POS[v['N']])
    assert abs(a-v['m']*(v['zD']+v['zN'])/2)<1e-9,(k,a,v['m']*(v['zD']+v['zN'])/2)
    v['a']=a
    v['psi']=math.atan2(POS[v['N']][1]-POS[v['D']][1], POS[v['N']][0]-POS[v['D']][0])
THIN=0.015
