import math, numpy as np
import manifold3d as m3
from manifold3d import CrossSection
ALPHA = math.radians(25)

def rack_tooth(m, w0, narc=14, D=1.25, base=2.6):
    sa, ca, ta = math.sin(ALPHA), math.cos(ALPHA), math.tan(ALPHA)
    Dm = D * m
    rho = (w0 * ca - Dm * sa) / (1 - sa)
    xc = -Dm + rho
    pts = []
    hw = lambda x: w0 + x * ta
    pts.append((base * m, hw(base * m)))
    th0 = math.radians(90 + 25)
    for k in range(narc + 1):
        th = th0 + (2 * math.pi - 2 * th0) * k / narc
        pts.append((xc + rho * math.cos(th), rho * math.sin(th)))
    pts.append((base * m, -hw(base * m)))
    return np.array(pts)

def gear_poly(z, m, t, dstep=0.006, tip_add=1.0, simp=0.0004):
    """Gear outline (list of points CCW), tooth centred on +x. t = tooth thickness (arc) at pitch circle."""
    rp = z * m / 2.0
    w0 = (math.pi * m - t) / 2.0
    tool = rack_tooth(m, w0)
    pitch = 2 * math.pi / z
    n = int(math.ceil(2 * pitch * rp / dstep))
    polys = []
    for k in range(n + 1):
        phi = -pitch + 2 * pitch * k / n
        c, s = math.cos(phi), math.sin(phi)
        x = tool[:, 0] + rp
        y = tool[:, 1] - rp * phi
        polys.append(np.stack([c * x - s * y, s * x + c * y], 1))
    cs = [CrossSection([p.tolist()]) for p in polys]
    gap = CrossSection.batch_boolean(cs, m3.OpType.Add)
    ra = rp + tip_add * m
    blank = CrossSection.circle(ra, 720)
    gaps = [gap.rotate(math.degrees(2 * math.pi * g / z)) for g in range(z)]
    allg = CrossSection.batch_boolean(gaps, m3.OpType.Add)
    g = (blank - allg).rotate(-180.0 / z)   # tooth centred on +x
    g = g.simplify(simp)
    pl = g.to_polygons()
    assert len(pl) == 1, len(pl)
    return np.asarray(pl[0])

if __name__ == "__main__":
    import time
    t0 = time.time()
    p = gear_poly(12, 0.2, 0.25)
    print(len(p), time.time() - t0, np.hypot(p[:,0], p[:,1]).min(), np.hypot(p[:,0], p[:,1]).max())
    p = gear_poly(96, 0.2, 0.284)
    r = np.hypot(p[:,0], p[:,1]); print(len(p), r.min(), r.max())
