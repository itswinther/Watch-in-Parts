import math, numpy as np, cadquery as cq
from gearlib import gear_poly
import sys; sys.path.insert(0,'/tmp/claude-0/runs/qa2_sonnet/app/tools')
import kernel

RP=0.7; HOLE=0.75; RT=0.45
def tgear(m): return m*(math.pi/2-0.22)

def prism(pts,z0,z1):
    pts=[tuple(p) for p in np.asarray(pts)]
    return cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1-z0)
def cyl(r,z0,z1,x=0.0,y=0.0):
    return cq.Workplane("XY").workplane(offset=z0).center(x,y).circle(r).extrude(z1-z0)
def rotz(w,deg): return w.rotate((0,0,0),(0,0,1),deg)
def mvw(w,x,y): return w.translate((x,y,0))
def u(a,b): return a.union(b)

def gear_solid(z,m,delta_deg,z0,z1):
    p=gear_poly(z,m,tgear(m))
    return rotz(prism(p,z0,z1),delta_deg)

def layer(elem,z0,z1):
    """elem: None | ('collar',) | ('gear',z,m,delta_deg)"""
    if elem[0]=='collar': return cyl(1.15,z0,z1)
    return gear_solid(elem[1],elem[2],elem[3],z0,z1)

def build_mobile(L0,L1,top=None,tall=None):
    """tall: (z_seat, z_top) -> arbor r0.7 up to seat then 0.45 to top"""
    s=cyl(RP,-0.9,1.7 if tall is None else tall[0])
    if L0: s=u(s,layer(L0,0.0,1.0))
    if L1: s=u(s,layer(L1,1.05,1.65))
    if tall: s=u(s,cyl(RT,tall[0]-0.01,tall[1]))
    return s

def build_H(wheel, ):
    z,m,delta=wheel
    s=layer(('gear',z,m,delta),1.05,1.65)
    s=u(s,cyl(1.2,1.05,6.4)); s=u(s,cyl(1.0,6.4,6.9))
    s=s.cut(cyl(HOLE,1.0,7.0))
    return s

def build_hand(rin,rout,R,z0,z1,ang_deg):
    h=cyl(rout,z0,z1)
    arm=prism([(rout*0.8,0.45),(R,0.15),(R,-0.15),(rout*0.8,-0.45)],z0,z1)
    h=u(h,arm).cut(cyl(rin,z0-0.1,z1+0.1))
    return rotz(h,ang_deg)

def write(shape,path):
    kernel.write_step(path,shape)

def load(path):
    return kernel.load_step_part(path,16777216,200000,0.001,0.1,500,120,4096,0.005)
