import math, numpy as np, random, itertools, sys, json
from layout import *

def pen_P(P,mob,parent,case=20.2,detail=False):
    P=dict(P); P['H']=P['M']
    ms=meshes_of(parent)
    pen=0.0; viol=[]
    names=list(mob.keys())
    for a,b in itertools.combinations(names,2):
        if {a,b}=={'M','H'}: continue
        d=np.linalg.norm(P[a]-P[b]); meshing=(a,b) in ms
        for (z0,z1,r0,m0) in mob[a]:
            for (y0,y1,r1,m1) in mob[b]:
                if min(z1,y1)-max(z0,y0)<0.02: continue
                if meshing and (b in m0) and (a in m1): continue
                need=r0+r1+CLR
                if d<need: pen+=(need-d)**2*10+(need-d); viol.append((a,b,round(need-d,2)))
    dd=np.linalg.norm(P['D']-P['M'])
    if dd<6.6: pen+=(6.6-dd)*5
    if pen>0 and not detail: return pen
    R={n:max(r for (_,_,r,_) in mob[n]) for n in names}
    f=lambda c: max(np.linalg.norm(P[n]-c)+R[n] for n in names)
    from scipy.optimize import minimize
    best=minimize(f,np.mean([P[n] for n in names],axis=0),method='Nelder-Mead',options=dict(xatol=1e-3,fatol=1e-3))
    if best.fun>case: pen+=(best.fun-case)*5+(best.fun-case)**2
    if detail: return pen,P,best.x,best.fun,viol
    return pen

def k1_pos(P,dist,sign):
    # K1 at |K1|=dist['K1'] from barrel and 7.2 from K2
    d=np.linalg.norm(P['K2']); a=dist['K1']; b=7.2
    if d>a+b or d<abs(a-b): return None
    x=(a*a-b*b+d*d)/(2*d); h=math.sqrt(max(a*a-x*x,0))
    u=P['K2']/d; v=np.array([-u[1],u[0]])
    return x*u*0+ (np.array([0,0])+ ( (a*a-b*b+d*d)/(2*d) )*u*0) + ( ( (d*d+a*a-b*b)/(2*d) )*u + sign*h*v )

def search6(P8,seed,iters=20000):
    mob,dist,parent=spec('6h')
    rng=random.Random(seed)
    base={n:P8[n] for n in ['barrel','T1','K2','K3','S']}
    names=['M','B','X','D']
    ang={n:rng.uniform(0,2*math.pi) for n in names}
    def build(ang,sign):
        P=dict(base)
        k=k1_pos(P,dist,sign)
        if k is None: return None
        P['K1']=k
        for n in names: 
            P[n]=P[parent[n]]+dist[n]*np.array([math.cos(ang[n]),math.sin(ang[n])])
        return P
    sign=rng.choice([1,-1]); 
    def ev(ang,sign):
        P=build(ang,sign)
        if P is None: return 1e6
        return pen_P(P,mob,parent)
    cur=ev(ang,sign); best=(cur,dict(ang),sign); T=2.0
    for it in range(iters):
        n=rng.choice(names+['sign']); old=ang.get(n); oldsign=sign
        if n=='sign': sign=-sign
        else: ang[n]=old+rng.gauss(0,0.6 if rng.random()<0.5 else 0.1)
        p=ev(ang,sign)
        if p<=cur or rng.random()<math.exp((cur-p)/T):
            cur=p
            if p<best[0]: best=(p,dict(ang),sign)
            if p<1e-9: break
        else:
            if n=='sign': sign=oldsign
            else: ang[n]=old
        T=max(0.02,T*0.9997)
    P=build(best[1],best[2])
    return best[0],P

def parse8(seed):
    mob,dist,parent=spec('8h')
    return mob,dist,parent
if __name__=='__main__':
    # reproduce 8h search for the seed then 6h
    seed=int(sys.argv[1])
    b=search('8h',seed)
    mob,dist,parent=spec('8h')
    pen,P8,c,rad,viol=penalty(b[1],mob,dist,parent,True)
    out={'seed':seed,'pen8':pen,'rad8':rad,'P8':{k:list(map(float,v)) for k,v in P8.items()}}
    if pen<1e-9:
        for s2 in range(6):
            p6,P6=search6(P8,s2)
            if p6<1e-9:
                mob6,d6,par6=spec('6h')
                pen6,P6,c6,rad6,v6=pen_P(P6,mob6,par6,detail=True)
                out['P6']={k:list(map(float,v)) for k,v in P6.items()}; out['rad6']=rad6
                break
    json.dump(out,open('cand_%d.json'%seed,'w'))
    print(seed,pen,rad,out.get('rad6'))
