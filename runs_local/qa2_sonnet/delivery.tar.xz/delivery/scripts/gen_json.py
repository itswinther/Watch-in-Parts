import json, numpy as np
import design as dz
D='/tmp/claude-0/runs/qa2_sonnet/app/delivery/'
def ax(p): return [float(p[0]),float(p[1])]
MAT="AD-C100-HT"
def mk(build):
    P=dz.P8 if build=='8h' else dz.P6
    t='8' if build=='8h' else '6'
    ax_ = lambda n: ax(P[n]) 
    mobiles={
     't1':dict(axis=ax(dz.P8['T1']),parts=['t1']),
     'min':dict(axis=ax(P['M']),parts=['min_arb_'+t,'min_hand_'+t]),
     'bw':dict(axis=ax(P['B']),parts=['bw_'+t]),
     'hr':dict(axis=ax(P['M']),parts=['hr_pipe_'+t,'hr_hand_'+t]),
     'xw':dict(axis=ax(P['X']),parts=['xw_'+t]),
     'day':dict(axis=ax(P['D']),parts=['day_arb_'+t,'day_hand_'+t]),
     'k1':dict(axis=ax(dz.P8['K1']),parts=['k1']),
     'k2':dict(axis=ax(dz.P8['K2']),parts=['k2_'+t]),
     'k3':dict(axis=ax(dz.P8['K3']),parts=['k3_'+t]),
     'sec':dict(axis=ax(dz.P8['S']),parts=['sec_arb','sec_hand']),
    }
    for m in mobiles.values(): m['material']=MAT
    if build=='8h':
        z=dict(zm=12,cB=15,dH=45,eX=30,p1=12)
    else:
        z=dict(zm=16,cB=12,dH=48,eX=32,p1=12)
    KW2,KP3=(48,12) if build=='8h' else (45,15)
    meshes=[("barrel",96,"t1",48),("t1",48,"min",z['zm']),("min",z['zm'],"bw",48),("bw",z['cB'],"hr",z['dH']),
            ("hr",z['dH'],"xw",z['eX']),("xw",12,"day",36),("barrel",96,"k1",z['p1']),("k1",60,"k2",12),("k2",KW2,"k3",KP3),("k3",36,"sec",12)]
    return {"case_centre":[float(dz.C[0]),float(dz.C[1])],"fixed":["frame_base","frame_bridge"],"mobiles":mobiles,
        "meshes":[{"driver":a,"driver_teeth":b,"driven":c,"driven_teeth":d} for a,b,c,d in meshes],
        "hands":{"hour":{"mobile":"hr","part":"hr_hand_"+t},"minute":{"mobile":"min","part":"min_hand_"+t},
                 "seconds":{"mobile":"sec","part":"sec_hand"},"day":{"mobile":"day","part":"day_hand_"+t}}}
json.dump(mk('8h'),open(D+'movement.json','w'),indent=1)
json.dump(mk('6h'),open(D+'variant_6h.json','w'),indent=1)
