import json, math, numpy as np
from layout import spec, HAND, rt

SEED=7
cand=json.load(open('cand_%d.json'%SEED))
C=np.array(cand['c'])
P8={k:np.array(v) for k,v in cand['P8'].items()}
P6={k:np.array(v) for k,v in cand['P6'].items()}
PL_R=20.3
Z=dict(P0=(-0.95,-0.05),L0=(0.0,1.0),L1=(1.05,1.65),BR=(1.7,2.3))

def pitch(z): return 2*math.pi/z

def child_delta(phi,dD,zD,zN):
    """phi: direction angle from D axis to N axis (rad); dD: rotation of D polygon (rad). returns rotation of N polygon (rad)"""
    sD=(phi-dD)/pitch(zD)
    return phi+math.pi-pitch(zN)*(0.5-sD)

def ang(a,b): d=b-a; return math.atan2(d[1],d[0])

def build_defs(build):
    """returns list of mobile defs with gears; computes phases"""
    P=P8 if build=='8h' else P6
    if build=='8h':
        zt=48; zm=12; mB=48; cB=15; dH=45; m2=0.2; eX=30; fX=12; gD=36; mHX=0.2; p1=12
    else:
        zt=48; zm=16; mB=48; cB=12; dH=48; m2=0.2*(zm+mB)/(cB+dH); eX=32; fX=12; gD=36; mHX=m2; p1=12
    B0=P['barrel']
    d={}
    # barrel gear: delta 0, z 96, module .2
    # T1
    phi=ang(B0,P['T1']); dT=child_delta(phi,0.0,96,zt)
    # M (meshes T1)
    phi=ang(P['T1'],P['M']); dM=child_delta(phi,dT,zt,zm)
    phi=ang(P['M'],P['B']); dBw=child_delta(phi,dM,zm,mB)
    dBp=0.0
    phi=ang(P['B'],P['M']); dHw=child_delta(phi,dBp,cB,dH)   # H axis = M axis
    phi=ang(P['M'],P['X']); dXw=child_delta(phi,dHw,dH,eX)
    dXp=0.0
    phi=ang(P['X'],P['D']); dDw=child_delta(phi,dXp,fX,gD)
    # K chain
    phi=ang(B0,P['K1']); dK1p=child_delta(phi,0.0,96,p1)
    return dict(P=P,zt=zt,zm=zm,mB=mB,cB=cB,dH=dH,m2=m2,eX=eX,fX=fX,gD=gD,mHX=mHX,p1=p1,
                dT=dT,dM=dM,dBw=dBw,dBp=dBp,dHw=dHw,dXw=dXw,dXp=dXp,dDw=dDw,dK1p=dK1p)

def k_phases(build):
    """K2,K3,S phases (shared between builds); K1 wheel phase solved from K2 pinion"""
    P=P8  # K2,K3,S same in both
    KW2,KP3=(48,12) if build=='8h' else (45,15)
    dK2p=0.0; dK2w=0.0
    phi=ang(P['K2'],P['K3']); dK3p=child_delta(phi,dK2w,KW2,KP3)
    dK3w=0.0
    phi=ang(P['K3'],P['S']); dSp=child_delta(phi,dK3w,36,12)
    # K1 wheel (D) meshing K2 pinion (N): need sD+sN=.5 -> solve dK1w
    Pb=P8
    phi=ang(Pb['K1'],P['K2'])
    sN=(phi+math.pi-dK2p)/pitch(12)
    # sD=(phi-dD)/pitch(60) = .5 - sN
    dK1w=phi-pitch(60)*(0.5-sN)
    return dict(dK2p=dK2p,dK2w=dK2w,dK3p=dK3p,dK3w=dK3w,dSp=dSp,dK1w=dK1w)
