import os, math, json, numpy as np, cadquery as cq, sys
sys.path.insert(0,'/tmp/claude-0/runs/qa2_sonnet/app/tools')
from parts import *
import design as dz
from layout import HAND
OUT='/tmp/claude-0/runs/qa2_sonnet/app/delivery/parts'
os.makedirs(OUT,exist_ok=True)
deg=math.degrees
C=dz.C
def at(w,p): return w.translate((float(p[0]),float(p[1]),0))
def emit(name,w): write(w,OUT+'/%s.step'%name); print('wrote',name,flush=True)

def gearL(z,m,d,L): 
    return gear_solid(z,m,deg(d),*L)
L0=(0.0,1.0); L1=(1.05,1.65)

def mob(L0g=None,L1g=None,flange=False,tall=None,top=1.65,fl1=False):
    s=cyl(RP,-0.9,top if tall is None else tall[0])
    if L0g: s=u(s,gearL(*L0g,L0))
    if flange: s=u(s,cyl(0.95,0.0,0.4))
    if L1g: s=u(s,gearL(*L1g,L1))
    if fl1: s=u(s,cyl(0.85,1.05,1.65))
    if tall: s=u(s,cyl(RT,tall[0]-0.01,tall[1]))
    return s

def hand(name,P,rin,rout,R,hz,ang_deg): 
    h=build_hand(rin,rout,R,hz[0],hz[1],ang_deg); emit(name,at(h,P))

def frame():
    pts_pivot=[]
    for P in (dz.P8,dz.P6):
        for k,v in P.items():
            if k in ('barrel','H'): continue
            pts_pivot.append(tuple(v))
    pts_pivot=sorted(set((round(a,6),round(b,6)) for a,b in pts_pivot))
    base=cyl(dz.PL_R,-0.95,-0.05,*dz.C)
    for p in pts_pivot: base=base.cut(cyl(0.75,-1.0,0.0,*p))
    base=base.cut(cyl(0.55,-1.0,0.0,0,0))
    emit('frame_base',base)
    br=cyl(dz.PL_R,1.7,2.3,*dz.C)
    br=u(br,cyl(3.0,1.05,1.7,0,0))
    legs=json.load(open('legs.json'))
    for p in legs: br=u(br,cyl(0.9,-0.05,1.7,*p))
    br=br.cut(cyl(1.1,1.0,2.4,0,0))
    tall=set()
    for P in (dz.P8,dz.P6):
        tall.add(('M',)+tuple(np.round(P['M'],6))); tall.add(('D',)+tuple(np.round(P['D'],6)))
    tall.add(('S',)+tuple(np.round(dz.P8['S'],6)))
    for t in tall:
        r=1.25 if t[0]=='M' else 0.75
        br=br.cut(cyl(r,1.6,2.4,t[1],t[2]))
    emit('frame_bridge',br)

def build(build):
    d=dz.build_defs(build); kp=dz.k_phases(build); P=d['P']; tag=build[:2] if build=='8h' else '6h'
    tag='8' if build=='8h' else '6'
    # T1
    if build=='8h':
        emit('t1',at(mob(L0g=(d['zt'],0.2,d['dT'])),P['T1']))
        emit('k1',at(mob(L0g=(12,0.2,d['dK1p']),L1g=(60,0.2,kp['dK1w'])),P['K1']))
        emit('sec_arb',at(mob(L1g=(12,0.2,kp['dSp']),flange=True,tall=(7.6,8.05)),dz.P8['S']))
        hand('sec_hand',dz.P8['S'],0.455,1.0,HAND['sec'][2],HAND['sec'][:2],40)
    KW2,KP3=(48,12) if build=='8h' else (45,15)
    emit('k2_'+tag,at(mob(L0g=(KW2,0.2,kp['dK2w']),L1g=(12,0.2,kp['dK2p'])),dz.P8['K2']))
    emit('k3_'+tag,at(mob(L0g=(KP3,0.2,kp['dK3p']),L1g=(36,0.2,kp['dK3w'])),dz.P8['K3']))
    emit('min_arb_'+tag,at(mob(L0g=(d['zm'],0.2,d['dM']),tall=(7.0,7.55),top=1.65),P['M']))
    emit('bw_'+tag,at(mob(L0g=(d['mB'],0.2,d['dBw']),L1g=(d['cB'],d['m2'],d['dBp'])),P['B']))
    h=build_H((d['dH'],d['m2'],deg(d['dHw'])))
    emit('hr_pipe_'+tag,at(h,P['M']))
    emit('xw_'+tag,at(mob(L0g=(d['fX'],0.2,d['dXp']),L1g=(d['eX'],d['mHX'],d['dXw'])),P['X']))
    emit('day_arb_'+tag,at(mob(L0g=(d['gD'],0.2,d['dDw']),tall=(5.8,6.25),fl1=True),P['D']))
    hand('min_hand_'+tag,P['M'],0.455,1.0,HAND['minute'][2],HAND['minute'][:2],100)
    hand('hr_hand_'+tag,P['M'],1.005,1.7,HAND['hour'][2],HAND['hour'][:2],20)
    hand('day_hand_'+tag,P['D'],0.455,1.0,HAND['day'][2],HAND['day'][:2],250)
    if build=='6h':
        pass

if __name__=='__main__':
    what=sys.argv[1]
    if what=='frame': frame()
    else: build(what)
