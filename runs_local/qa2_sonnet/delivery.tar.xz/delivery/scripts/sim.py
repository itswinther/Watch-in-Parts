import sys; sys.path.insert(0,'/tmp/claude-0/runs/qa2_sonnet/app/tools')
import kernel, numpy as np, math, manifold3d as m3

def Rz(deg, ax, ay):
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    T = np.eye(4); T[0,0]=c; T[0,1]=-s; T[1,0]=s; T[1,1]=c
    T[0,3] = ax - (c*ax - s*ay); T[1,3] = ay - (s*ax + c*ay)
    return T
def Tr(dx,dy,dz):
    T=np.eye(4); T[:3,3]=[dx,dy,dz]; return T
def mv(man,T): return kernel.apply(man,T)

def mesh_test(D, aD, zD, N, aN, zN, shift=0.0, full=False, verbose=False):
    """D,N manifolds (assembled), aD,aN axes (x,y). shift: N moved along line away from D (+) or toward (-)."""
    aD=np.array(aD,float); aN=np.array(aN,float)
    dist=np.linalg.norm(aN-aD)
    m = 2*dist/(zD+zN)
    if shift:
        u=(aN-aD)/dist if dist>1e-9 else np.array([1.0,0])
        N = mv(N, Tr(u[0]*shift,u[1]*shift,0)); aN = aN+u*shift
    nsteps = 8*max(zD,zN) if full else 8
    res = dict(maxint=0.0, engaged_ok=True, mind=0.0, drive=[], m=m)
    def cfg(i):
        ang = i*360.0/(8*zD)
        return mv(D,Rz(ang,*aD)), mv(N,Rz(-ang*zD/zN,*aN))
    pos=[]
    for i in range(nsteps): pos.append((i,False))
    for i in range(0,nsteps,8):
        pos.append((i+1/3,True)); pos.append((i+1/5,True))
    for i,frac in pos:
        d,n = cfg(i)
        v = kernel.ivol(d,n)
        res['maxint']=max(res['maxint'],v)
        if (not frac) and i%4==0 and v==0.0:
            md = kernel.min_distance(d,n,0.5)
            res['mind']=max(res['mind'],md)
            if md>0.1: res['engaged_ok']=False
    for i in range(0,nsteps,8):
        d,n = cfg(i)
        d2 = mv(d, Rz(90.0/zD,*aD))
        reg = (d2 ^ n) - d
        V = reg.volume()
        if reg.is_empty() or V<=0: res['drive'].append((V,0,0)); continue
        bb=reg.bounding_box(); H=bb[5]-bb[2]
        res['drive'].append((V,H,V/H/(0.5*m*m)))
        if not full and i>=8: break
    return res
