import sys, json, math, re, itertools, time, os
sys.path.insert(0,'/tmp/claude-0/runs/qa2_sonnet/app/tools')
import numpy as np, manifold3d as m3
from fractions import Fraction
import kernel
from sim import Rz, Tr, mv
APP='/tmp/claude-0/runs/qa2_sonnet/app/'
DEL=APP+'delivery/'
CASE_R=20.7; CASE_H=13.4
_cache={}
def part(name):
    if name not in _cache:
        _cache[name]=kernel.load_step_part(DEL+'parts/%s.step'%name,16777216,200000,0.001,0.1,500,120,4096,0.005)
    return _cache[name]
BARREL=kernel.tris_to_manifold(kernel.read_stl(APP+'supplied/barrel.stl',10**7,10**9))
def union(ms): return kernel.union(ms)

def load_Y():
    t=open(APP+'datasheets/DS-W04_gear_rating.md').read()
    Y={}
    sec=t[t.index('## 3. Lewis'):]
    for line in sec.splitlines():
        m=re.match(r'\|\s*(\d+)\s*\|(.*)\|',line)
        if m:
            base=int(m.group(1)); cells=[c.strip() for c in m.group(2).split('|')]
            for i,c in enumerate(cells):
                try: Y[base+i]=float(c)
                except: pass
    return Y
Y=load_Y()

class Mov:
    def __init__(self,js,barrel_speed):
        self.js=js; self.bs=barrel_speed  # Fraction turns/h, CW positive
        self.fixed=js['fixed']
        self.mob={}
        for n,m in js['mobiles'].items():
            self.mob[n]=dict(axis=np.array(m['axis'],float),parts=m['parts'],solid=union([part(p) for p in m['parts']]))
        self.mob['barrel']=dict(axis=np.zeros(2),parts=[],solid=BARREL)
        self.frame=union([part(p) for p in self.fixed])
        self.meshes=js['meshes']

def ivol(a,b): return kernel.ivol(a,b)
def rot_about(man,deg,axis): return mv(man,Rz(deg,axis[0],axis[1]))

def mesh_test(D,aD,zD,N,aN,zN,shift=0.0,full=False):
    aD=np.array(aD,float); aN=np.array(aN,float)
    dist=np.linalg.norm(aN-aD); m=2*dist/(zD+zN)
    if shift:
        u=(aN-aD)/dist if dist>1e-9 else np.array([1.0,0]); N=mv(N,Tr(u[0]*shift,u[1]*shift,0)); aN=aN+u*shift
    nsteps=8*max(zD,zN) if full else 8
    res=dict(maxint=0.0,engaged_ok=True,drive=[],m=m,ok=True)
    def cfg(i):
        ang=i*360.0/(8*zD)
        return rot_about(D,ang,aD), rot_about(N,-ang*zD/zN,aN)
    for i in range(nsteps):
        d,n=cfg(i); v=ivol(d,n); res['maxint']=max(res['maxint'],v)
        if i%4==0 and v==0.0:
            if kernel.min_distance(d,n,0.5)>0.1: res['engaged_ok']=False
    for i in range(0,nsteps,8):
        for f in (1/3,1/5):
            d,n=cfg(i+f); res['maxint']=max(res['maxint'],ivol(d,n))
    for i in range(0,nsteps,8):
        d,n=cfg(i); d2=rot_about(d,90.0/zD,aD)
        reg=(d2^n)-d
        V=reg.volume()
        if reg.is_empty() or V<=0: res['drive'].append((0,0,False)); continue
        bb=reg.bounding_box(); H=bb[5]-bb[2]
        res['drive'].append((V,H,V>=0.001 and V/H>0.5*m*m))
        if not full and i>=8: break
    if res['maxint']>0.01 or not res['engaged_ok'] or not all(x[2] for x in res['drive']): res['ok']=False
    return res

def centroid(man):
    me=man.to_mesh(); v=np.asarray(me.vert_properties,float)[:,:3]; t=np.asarray(me.tri_verts)
    a,b,c=v[t[:,0]],v[t[:,1]],v[t[:,2]]
    vol=np.einsum('ij,ij->i',a,np.cross(b,c))/6.0
    cen=(a+b+c)/4.0
    return (vol[:,None]*cen).sum(0)/vol.sum()

def printable(man):
    h=0.05
    bb=man.bounding_box(); lo=np.array(bb[:3])-0.3; hi=np.array(bb[3:])+0.3
    k0=np.floor((lo-0.0113)/h)
    origin=0.0113+h*k0-0.5*h
    shape=tuple(int(x) for x in np.ceil((hi-origin)/h)+1)
    n,dev=kernel.opening_test_slabs(man,origin,shape,h,1.5,1.0,6.0)
    return n>0 and dev<=4.0+1e-9, dev

def mesh_graph(M):
    return M.meshes

def speeds(M,results):
    """BFS speeds from barrel over meshes that pass; returns dict name->Fraction (CW positive), conflict flag"""
    sp={'barrel':M.bs}; conflict=False
    ok=[(i,m) for i,m in enumerate(M.meshes) if results[i]]
    changed=True
    while changed:
        changed=False
        for i,m in ok:
            a,b=m['driver'],m['driven']; za,zb=m['driver_teeth'],m['driven_teeth']
            for x,y,zx,zy in ((a,b,za,zb),(b,a,zb,za)):
                if x in sp:
                    v=-sp[x]*Fraction(zx,zy)
                    if y in sp:
                        if sp[y]!=v: conflict=True
                    else: sp[y]=v; changed=True
    # conflicts: recheck all
    for i,m in ok:
        a,b=m['driver'],m['driven']; za,zb=m['driver_teeth'],m['driven_teeth']
        if a in sp and b in sp and sp[b]!=-sp[a]*Fraction(za,zb): conflict=True
    return sp,conflict

def run(js_name,barrel_speed,full=False,quick=False):
    t0=time.time()
    js=json.load(open(DEL+js_name))
    M=Mov(js,barrel_speed)
    R={}
    log=lambda *a: print(*a,flush=True)
    names=list(M.mob.keys())
    # C2
    c2=True
    items=[('frame',M.frame)]+[(n,M.mob[n]['solid']) for n in names]
    for (a,sa),(b,sb) in itertools.combinations(items,2):
        v=ivol(sa,sb)
        if v>0.01: c2=False; log('C2 fail',a,b,v)
    for a,b in itertools.combinations(M.fixed,2):
        if ivol(part(a),part(b))>0.01: c2=False; log('C2 fixed',a,b)
    for n in names:
        for a,b in itertools.combinations(M.mob[n]['parts'],2):
            v=ivol(part(a),part(b))
            if v>0.01: c2=False; log('C2 mobile parts',n,a,b,v)
    # frame connected
    fp=M.fixed; seen={fp[0]}; fr=[fp[0]]
    while fr:
        x=fr.pop()
        for y in fp:
            if y not in seen and kernel.min_distance(part(x),part(y),0.05)<=0.01: seen.add(y); fr.append(y)
    if len(seen)!=len(fp): c2=False; log('frame not connected')
    R['C2']=c2; log('C2',c2)
    # 1 free
    ok=True
    for n in names:
        s=M.mob[n]['solid']; ax=M.mob[n]['axis']
        for k in range(72):
            v=ivol(rot_about(s,5.0*k,ax),M.frame)
            if v>0.01: ok=False; log('free fail',n,k,v); break
    R[1]=ok; log('1 free',ok)
    # 2 held
    dirs=[(0.3,0,0),(-0.3,0,0),(0,0.3,0),(0,-0.3,0),(0,0,0.3),(0,0,-0.3)]
    ok=True
    for di,d in enumerate(dirs):
        held={}
        for n in names:
            moved=mv(M.mob[n]['solid'],Tr(*d)); held[n]=ivol(moved,M.frame)>0.01
        ch=True
        while ch:
            ch=False
            for n in names:
                if held[n]: continue
                for o in names:
                    if o!=n and held[o] and np.linalg.norm(M.mob[n]['axis']-M.mob[o]['axis'])<=0.01:
                        if ivol(mv(M.mob[n]['solid'],Tr(*d)),M.mob[o]['solid'])>0.01: held[n]=True; ch=True; break
        for n in names:
            if not held[n]: ok=False; log('not held',n,d)
    R[2]=ok; log('2 held',ok)
    # 3 seated
    ok=True
    for n in names:
        ps=M.mob[n]['parts']
        if len(ps)<2: continue
        for p in ps:
            others=union([part(q) for q in ps if q!=p])
            for d in [(0.3,0,0),(-0.3,0,0),(0,0.3,0),(0,-0.3,0)]:
                if ivol(mv(part(p),Tr(*d)),others)<=0.01: ok=False; log('seat xy',n,p,d)
            if max(ivol(mv(part(p),Tr(0,0,0.3)),others),ivol(mv(part(p),Tr(0,0,-0.3)),others))<=0.01: ok=False; log('seat z',n,p)
        # chain within 0.02
        seen={ps[0]}; fr=[ps[0]]
        while fr:
            x=fr.pop()
            for y in ps:
                if y not in seen and kernel.min_distance(part(x),part(y),0.05)<=0.02: seen.add(y); fr.append(y)
        if len(seen)!=len(ps): ok=False; log('seat chain',n)
    R[3]=ok; log('3 seated',ok)
    # 4,5 mesh tests
    res0=[];resA=[];resT=[]
    for i,m in enumerate(M.meshes):
        D=M.mob[m['driver']]; N=M.mob[m['driven']]
        r0=mesh_test(D['solid'],D['axis'],m['driver_teeth'],N['solid'],N['axis'],m['driven_teeth'],0.0,full)
        ra=mesh_test(D['solid'],D['axis'],m['driver_teeth'],N['solid'],N['axis'],m['driven_teeth'],0.03,full)
        rt=mesh_test(D['solid'],D['axis'],m['driver_teeth'],N['solid'],N['axis'],m['driven_teeth'],-0.03,full)
        res0.append(r0['ok']);resA.append(ra['ok']);resT.append(rt['ok'])
        log('mesh',m['driver'],m['driven'],r0['ok'],ra['ok'],rt['ok'],'maxint %.4f %.4f %.4f'%(r0['maxint'],ra['maxint'],rt['maxint']),
            [round(x[1],3) for x in r0['drive']][:1],[round(x[0]/x[1]/(0.5*r0['m']**2),2) if x[1] else 0 for x in r0['drive']][:1],
            [round(x[0]/x[1]/(0.5*ra['m']**2),2) if x[1] else 0 for x in ra['drive']][:1],[round(x[0]/x[1]/(0.5*rt['m']**2),2) if x[1] else 0 for x in rt['drive']][:1])
        m['_H']=min([x[1] for x in r0['drive']]) if r0['drive'] else 0
        m['_m']=r0['m']
    sp,conflict=speeds(M,res0)
    reach=all(n in sp for n in names)
    R[4]=bool(len(M.meshes)>0 and all(res0) and not conflict and reach)
    R[5]=bool(all(resA) and all(resT))
    log('4 train',R[4],'5 shifted',R[5],'speeds',{k:str(v) for k,v in sp.items()},conflict)
    # 6 non-mesh pairs
    ms={(m['driver'],m['driven']) for m in M.meshes}; ms|={(b,a) for a,b in ms}
    ok=True
    spd={n:sp.get(n,Fraction(0)) for n in names}
    for a,b in itertools.combinations(names,2):
        if (a,b) in ms: continue
        Ra=np.abs(kernel.verts(M.mob[a]['solid'])[:,:2]-M.mob[a]['axis']).max()*1.5
        Rb=np.abs(kernel.verts(M.mob[b]['solid'])[:,:2]-M.mob[b]['axis']).max()*1.5
        if np.linalg.norm(M.mob[a]['axis']-M.mob[b]['axis'])>Ra+Rb+1: continue
        sa,sb=spd[a],spd[b]
        # turning angle: CW positive speeds -> rotate by -angle
        fast=max(abs(sa),abs(sb))
        def pose(ta,tb): # ta,tb in fraction of full turn of faster ; angle = -360*speed/fast*t
            A=rot_about(M.mob[a]['solid'],-360.0*float(sa/fast)*ta if fast else 0,M.mob[a]['axis'])
            B=rot_about(M.mob[b]['solid'],-360.0*float(sb/fast)*ta if fast else 0,M.mob[b]['axis'])
            return A,B
        bad=0
        for k in range(144):
            A,B=pose(k/144.0,0)
            if ivol(A,B)>0.01: bad+=1
        if sa!=sb:
            for k in range(144):
                A=M.mob[a]['solid']; B=rot_about(M.mob[b]['solid'],360.0*k/144.0,M.mob[b]['axis'])
                if ivol(A,B)>0.01: bad+=1
        if bad: ok=False; log('6 fail',a,b,bad)
    R[6]=ok; log('6 nothing else collides',ok)
    # hands
    def hand_ok(key,turn_h):
        h=js['hands'].get(key)
        if not h: return False
        mn=h['mobile']
        return mn in sp and sp[mn]==Fraction(turn_h) and h['part'] in M.mob[mn]['parts']
    R[7]=hand_ok('hour',Fraction(1,12)); R[8]=hand_ok('minute',1); R[9]=hand_ok('seconds',60)
    log('7,8,9',R[7],R[8],R[9])
    hm=js['hands']['hour']['mobile']; mm=js['hands']['minute']['mobile']
    R[10]=bool(np.linalg.norm(M.mob[hm]['axis']-M.mob[mm]['axis'])<=0.01)
    ftop=M.frame.bounding_box()[5]
    ok=True
    for key,minr in (('hour',5),('minute',5),('seconds',5)):
        h=js['hands'][key]; pm=part(h['part']); ax=M.mob[h['mobile']]['axis']
        v=kernel.verts(pm); reach=np.hypot(v[:,0]-ax[0],v[:,1]-ax[1]).max()
        cz=centroid(pm); cd=np.hypot(cz[0]-ax[0],cz[1]-ax[1])
        o=(reach>=minr) and (pm.bounding_box()[2]>=ftop) and cd>=0.5
        if not o: ok=False
        log('hand',key,round(reach,2),round(pm.bounding_box()[2],2),round(ftop,2),round(cd,2))
    R[11]=ok
    cc=np.array(js['case_centre']); ok=True; zlo=1e9; zhi=-1e9
    for n in names:
        v=kernel.verts(M.mob[n]['solid']); ax=M.mob[n]['axis']
        r=np.hypot(v[:,0]-ax[0],v[:,1]-ax[1]).max()+np.linalg.norm(ax-cc)
        if r>CASE_R: ok=False; log('case fail',n,r)
        zlo=min(zlo,v[:,2].min()); zhi=max(zhi,v[:,2].max())
    vf=kernel.verts(M.frame)
    if np.hypot(vf[:,0]-cc[0],vf[:,1]-cc[1]).max()>CASE_R: ok=False; log('frame outside case')
    zlo=min(zlo,vf[:,2].min()); zhi=max(zhi,vf[:,2].max())
    if zhi-zlo>CASE_H: ok=False
    R[12]=ok; log('12 case',ok,round(zhi-zlo,2))
    # 13 printable
    ok=True
    allp=set(M.fixed)|{p for n in M.js['mobiles'] for p in M.js['mobiles'][n]['parts']}
    for p in sorted(allp):
        o,dev=printable(part(p))
        if not o: ok=False
        log('print',p,o,round(dev,2))
    R[13]=ok
    # 14 strength
    Tb=70.1; ok=True
    # BFS path
    adj={}
    okm=[(i,m) for i,m in enumerate(M.meshes) if res0[i]]
    from collections import deque
    sm=js['hands']['seconds']['mobile']; prev={'barrel':None}; q=deque(['barrel'])
    while q:
        x=q.popleft()
        for i,m in okm:
            for a,b in ((m['driver'],m['driven']),(m['driven'],m['driver'])):
                if a==x and b not in prev: prev[b]=(x,i); q.append(b)
    if sm not in prev: ok=False
    else:
        path=[]; x=sm
        while prev[x]: path.append(prev[x][1]); x=prev[x][0]
        for i in path:
            m=M.meshes[i]; D,Nn=m['driver'],m['driven']; zD,zN=m['driver_teeth'],m['driven_teeth']
            nD=abs(sp[D]); TD=Tb*float(abs(sp['barrel']/sp[D])); mm_=m['_m']
            F=TD/(mm_*zD/2); b=m['_H']
            for g,zg in ((D,zD),(Nn,zN)):
                if g=='barrel': continue
                sig=F/(b*mm_*Y[zg])
                # allowable
                mat='AD-C100-HT'; allow=725.0
                log('  rated',D,Nn,g,'sigma %.1f'%sig,'allow',allow,'b',round(b,3))
                if sig>allow: ok=False
    R[14]=ok; log('14 strength',ok)
    R['time']=time.time()-t0
    return R,M,sp

def part2(js,M,sp,key='day'):
    R={}
    h=js['hands'].get('day')
    ok=bool(h) and h['mobile'] in M.mob and h['part'] in M.mob[h['mobile']]['parts'] and h['part'] not in [js['hands'][k]['part'] for k in ('hour','minute','seconds')]
    R['C3']=ok
    R['p21']= ok and sp.get(h['mobile'])==Fraction(1,24)
    if ok:
        hm=js['hands']['hour']['mobile']; ax=M.mob[h['mobile']]['axis']
        pm=part(h['part']); v=kernel.verts(pm); reach=np.hypot(v[:,0]-ax[0],v[:,1]-ax[1]).max(); cz=centroid(pm)
        R['p22']=bool(np.linalg.norm(ax-M.mob[hm]['axis'])>=6 and reach>=3 and pm.bounding_box()[2]>=M.frame.bounding_box()[5] and np.hypot(cz[0]-ax[0],cz[1]-ax[1])>=0.5)
    else: R['p22']=False
    return R

if __name__=='__main__':
    which=sys.argv[1]; full=len(sys.argv)>2 and sys.argv[2]=='full'
    if which=='8h':
        js=json.load(open(DEL+'movement.json')); R,M,sp=run('movement.json',Fraction(1,8),full)
    else:
        js=json.load(open(DEL+'variant_6h.json')); R,M,sp=run('variant_6h.json',Fraction(1,6),full)
    print(R); print(part2(js,M,sp))
