import math, numpy as np, random, itertools
from scipy.optimize import minimize

CLR = 0.3
COL = 1.15
HAND = dict(day=(5.8,6.2,4.0), hour=(6.4,6.8,5.6), minute=(7.0,7.4,7.0), sec=(7.6,8.0,7.0))
def rt(z,m): return (z/2.0+1.0)*m

def spec(build):
    if build=='8h':
        zt=48; zm=12; mB=48; cB=15; dH=45; m2=0.2; eX=30; fX=12; gD=36; mHX=0.2
        p1=12
    else:
        zt=48; zm=16; mB=48; cB=12; dH=48; m2=0.2*(zm+mB)/(cB+dH); eX=32; fX=12; gD=36; mHX=m2
        p1=12
    KW2,KP3=(48,12) if build=='8h' else (45,15)
    L0=(0,1.0); L1=(1.05,1.65); FL=(0,0.4)
    mob={}
    def D(z,r,mesh=()): return (z[0],z[1],r,tuple(mesh))
    ARB=D(L1,0.75)
    mob['T1']=[D(L0,rt(zt,.2),('barrel','M')),ARB]
    mob['M']=[D(L0,rt(zm,.2),('T1','B')),D((1.0,7.6),0.75),D(HAND['minute'][:2],HAND['minute'][2]+0.1)]
    mob['B']=[D(L0,rt(mB,.2),('M',)),D(L1,rt(cB,m2),('H',))]
    mob['H']=[D(L1,rt(dH,m2),('B','X')),D((1.65,6.4),1.25),D((6.4,6.9),1.05),D(HAND['hour'][:2],HAND['hour'][2]+0.1)]
    mob['X']=[D(L1,rt(eX,mHX),('H',)),D(L0,rt(fX,.2),('D',))]
    mob['D']=[D(L0,rt(gD,.2),('X',)),D((1.0,6.3),0.75),D(L1,0.85),D(HAND['day'][:2],HAND['day'][2]+0.1)]
    mob['K1']=[D(L0,rt(p1,.2),('barrel',)),D(L1,rt(60,.2),('K2',))]
    mob['K2']=[D(L1,rt(12,.2),('K1',)),D(L0,rt(KW2,.2),('K3',))]
    mob['K3']=[D(L0,rt(KP3,.2),('K2',)),D(L1,rt(36,.2),('S',))]
    mob['S']=[D(L1,rt(12,.2),('K3',)),D(FL,0.95),D((1.65,8.3),0.75),D(HAND['sec'][:2],HAND['sec'][2]+0.1)]
    mob['barrel']=[D(L0,9.8,('T1','K1')),D((1.05,1.7),3.0),D((1.7,5.6),1.0)]
    dist=dict(
        T1=0.1*(96+zt), M=0.1*(zt+zm), B=0.1*(zm+mB), X=mHX*(dH+eX)/2, D=0.1*(fX+gD),
        K1=0.1*(96+p1), K2=0.1*(60+12), K3=0.1*(48+12), S=0.1*(36+12))
    parent=dict(T1='barrel',M='T1',B='M',X='M',D='X',K1='barrel',K2='K1',K3='K2',S='K3')
    return mob,dist,parent

MESHPAIRS_EXTRA=[('barrel','T1'),('barrel','K1')]
def pos_from(ang,dist,parent):
    P={'barrel':np.zeros(2)}
    for n in ['T1','M','B','X','D','K1','K2','K3','S']:
        a=ang[n]; P[n]=P[parent[n]]+dist[n]*np.array([math.cos(a),math.sin(a)])
    return P

def meshes_of(parent):
    s=set()
    for c,p in parent.items(): s.add((p,c)); s.add((c,p))
    for p in [('M','H'),('B','H'),('X','H')]: s.add(p); s.add(p[::-1])
    return s

def penalty(ang,mob,dist,parent,detail=False,case=20.7-0.5):
    P=pos_from(ang,dist,parent); P['H']=P['M']
    ms=meshes_of(parent)
    pen=0.0; viol=[]
    names=list(mob.keys())
    # hand/arbor etc with H, M coaxial
    for a,b in itertools.combinations(names,2):
        if a=='M' and b=='H' or a=='H' and b=='M': continue
        d=np.linalg.norm(P[a]-P[b])
        meshing=(a,b) in ms
        for (z0,z1,r0,m0) in mob[a]:
            for (y0,y1,r1,m1) in mob[b]:
                if min(z1,y1)-max(z0,y0) < 0.02: continue
                if meshing and (b in m0) and (a in m1): continue
                need=r0+r1+CLR
                if d<need:
                    pen+= (need-d)**2*10+ (need-d); viol.append((a,b,round(need-d,2)))
    # barrel mesh special-case: barrel discs vs T1,K1: skip mesh gear discs (handled above by m flags)
    if pen>0 and not detail: return pen
    R={}
    for n in names:
        R[n]=max(r for (_,_,r,_) in mob[n])
    R['H']=max(r for (_,_,r,_) in mob['H']); R['M']=max(R['M'],max(r for (_,_,r,_) in mob['M']))
    def f(c): return max(np.linalg.norm(P[n]-c)+R[n] for n in names)
    best=minimize(f,np.mean([P[n] for n in names],axis=0),method='Nelder-Mead',options=dict(xatol=1e-3,fatol=1e-3))
    c=best.x; rad=best.fun
    if rad>case: pen+=(rad-case)*5+ (rad-case)**2
    # D axis distance from M >=6.6
    dd=np.linalg.norm(P['D']-P['M'])
    if dd<6.6: pen+=(6.6-dd)*5
    # keep mobile axes inside plate disc, barrel too
    if detail: return pen,P,c,rad,viol
    return pen

def search(build,seed=0,iters=40000):
    mob,dist,parent=spec(build)
    rng=random.Random(seed)
    names=['T1','M','B','X','D','K1','K2','K3','S']
    ang={n:rng.uniform(0,2*math.pi) for n in names}
    cur=penalty(ang,mob,dist,parent); best=(cur,dict(ang))
    T=2.0
    for it in range(iters):
        n=rng.choice(names)
        old=ang[n]
        ang[n]=old+rng.gauss(0,0.6 if rng.random()<0.5 else 0.1)
        p=penalty(ang,mob,dist,parent)
        if p<=cur or rng.random()<math.exp((cur-p)/T):
            cur=p
            if p<best[0]: best=(p,dict(ang))
            if p<1e-9: break
        else: ang[n]=old
        T=max(0.02,T*0.9998)
    return best

if __name__=='__main__':
    import sys
    build=sys.argv[1]; seed=int(sys.argv[2])
    b=search(build,seed)
    print(build,seed,b[0]); 
    mob,dist,parent=spec(build)
    pen,P,c,rad,viol=penalty(b[1],mob,dist,parent,True)
    print(pen,rad,c,viol)
    print({k:math.degrees(v)%360 for k,v in b[1].items()})
