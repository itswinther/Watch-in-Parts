import sys, json, math, itertools, numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/qa2_sonnet/app/work')
import qa, kernel
from sim import Tr, mv
DEL=qa.DEL
js=json.load(open(DEL+'movement.json'))
names=list(js['fixed'])
for m in js['mobiles'].values(): names+=m['parts']
solids={n:qa.part(n) for n in names}; solids['barrel']=qa.BARREL
allb=np.array([s.bounding_box() for s in solids.values()])
top=allb[:,5].max()+5.0
poses={}
for n,s in solids.items():
    zmin=s.bounding_box()[2]
    sh=top+0.4-zmin
    k=int(math.ceil(sh/0.19))
    poses[n]=[sh*(1-i/k) for i in range(k+1)]
def blocked(A,B):
    sa,sb=solids[A],solids[B]; ba=sa.bounding_box(); bb=sb.bounding_box()
    for dz in poses[A]:
        if ba[2]+dz>=bb[5] : continue
        if ba[0]>=bb[3] or bb[0]>=ba[3] or ba[1]>=bb[4] or bb[1]>=ba[4]: return False
        if ba[5]+dz<=bb[2]: continue
        if kernel.ivol(mv(sa,Tr(0,0,dz)),sb)>0.01: return True
    return False
order_names=list(solids.keys())
bl={}
for A in order_names:
    for B in order_names:
        if A!=B: bl[(A,B)]=blocked(A,B)
edges={n:set() for n in order_names}
indeg={n:0 for n in order_names}
bad=[]
for A,B in itertools.combinations(order_names,2):
    ab,ba=bl[(A,B)],bl[(B,A)]
    if ab and ba: bad.append((A,B))
    elif ab:   # A blocked by B -> A before B
        edges[A].add(B)
    elif ba: edges[B].add(A)
print('both-blocked pairs',bad)
for a in edges:
    for b in edges[a]: indeg[b]+=1
# Kahn, prefer parts with larger z last? keep deterministic
ready=sorted([n for n in order_names if indeg[n]==0],key=lambda n:solids[n].bounding_box()[2])
order=[]
while ready:
    n=ready.pop(0); order.append(n)
    for b in edges[n]:
        indeg[b]-=1
        if indeg[b]==0: ready.append(b)
    ready.sort(key=lambda n:solids[n].bounding_box()[2])
print('order',order, len(order)==len(order_names))
assert len(order)==len(order_names)
paths={n:[np.array(Tr(0,0,dz)).tolist() for dz in poses[n]] for n in order}
json.dump({'order':order,'paths':paths},open(DEL+'assembly.json','w'))
# verify
ok=True
for i,n in enumerate(order):
    for dz in poses[n]:
        for p in order[:i]:
            if kernel.ivol(mv(solids[n],Tr(0,0,dz)),solids[p])>0.01: ok=False; print('collide',n,p,dz)
print('assembly verified',ok, {n:len(poses[n]) for n in order})
