"""Own re-implementation of Part 4 (assembly) of the acceptance test."""
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import check, kernel   # noqa: E402

doc = json.load(open(os.path.join(DELIV, "movement.json")))
asm = json.load(open(os.path.join(DELIV, "assembly.json")))
names = list(doc["fixed"]) + [p for m in doc["mobiles"].values() for p in m["parts"]] + ["barrel"]
parts = {n: check.load(n) for n in names}
allp = kernel.union(list(parts.values()))
bb = np.array(allp.bounding_box()); glo, ghi = bb[:3] - 5, bb[3:] + 5
order = []
for n in asm["order"]:
    if n in parts and n not in order:
        order.append(n)
placed = [n for n in names if n not in order]
ok_count = 0
for n in order:
    P = [np.array(T, float) for T in asm["paths"].get(n, [])]
    ok = 2 <= len(P) <= 1500
    for T in P:
        R = T[:3, :3]
        ok &= bool(np.all(np.isfinite(T))) and np.allclose(R.T @ R, np.eye(3), atol=1e-6) and abs(np.linalg.det(R) - 1) < 1e-6 and np.allclose(T[3], [0, 0, 0, 1], atol=1e-6)
    ok &= np.allclose(P[-1], np.eye(4), atol=1e-6)
    V = kernel.verts(parts[n])
    b0 = kernel.apply(parts[n], P[0]).bounding_box()
    ok &= any(b0[i] > ghi[i] or b0[i + 3] < glo[i] for i in range(3))
    Vh = np.c_[V, np.ones(len(V))]
    for a, b in zip(P, P[1:]):
        ok &= float(np.max(np.linalg.norm((Vh @ b.T - Vh @ a.T)[:, :3], axis=1))) <= 0.2
    worst = 0
    for T in P:
        moved = kernel.apply(parts[n], T)
        for q in placed:
            worst = max(worst, kernel.ivol(moved, parts[q]))
    ok &= worst <= 0.01
    print("%-18s poses %4d worst %.5f %s" % (n, len(P), worst, "installed" if ok else "NOT INSTALLED"))
    ok_count += ok
    placed.append(n)
print("installed %d / %d" % (ok_count, len(order)))
