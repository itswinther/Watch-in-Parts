"""2-D version of the mesh test, for quick design checks."""
import math, sys, os
import numpy as np
import manifold3d as m3
from gears import *

def mesh2d(csD, cD, zD, csN, cN, zN, thN, shift=0.0, steps=None):
    """csD, csN local; N at rotation thN in assembled pose. shift: N moved away (+) from D."""
    cD = np.array(cD, float); cN = np.array(cN, float)
    u = (cN - cD) / np.linalg.norm(cN - cD)
    a0 = np.linalg.norm(cN - cD)
    cN2 = cN + shift * u
    m = 2 * a0 / (zD + zN)
    nst = 8 * max(zD, zN)
    worst = 0; mind_ok = True; minVH = 1e9
    def pose(i):
        aD = math.radians(i * 360.0 / (8 * zD))
        aN = -aD * zD / zN
        return placed(csD, cD, aD), placed(csN, cN2, thN + aN)
    for i in range(nst):
        fr = [i] + ([i + 1/3, i + 1/5] if i % 8 == 0 else [])
        for f in fr:
            D, N = pose(f)
            worst = max(worst, (D ^ N).area())
        if i % 8 == 0:
            D, N = pose(i)
            aD = math.radians(i * 360.0 / (8 * zD)) + math.radians(90.0 / zD)
            D2 = placed(csD, cD, aD)
            reg = (D2 - D) ^ N
            minVH = min(minVH, reg.area())
    return worst, minVH, 0.5 * m * m
