"""Layout of the calibre: axes, z levels, gears, parts. Pure data plus small helpers.
Frame: right-handed, mm, dial side +z. Barrel BR-096-20 on x=0,y=0 (supplied)."""
import math

# ---------------------------------------------------------------- axes
B = (0.0, 0.0)                      # barrel
M = (10.6, 0.0)                     # centre arbor: minute + hour (case centre)
CC = M                              # case centre


def circ_inter(c1, r1, c2, r2, upper=True):
    dx, dy = c2[0] - c1[0], c2[1] - c1[1]
    d = math.hypot(dx, dy)
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(r1 * r1 - a * a)
    px, py = c1[0] + a * dx / d, c1[1] + a * dy / d
    s = 1 if upper else -1
    return (px - s * h * dy / d, py + s * h * dx / d)


def polar(c, r, deg):
    return (c[0] + r * math.cos(math.radians(deg)), c[1] + r * math.sin(math.radians(deg)))


M_BA, M_AM = 0.2, 0.45               # modules: barrel/pinion, change wheels
A = circ_inter(B, M_BA * (96 + 12) / 2, M, M_AM * 42 / 2, upper=True)   # intermediate wheel
T = polar(M, 0.2 * (80 + 10) / 2, -60.0)       # third wheel
S = polar(T, 0.2 * (75 + 10) / 2, 20.0)        # seconds wheel
W = polar(M, 0.2 * (15 + 45) / 2, 90.0)        # minute wheel (motion work)
I = polar(M, 0.4 * (12 + 18) / 2, 210.0)       # 24-hour intermediate
D = polar(I, 0.4 * (18 + 24) / 2, 290.0)       # 24-hour wheel
PILLARS = [(-3.0, 12.0), (-3.0, -12.0), (27.0, 6.0)]

# ---------------------------------------------------------------- z levels
P0 = (-1.0, -0.2)       # main plate (back)
P1 = (4.3, 5.1)         # train plate
P2 = (8.2, 9.0)         # dial
COCK = (1.15, 4.3)      # barrel cock (post under the train plate)
PLATE_R = 20.4          # plate radius about the case centre

HOLE_CLR = 0.05         # pivot clearance (radial)
FIT_CLR = 0.005         # press-fit (hand, cannon pinion) radial gap

# ---------------------------------------------------------------- the time shown in the assembled position
TIME_H = 10 + 10.5 / 60.0                       # 10:10:30
ANG_HOUR = (TIME_H % 12) / 12 * 360
ANG_MIN = (TIME_H * 60 % 60) / 60 * 360
ANG_SEC = (TIME_H * 3600 % 60) / 60 * 360
ANG_DAY = TIME_H / 24 * 360                     # clockwise from +y (12 o'clock)
