# Calibre: going train, hands, 6-hour variant

Run `python3 build.py` then `python3 assembly.py` from this folder. `check.py` and `check_asm.py` are my own
re-implementation of the acceptance test, used for verification.

Train (barrel BR-096-20, module 0.2, 25 deg, 96 teeth, clockwise):

| mesh | 8-hour build | 6-hour variant | module |
|---|---|---|---|
| barrel -> intermediate pinion | 96/12 | 96/12 | 0.2 |
| intermediate wheel -> centre pinion (change wheels, same centre distance) | 21/21 | 18/24 | 0.45 |
| centre wheel -> third pinion | 80/10 | 80/10 | 0.2 (x = -0.2/+0.2) |
| third wheel -> seconds pinion | 75/10 | 75/10 | 0.2 (x = -0.2/+0.2) |
| cannon pinion -> minute wheel | 15/45 | 15/45 | 0.2 |
| minute-wheel pinion -> hour wheel | 12/48 | 12/48 | 0.2 |
| hour pinion -> 24-hour intermediate | 12/18 | 12/18 | 0.4 |
| 24-hour intermediate -> 24-hour wheel | 18/24 | 18/24 | 0.4 |

Centre: 1 turn/h; hour wheel 1/12; seconds 60; 24-hour wheel 1/24 turn/h, all clockwise.
Only the intermediate wheel and the centre arbor differ between builds; the frame and every other part is shared.
Frame: main plate, train plate, dial, six pillars, barrel cock. Hands sit above the dial.
