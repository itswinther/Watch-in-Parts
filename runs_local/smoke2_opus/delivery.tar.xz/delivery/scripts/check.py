"""Own re-implementation of the acceptance test (instruction.md), used to verify the design.
    python3 check.py movement.json 8 [checks...]
    python3 check.py variant_6h.json 6
    python3 check.py assembly"""
import json
import math
import os
import pickle
import sys
import time
from fractions import Fraction as Fr
import numpy as np
import manifold3d as m3

HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
APP = os.path.dirname(DELIV)
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel    # noqa: E402

CACHE = os.environ.get("PART_CACHE", "/tmp/partcache")
TOL = 0.01


def load(name):
    if name == "barrel":
        t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 6, 10 ** 8)
        return kernel.tris_to_part(t, 0.005)
    p = os.path.join(DELIV, "parts", name + ".step")
    os.makedirs(CACHE, exist_ok=True)
    c = os.path.join(CACHE, name + ".pkl")
    if os.path.exists(c) and os.path.getmtime(c) > os.path.getmtime(p):
        with open(c, "rb") as f:
            v, t = pickle.load(f)
        return m3.Manifold(m3.Mesh(vert_properties=v, tri_verts=t))
    man = kernel.load_step_part(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096, 0.005)
    mesh = man.to_mesh()
    with open(c, "wb") as f:
        pickle.dump((np.asarray(mesh.vert_properties, np.float32), np.asarray(mesh.tri_verts, np.uint32)), f)
    return man


def rotz(c, ang_deg):
    a = math.radians(ang_deg)
    ca, sa = math.cos(a), math.sin(a)
    cx, cy = c
    return np.array([[ca, -sa, 0, cx - ca * cx + sa * cy], [sa, ca, 0, cy - sa * cx - ca * cy],
                     [0, 0, 1, 0], [0, 0, 0, 1.0]])


def tr(d):
    return kernel.translation(d)


def iv(a, b):
    return kernel.ivol(a, b)


class Mv:
    def __init__(self, fn, period_h):
        self.doc = json.load(open(os.path.join(DELIV, fn)))
        d = self.doc
        self.period = period_h
        self.parts = {}
        for n in d["fixed"]:
            self.parts[n] = load(n)
        self.mob = {"barrel": {"axis": [0.0, 0.0], "parts": ["barrel"]}}
        self.parts["barrel"] = load("barrel")
        for k, m in d["mobiles"].items():
            self.mob[k] = m
            for n in m["parts"]:
                self.parts[n] = load(n)
        self.frame = kernel.union([self.parts[n] for n in d["fixed"]])
        self.msolid = {k: kernel.union([self.parts[n] for n in m["parts"]]) for k, m in self.mob.items()}
        self.speeds()

    def speeds(self):
        """turns per hour, CCW positive."""
        sp = {"barrel": Fr(-1, self.period)}
        self.conflict = False
        changed = True
        while changed:
            changed = False
            for e in self.doc["meshes"]:
                a, b = e["driver"], e["driven"]
                r = Fr(e["driver_teeth"], e["driven_teeth"])
                for x, y, rr in ((a, b, r), (b, a, 1 / r)):
                    if x in sp:
                        v = -sp[x] * rr
                        if y in sp and sp[y] != v:
                            self.conflict = True
                        if y not in sp:
                            sp[y] = v
                            changed = True
        self.sp = sp

    def ax(self, k):
        return self.mob[k]["axis"]


def check_C2(mv):
    ok = True
    names = list(mv.mob)
    for i, a in enumerate(names):
        v = iv(mv.frame, mv.msolid[a])
        if v > TOL:
            print("  C2 frame x", a, v); ok = False
        for b in names[i + 1:]:
            v = iv(mv.msolid[a], mv.msolid[b])
            if v > TOL:
                print("  C2", a, b, v); ok = False
    fx = mv.doc["fixed"]
    for i, a in enumerate(fx):
        for b in fx[i + 1:]:
            v = iv(mv.parts[a], mv.parts[b])
            if v > TOL:
                print("  C2 fixed", a, b, v); ok = False
    for k, m in mv.mob.items():
        ps = m["parts"]
        for i, a in enumerate(ps):
            for b in ps[i + 1:]:
                v = iv(mv.parts[a], mv.parts[b])
                if v > TOL:
                    print("  C2 mobile parts", a, b, v); ok = False
    # frame joined
    adj = {a: set() for a in fx}
    for i, a in enumerate(fx):
        for b in fx[i + 1:]:
            if kernel.min_distance(mv.parts[a], mv.parts[b], 0.05) <= 0.01:
                adj[a].add(b); adj[b].add(a)
    seen, st = {fx[0]}, [fx[0]]
    while st:
        x = st.pop()
        for y in adj[x]:
            if y not in seen:
                seen.add(y); st.append(y)
    if len(seen) != len(fx):
        print("  C2 frame not joined", set(fx) - seen); ok = False
    return ok


def check_free(mv):
    ok = True
    for k in mv.mob:
        worst = 0
        for s in range(72):
            worst = max(worst, iv(mv.frame, kernel.apply(mv.msolid[k], rotz(mv.ax(k), 5 * s))))
        if worst > TOL:
            print("  free:", k, worst); ok = False
    return ok


DIRS = [(0.3, 0, 0), (-0.3, 0, 0), (0, 0.3, 0), (0, -0.3, 0), (0, 0, 0.3), (0, 0, -0.3)]


def check_held(mv):
    ok = True
    for d in DIRS:
        held = {}
        moved = {k: kernel.apply(mv.msolid[k], tr(d)) for k in mv.mob}
        for k in mv.mob:
            held[k] = iv(mv.frame, moved[k]) > TOL
        changed = True
        while changed:
            changed = False
            for k in mv.mob:
                if held[k]:
                    continue
                for j in mv.mob:
                    if j != k and held[j] and math.dist(mv.ax(j), mv.ax(k)) <= 0.01 and iv(moved[k], mv.msolid[j]) > TOL:
                        held[k] = True; changed = True
                        break
        bad = [k for k in mv.mob if not held[k]]
        if bad:
            print("  held: not held in", d, bad); ok = False
    return ok


def check_seated(mv):
    ok = True
    for k, m in mv.mob.items():
        ps = m["parts"]
        if len(ps) < 2:
            continue
        for p in ps:
            others = kernel.union([mv.parts[q] for q in ps if q != p])
            for d in DIRS[:4]:
                v = iv(kernel.apply(mv.parts[p], tr(d)), others)
                if v <= TOL:
                    print("  seated:", k, p, d, v); ok = False
            vz = [iv(kernel.apply(mv.parts[p], tr(d)), others) for d in DIRS[4:]]
            if max(vz) <= TOL:
                print("  seated z:", k, p, vz); ok = False
        # chain
        adj = {p: set() for p in ps}
        for i, a in enumerate(ps):
            for b in ps[i + 1:]:
                if kernel.min_distance(mv.parts[a], mv.parts[b], 0.1) <= 0.02:
                    adj[a].add(b); adj[b].add(a)
        seen, st = {ps[0]}, [ps[0]]
        while st:
            x = st.pop()
            for y in adj[x]:
                if y not in seen:
                    seen.add(y); st.append(y)
        if len(seen) != len(ps):
            print("  seated chain:", k, set(ps) - seen); ok = False
    return ok


def mesh_test(mv, e, shift=0.0, verbose=True):
    Dn, Nn = e["driver"], e["driven"]
    zD, zN = e["driver_teeth"], e["driven_teeth"]
    cD = np.array(mv.ax(Dn), float)
    cN = np.array(mv.ax(Nn), float)
    dist = np.linalg.norm(cN - cD)
    u = (cN - cD) / dist if dist > 0.01 else np.array([1.0, 0])
    cN2 = cN + shift * u
    SN = kernel.apply(mv.msolid[Nn], tr([shift * u[0], shift * u[1], 0]))
    SD = mv.msolid[Dn]
    m = 2 * dist / (zD + zN)
    n = 8 * max(zD, zN)
    worst, maxgap, minVH, minV = 0.0, 0.0, 1e9, 1e9

    def poseD(f):
        return kernel.apply(SD, rotz(cD, f * 360.0 / (8 * zD)))

    def poseN(f):
        return kernel.apply(SN, rotz(cN2, -f * 360.0 / (8 * zD) * zD / zN))
    for i in range(n):
        fs = [i] + ([i + 1 / 3, i + 1 / 5] if i % 8 == 0 else [])
        for f in fs:
            Dp, Np = poseD(f), poseN(f)
            v = iv(Dp, Np)
            worst = max(worst, v)
            if f == i and i % 4 == 0 and v == 0:
                g = kernel.min_distance(Dp, Np, 0.5)
                maxgap = max(maxgap, g)
            if f == i and i % 8 == 0:
                D2 = kernel.apply(SD, rotz(cD, i * 360.0 / (8 * zD) + 90.0 / zD))
                reg = (D2 - Dp) ^ Np
                V = reg.volume()
                if V > 0:
                    bb = reg.bounding_box()
                    Hh = bb[5] - bb[2]
                    minVH = min(minVH, V / Hh)
                else:
                    minVH = 0
                minV = min(minV, V)
    ok = worst <= TOL and maxgap <= 0.1 and minV >= 0.001 and minVH > 0.5 * m * m
    if verbose:
        print("  mesh %s->%s shift %+.2f: jam %.5f gap %.4f V %.4f V/H %.4f (need > %.4f) %s"
              % (Dn, Nn, shift, worst, maxgap, minV, minVH, 0.5 * m * m, "ok" if ok else "FAIL"))
    return ok


def check_mesh(mv, shifts=(0.0,)):
    ok = True
    for e in mv.doc["meshes"]:
        for s in shifts:
            ok &= mesh_test(mv, e, s)
    return ok


def check_collide(mv):
    ok = True
    meshed = {frozenset((e["driver"], e["driven"])) for e in mv.doc["meshes"]}
    names = list(mv.mob)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if frozenset((a, b)) in meshed:
                continue
            A, Bs = mv.msolid[a], mv.msolid[b]
            if not kernel.bbox_overlap(A, Bs):
                continue
            wa, wb = float(mv.sp.get(a, 0)), float(mv.sp.get(b, 0))
            fast = max(abs(wa), abs(wb))
            worst = 0
            seqs = []
            if fast > 0:
                seqs.append([(360.0 * wa / fast * k / 144, 360.0 * wb / fast * k / 144) for k in range(144)])
            if wa != wb:
                rel = abs(wa - wb)
                seqs.append([(360.0 * wa / rel * k / 144, 360.0 * wb / rel * k / 144) for k in range(144)])
            for seq in seqs:
                for ta, tb in seq:
                    worst = max(worst, iv(kernel.apply(A, rotz(mv.ax(a), ta)), kernel.apply(Bs, rotz(mv.ax(b), tb))))
            if worst > TOL:
                print("  collide", a, b, worst); ok = False
    return ok


def check_hands(mv):
    ok = True
    h = mv.doc["hands"]
    exp = {"hour": Fr(-1, 12), "minute": Fr(-1, 1), "seconds": Fr(-60, 1), "day": Fr(-1, 24)}
    if mv.conflict:
        print("  speed conflict"); ok = False
    for k, e in h.items():
        sp = mv.sp.get(e["mobile"])
        print("  hand %-7s mobile %-12s speed %s rev/h (want %s)" % (k, e["mobile"], sp, exp[k]))
        ok &= sp == exp[k]
    d = math.dist(mv.ax(h["hour"]["mobile"]), mv.ax(h["minute"]["mobile"]))
    ok &= d <= 0.01
    ftop = max(mv.parts[n].bounding_box()[5] for n in mv.doc["fixed"])
    for k, e in h.items():
        P = mv.parts[e["part"]]
        c = np.array(mv.ax(e["mobile"]))
        V = kernel.verts(P)
        reach = np.max(np.hypot(V[:, 0] - c[0], V[:, 1] - c[1]))
        low = P.bounding_box()[2]
        # centre of volume
        mesh = P.to_mesh()
        v = np.asarray(mesh.vert_properties)[:, :3].astype(float)
        t = np.asarray(mesh.tri_verts)
        a, b, cc = v[t[:, 0]], v[t[:, 1]], v[t[:, 2]]
        vol6 = np.einsum("ij,ij->i", a, np.cross(b, cc))
        cen = ((a + b + cc) * vol6[:, None]).sum(0) / (4 * vol6.sum())
        cd = math.hypot(cen[0] - c[0], cen[1] - c[1])
        need = 3 if k == "day" else 5
        good = reach >= need and low >= ftop and cd >= 0.5
        print("  hand %-7s reach %.2f low %.3f frame top %.3f centroid off %.2f %s" % (k, reach, low, ftop, cd, good))
        ok &= good
    dd = math.dist(mv.ax(h["day"]["mobile"]), mv.ax(h["hour"]["mobile"]))
    print("  day axis from hour axis %.2f" % dd)
    ok &= dd >= 6
    return ok


def check_case(mv):
    ok = True
    cc = np.array(mv.doc["case_centre"])
    zs = []
    for n in mv.doc["fixed"]:
        V = kernel.verts(mv.parts[n])
        r = np.max(np.hypot(V[:, 0] - cc[0], V[:, 1] - cc[1]))
        if r > 20.7:
            print("  case: fixed", n, r); ok = False
    worst = 0
    for k in mv.mob:
        c = np.array(mv.ax(k))
        V = kernel.verts(mv.msolid[k])
        r = np.max(np.hypot(V[:, 0] - c[0], V[:, 1] - c[1])) + np.linalg.norm(c - cc)
        worst = max(worst, r)
        if r > 20.7:
            print("  case: mobile", k, r); ok = False
    allp = kernel.union([mv.frame] + list(mv.msolid.values()))
    bb = allp.bounding_box()
    print("  case: worst radius %.3f, height %.3f (z %.3f..%.3f)" % (worst, bb[5] - bb[2], bb[2], bb[5]))
    ok &= bb[5] - bb[2] <= 13.4
    return ok


def printable(man):
    bb = man.bounding_box()
    h = 0.05
    lo = np.array(bb[:3]) - 0.2
    k = np.floor((lo - 0.0113) / h)
    origin = k * h + 0.0113 - h / 2          # voxel centres at origin + (i+0.5)h = 0.05k+0.0113
    shape = tuple(int(v) for v in np.ceil((np.array(bb[3:]) + 0.2 - origin) / h).astype(int) + 1)
    n, dev = kernel.opening_test_slabs(man, origin, shape, h, 1.5, 1.0, 4.0)
    return n > 0 and dev * h <= 0.2 + 1e-9, dev * h


def check_print(mv, names=None):
    ok = True
    for n in (names or [p for p in mv.parts if p != "barrel"]):
        t = time.time()
        good, dev = printable(mv.parts[n])
        print("  print %-18s dev %.3f mm %s (%.1fs)" % (n, dev, "ok" if good else "FAIL", time.time() - t))
        ok &= good
    return ok


def main(argv):
    fn, per = argv[0], int(argv[1])
    which = argv[2:] or ["C2", "free", "held", "seated", "mesh", "mesh_shift", "collide", "hands", "case", "print"]
    t0 = time.time()
    mv = Mv(fn, per)
    print("loaded %.1fs" % (time.time() - t0))
    fns = {"C2": check_C2, "free": check_free, "held": check_held, "seated": check_seated,
           "mesh": check_mesh, "mesh_shift": lambda m: check_mesh(m, (0.03, -0.03)),
           "collide": check_collide, "hands": check_hands, "case": check_case, "print": check_print}
    for w in which:
        t = time.time()
        r = fns[w](mv)
        print("%-10s %s  (%.1fs)" % (w, "PASS" if r else "FAIL", time.time() - t))
        sys.stdout.flush()


if __name__ == "__main__":
    main(sys.argv[1:])
