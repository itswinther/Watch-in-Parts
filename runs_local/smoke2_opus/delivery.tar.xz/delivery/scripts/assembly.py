"""Writes ../assembly.json: the assembly order of movement.json and a straight path for each part.
Every part comes down along -z from above the movement into its place; the plates and the barrel cock
are lowered over the arbors, the hands are pressed on last."""
import json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import check   # noqa: E402  (loads the part solids exactly as the inspection does)

ORDER = ["plate_main", "pillar_1", "pillar_2", "pillar_3", "barrel", "inter_8h", "centre_8h", "third_wheel",
         "seconds_arbor", "barrel_cock", "plate_train", "pillar_4", "pillar_5", "pillar_6", "cannon_pinion",
         "minute_wheel", "hour_wheel", "day_intermediate", "day_wheel", "dial", "day_hand", "seconds_hand",
         "hour_hand", "minute_hand"]
STEP = 0.19


def main():
    doc = json.load(open(os.path.join(DELIV, "movement.json")))
    names = list(doc["fixed"]) + [p for m in doc["mobiles"].values() for p in m["parts"]] + ["barrel"]
    assert sorted(names) == sorted(ORDER), set(names) ^ set(ORDER)
    parts = {n: check.load(n) for n in names}
    top = max(p.bounding_box()[5] for p in parts.values())
    paths = {}
    for n in ORDER:
        zmin = parts[n].bounding_box()[2]
        dz = (top + 5.0) - zmin + 0.3
        k = int(math.ceil(dz / STEP))
        paths[n] = [[[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, round(dz * (1 - i / k), 6)], [0, 0, 0, 1]]
                    for i in range(k + 1)]
        paths[n][-1][2][3] = 0
    with open(os.path.join(DELIV, "assembly.json"), "w") as f:
        json.dump({"order": ORDER, "paths": paths}, f)


if __name__ == "__main__":
    main()
