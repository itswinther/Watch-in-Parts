"""Involute spur gear profiles (polygons) and backlash centring of meshing pairs.
All lengths mm, angles radians unless named *_deg."""
import math
import numpy as np
import manifold3d as m3

ALPHA = math.radians(25.0)          # pressure angle of the barrel BR-096-20; used for every gear


def inv(a):
    return math.tan(a) - a


def gear_points(z, m, x=0.0, thin=0.0, phase=0.0, ha=1.0, hf=1.25, nflank=12, ntip=3, nroot=5, alpha=ALPHA):
    """Closed CCW polygon (N x 2) of a spur gear with z teeth, module m, profile shift x (in modules),
    tooth thickness reduced by `thin` (arc on the pitch circle, backlash allowance), one tooth centred
    on the angle `phase`. Involute flanks; below the base circle a radial flank; flat root and tip arcs."""
    rp = m * z / 2.0
    rb = rp * math.cos(alpha)
    ra = rp + m * (ha + x)
    rf = rp - m * (hf - x)
    s = m * (math.pi / 2 + 2 * x * math.tan(alpha)) - thin

    def psi(r):
        return s / (2 * rp) + inv(alpha) - inv(math.acos(min(1.0, rb / r)))
    r0 = max(rb, rf)
    t = (1 - np.cos(np.linspace(0, math.pi / 2, nflank))) if r0 == rb else np.linspace(0, 1, nflank)
    radii = r0 + (ra - r0) * t
    radii[-1] = ra
    flank = [(r, psi(r)) for r in radii]
    if rf < rb - 1e-9:
        flank = [(rf, psi(rb))] + flank
    ptip = psi(ra)
    if ptip <= 0:
        raise ValueError("pointed teeth: z=%d m=%g x=%g" % (z, m, x))
    proot = flank[0][1]
    pitch = 2 * math.pi / z
    if pitch - 2 * proot <= 0:
        raise ValueError("no root space")
    pts = []
    for k in range(z):
        c = phase + k * pitch
        for r, p in flank:                                   # right flank, root -> tip
            pts.append((r * math.cos(c - p), r * math.sin(c - p)))
        for j in range(1, ntip + 1):                         # tip arc
            a = c - ptip + 2 * ptip * j / (ntip + 1)
            pts.append((ra * math.cos(a), ra * math.sin(a)))
        for r, p in reversed(flank):                         # left flank, tip -> root
            pts.append((r * math.cos(c + p), r * math.sin(c + p)))
        a0, a1 = c + proot, c + pitch - proot
        for j in range(1, nroot + 1):                        # root arc
            a = a0 + (a1 - a0) * j / (nroot + 1)
            pts.append((rf * math.cos(a), rf * math.sin(a)))
    return np.array(pts), dict(rp=rp, rb=rb, ra=ra, rf=rf, s=s)


def cs_from_points(pts):
    return m3.CrossSection([np.asarray(pts, float).tolist()], m3.FillRule.Positive)


def placed(cs, centre, angle):
    return cs.rotate(math.degrees(angle)).translate(list(centre))


def overlap_area(a, b):
    return (a ^ b).area()


def centre_phase(csD, cD, csN, cN, zD, zN, nscan=240, probe=None):
    """Rotation of N (radians, about its centre) that puts the pair in the middle of its backlash.
    csD/csN are local cross-sections (centred on the origin); D stays at angle 0.
    Returns (angle, free_width) with free_width the angular width (rad of N) of the jam-free range."""
    D = placed(csD, cD, 0.0)
    pitchN = 2 * math.pi / zN
    angs = np.linspace(0, pitchN, nscan, endpoint=False)
    free = np.array([overlap_area(D, placed(csN, cN, a)) < 1e-9 for a in angs])
    if free.all() or not free.any():
        raise RuntimeError("centring failed: all free=%s" % free.all())
    # find the longest cyclic run of free samples
    n = len(free)
    best, bstart = 0, 0
    for i in range(n):
        if free[i] and not free[i - 1]:
            j = i
            while free[j % n]:
                j += 1
            if j - i > best:
                best, bstart = j - i, i
    step = pitchN / nscan

    def is_free(a):
        return overlap_area(D, placed(csN, cN, a)) < 1e-9
    # refine both edges by bisection
    lo_in, lo_out = angs[bstart], angs[bstart] - step
    for _ in range(30):
        mid = 0.5 * (lo_in + lo_out)
        if is_free(mid):
            lo_in = mid
        else:
            lo_out = mid
    hi_in, hi_out = angs[bstart] + (best - 1) * step, angs[bstart] + best * step
    for _ in range(30):
        mid = 0.5 * (hi_in + hi_out)
        if is_free(mid):
            hi_in = mid
        else:
            hi_out = mid
    return 0.5 * (lo_in + hi_in), hi_in - lo_in
