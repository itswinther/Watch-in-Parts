"""Builds every part (STEP), movement.json, variant_6h.json and assembly.json.
    python3 build.py            (run from this folder; writes into ../)"""
import json
import math
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DELIV = os.path.dirname(HERE)
APP = os.path.dirname(DELIV)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel                       # noqa: E402
import layout as L                  # noqa: E402
from gears import gear_points, cs_from_points, centre_phase   # noqa: E402

PARTS_DIR = os.path.join(DELIV, "parts")

# ============================================================== gears
# name: (axis, z, module, shift x, thinning)
THIN2, THIN4 = 0.0225, 0.03
GEARS = {
    "A_pin":   (L.A, 12, 0.2, 0.0, 0.015),        # meshes the barrel (barrel already thinned 0.03)
    "A_whl8":  (L.A, 21, 0.45, 0.0, THIN4),
    "A_whl6":  (L.A, 18, 0.45, 0.0, THIN4),
    "M_pin8":  (L.M, 21, 0.45, 0.0, THIN4),
    "M_pin6":  (L.M, 24, 0.45, 0.0, THIN4),
    "M_whl":   (L.M, 80, 0.2, -0.2, THIN2),
    "T_pin":   (L.T, 10, 0.2, 0.2, THIN2),
    "T_whl":   (L.T, 75, 0.2, -0.2, THIN2),
    "S_pin":   (L.S, 10, 0.2, 0.2, THIN2),
    "C_pin":   (L.M, 15, 0.2, 0.0, THIN2),        # cannon pinion
    "W_whl":   (L.W, 45, 0.2, 0.0, THIN2),
    "W_pin":   (L.W, 12, 0.2, 0.0, THIN2),
    "H_whl":   (L.M, 48, 0.2, 0.0, THIN2),
    "H_pin":   (L.M, 12, 0.4, 0.0, THIN4),
    "I_whl":   (L.I, 18, 0.4, 0.0, THIN4),
    "D_whl":   (L.D, 24, 0.4, 0.0, THIN4),
}
# (driver gear, driven gear): the driven gear's phase is centred in the backlash of the pair
CENTRING = [("barrel", "A_pin"), ("M_pin8", "A_whl8"), ("M_pin6", "A_whl6"), ("M_whl", "T_pin"),
            ("T_whl", "S_pin"), ("C_pin", "W_whl"), ("W_pin", "H_whl"), ("H_pin", "I_whl"),
            ("I_whl", "D_whl")]


def local_cs(name, phase=0.0):
    ax, z, m, x, th = GEARS[name]
    pts, info = gear_points(z, m, x=x, thin=th, phase=phase, nflank=3 if z >= 40 else 5, ntip=0, nroot=1)
    return cs_from_points(pts), pts, info


def barrel_cs():
    t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 6, 10 ** 8)
    return kernel.tris_to_part(t, 0.005).slice(0.5)


def compute_phases():
    ph = {n: 0.0 for n in GEARS}
    for drv, drn in CENTRING:
        if drv == "barrel":
            csD, cD, zD = barrel_cs(), L.B, 96
        else:
            csD, _, _ = local_cs(drv, ph[drv])
            csD = csD.translate(list(GEARS[drv][0]))
            cD, zD = (0.0, 0.0), GEARS[drv][1]
        csN, _, _ = local_cs(drn, 0.0)
        th, w = centre_phase(csD, cD, csN, GEARS[drn][0], zD, GEARS[drn][1])
        ph[drn] = th
        print("centred %-7s against %-7s: phase %.5f rad, free %.4f mm on pitch circle"
              % (drn, drv, th, w * GEARS[drn][2] * GEARS[drn][1] / 2))
    return ph


# ============================================================== solids (CadQuery)
import cadquery as cq                                      # noqa: E402


def ngon(c, r, hole=False):
    """Regular polygon standing in for a circle of radius r: for a solid its corners lie on r (the
    solid stays inside the circle); for a hole its sides touch r (the hole stays outside the circle)."""
    n = 180 if r > 5 else 32
    R = r / math.cos(math.pi / n) if hole else r
    return [(c[0] + R * math.cos(2 * math.pi * k / n), c[1] + R * math.sin(2 * math.pi * k / n)) for k in range(n)]


def cyl(c, z0, z1, r, hole=False):
    return prism(ngon(c, r, hole), z0, z1)


def hole(c, z0, z1, r):
    return cyl(c, z0, z1, r, hole=True)


def prism(pts_world, z0, z1):
    return cq.Workplane("XY", origin=(0, 0, z0)).polyline([tuple(p) for p in pts_world]).close().extrude(z1 - z0)


def gear_solid(name, phase, z0, z1):
    ax = GEARS[name][0]
    _, pts, _ = local_cs(name, phase)
    return prism(pts + np.array(ax), z0, z1)


def fuse(objs):
    s = objs[0]
    for o in objs[1:]:
        s = s.union(o)
    return s.clean()


def arbor_stack(c, segs):
    """segs: list of (z0, z1, r) cylinders on axis c."""
    return [cyl(c, z0, z1, r) for z0, z1, r in segs]


def hand_solid(c, z0, z1, bore, hub, length, angle_deg, w_root, w_tip, tail, w_tail):
    """A hand: hub disc and a tapered pointer at angle_deg clockwise from +y, with a short tail."""
    a = math.radians(angle_deg)
    u = np.array([math.sin(a), math.cos(a)])          # pointing direction
    v = np.array([-u[1], u[0]])
    cc = np.array(c)
    pts = [cc - tail * u - w_tail / 2 * v, cc + 0.0 * u - w_root / 2 * v, cc + length * u - w_tip / 2 * v,
           cc + length * u + w_tip / 2 * v, cc + 0.0 * u + w_root / 2 * v, cc - tail * u + w_tail / 2 * v]
    body = prism(pts, z0, z1).union(cyl(c, z0, z1, hub))
    return body.cut(hole(c, z0 - 1, z1 + 1, bore)).clean()


def plate_solid(z0, z1, holes):
    p = cyl(L.CC, z0, z1, L.PLATE_R)
    for c, r in holes:
        p = p.cut(hole(c, z0 - 1, z1 + 1, r))
    return p.clean()


def build_parts(ph):
    H = L.HOLE_CLR
    F = L.FIT_CLR
    P = {}
    # ---------------- frame
    P["plate_main"] = plate_solid(*L.P0, [(L.B, 0.5 + H), (L.A, 0.4 + H), (L.M, 0.5 + H), (L.T, 0.4 + H),
                                          (L.S, 0.4 + H)])
    for i, c in enumerate(L.PILLARS):
        P["pillar_%d" % (i + 1)] = cyl(c, L.P0[1], L.P1[0], 0.8)
        P["pillar_%d" % (i + 4)] = cyl(c, L.P1[1], L.P2[0], 0.8)
    P["barrel_cock"] = cyl(L.B, L.COCK[0], L.COCK[1], 1.4).cut(hole(L.B, L.COCK[0] - 1, 1.75, 0.5 + H)).clean()
    P["plate_train"] = plate_solid(*L.P1, [(L.A, 0.4 + H), (L.M, 0.5 + H), (L.T, 0.4 + H), (L.S, 0.4 + H),
                                           (L.W, 0.4 + H), (L.I, 0.4 + H), (L.D, 0.4 + H)])
    P["dial"] = plate_solid(*L.P2, [(L.M, 0.95 + H), (L.S, 0.4 + H), (L.D, 0.4 + H), (L.W, 0.4 + H),
                                    (L.I, 0.4 + H)])
    # ---------------- intermediate wheel (barrel pinion + change wheel)
    for b in ("8", "6"):
        P["inter_%sh" % b] = fuse(arbor_stack(L.A, [(-0.9, 0.05, 0.4), (1.0, 1.35, 0.4), (2.05, 4.05, 0.4),
                                                    (4.0, 4.2, 0.6), (4.15, 5.0, 0.4)])
                                  + [gear_solid("A_pin", ph["A_pin"], 0.0, 1.0),
                                     gear_solid("A_whl" + b, ph["A_whl" + b], 1.3, 2.1)])
    # ---------------- centre arbor (change pinion + third-wheel driver)
    for b in ("8", "6"):
        P["centre_%sh" % b] = fuse(arbor_stack(L.M, [(-0.9, 1.35, 0.5), (2.05, 2.35, 0.5), (3.05, 4.0, 0.5),
                                                     (3.95, 4.2, 0.8), (4.15, 5.2, 0.5), (5.2, 10.0, 0.35),
                                                     (10.0, 10.3, 0.25)])
                                   + [gear_solid("M_pin" + b, ph["M_pin" + b], 1.3, 2.1),
                                      gear_solid("M_whl", ph["M_whl"], 2.3, 3.1)])
    P["cannon_pinion"] = gear_solid("C_pin", ph["C_pin"], 5.2, 6.0).cut(hole(L.M, 4, 7, 0.35 + F)).clean()
    P["minute_hand"] = hand_solid(L.M, 10.0, 10.3, 0.25 + F, 0.6, 15.0, L.ANG_MIN, 0.7, 0.35, 2.0, 0.6)
    # ---------------- third wheel
    P["third_wheel"] = fuse(arbor_stack(L.T, [(-0.9, 0.0, 0.4), (0.0, 0.3, 0.6), (0.25, 2.35, 0.4),
                                              (3.05, 3.35, 0.4), (4.05, 5.0, 0.4)])
                            + [gear_solid("T_pin", ph["T_pin"], 2.3, 3.1),
                               gear_solid("T_whl", ph["T_whl"], 3.3, 4.1)])
    # ---------------- seconds wheel
    P["seconds_arbor"] = fuse(arbor_stack(L.S, [(-0.9, 0.0, 0.4), (0.0, 0.3, 0.6), (0.25, 3.35, 0.4),
                                                (4.05, 9.1, 0.4), (9.1, 9.4, 0.25)])
                              + [gear_solid("S_pin", ph["S_pin"], 3.3, 4.1)])
    P["seconds_hand"] = hand_solid(L.S, 9.1, 9.4, 0.25 + F, 0.6, 6.0, L.ANG_SEC, 0.6, 0.35, 1.8, 0.6)
    # ---------------- motion work: minute wheel
    P["minute_wheel"] = fuse(arbor_stack(L.W, [(4.4, 5.25, 0.4), (5.95, 6.25, 0.4), (6.95, 7.85, 0.4),
                                               (7.8, 8.1, 0.6), (8.05, 8.9, 0.4)])
                             + [gear_solid("W_whl", ph["W_whl"], 5.2, 6.0),
                                gear_solid("W_pin", ph["W_pin"], 6.2, 7.0)])
    # ---------------- hour wheel
    hw = fuse([gear_solid("H_whl", ph["H_whl"], 6.2, 7.0), cyl(L.M, 6.95, 7.25, 0.95),
               gear_solid("H_pin", ph["H_pin"], 7.2, 8.0), cyl(L.M, 7.95, 9.55, 0.95), cyl(L.M, 9.5, 9.85, 0.7)])
    P["hour_wheel"] = hw.cut(hole(L.M, 5, 11, 0.35 + L.HOLE_CLR)).clean()
    P["hour_hand"] = hand_solid(L.M, 9.55, 9.85, 0.7 + F, 1.1, 10.0, L.ANG_HOUR, 0.9, 0.45, 1.8, 0.8)
    # ---------------- 24-hour train
    P["day_intermediate"] = fuse(arbor_stack(L.I, [(4.4, 5.2, 0.4), (5.2, 5.5, 0.6), (5.45, 7.25, 0.4),
                                                   (7.95, 8.9, 0.4)])
                                 + [gear_solid("I_whl", ph["I_whl"], 7.2, 8.0)])
    P["day_wheel"] = fuse(arbor_stack(L.D, [(4.4, 5.2, 0.4), (5.2, 5.5, 0.6), (5.45, 7.25, 0.4),
                                            (7.95, 9.1, 0.4), (9.1, 9.4, 0.25)])
                          + [gear_solid("D_whl", ph["D_whl"], 7.2, 8.0)])
    P["day_hand"] = hand_solid(L.D, 9.1, 9.4, 0.25 + F, 0.6, 4.0, L.ANG_DAY, 0.6, 0.35, 1.2, 0.6)
    return P


# ============================================================== movement files
FIXED = ["plate_main", "pillar_1", "pillar_2", "pillar_3", "barrel_cock", "plate_train",
         "pillar_4", "pillar_5", "pillar_6", "dial"]


def movement(b):
    mob = {
        "intermediate": {"axis": list(L.A), "parts": ["inter_%sh" % b]},
        "centre": {"axis": list(L.M), "parts": ["centre_%sh" % b, "cannon_pinion", "minute_hand"]},
        "third": {"axis": list(L.T), "parts": ["third_wheel"]},
        "seconds": {"axis": list(L.S), "parts": ["seconds_arbor", "seconds_hand"]},
        "minute_wheel": {"axis": list(L.W), "parts": ["minute_wheel"]},
        "hour": {"axis": list(L.M), "parts": ["hour_wheel", "hour_hand"]},
        "day_intermediate": {"axis": list(L.I), "parts": ["day_intermediate"]},
        "day": {"axis": list(L.D), "parts": ["day_wheel", "day_hand"]},
    }
    za, zm = (21, 21) if b == "8" else (18, 24)
    meshes = [
        {"driver": "barrel", "driver_teeth": 96, "driven": "intermediate", "driven_teeth": 12},
        {"driver": "intermediate", "driver_teeth": za, "driven": "centre", "driven_teeth": zm},
        {"driver": "centre", "driver_teeth": 80, "driven": "third", "driven_teeth": 10},
        {"driver": "third", "driver_teeth": 75, "driven": "seconds", "driven_teeth": 10},
        {"driver": "centre", "driver_teeth": 15, "driven": "minute_wheel", "driven_teeth": 45},
        {"driver": "minute_wheel", "driver_teeth": 12, "driven": "hour", "driven_teeth": 48},
        {"driver": "hour", "driver_teeth": 12, "driven": "day_intermediate", "driven_teeth": 18},
        {"driver": "day_intermediate", "driver_teeth": 18, "driven": "day", "driven_teeth": 24},
    ]
    hands = {"hour": {"mobile": "hour", "part": "hour_hand"},
             "minute": {"mobile": "centre", "part": "minute_hand"},
             "seconds": {"mobile": "seconds", "part": "seconds_hand"},
             "day": {"mobile": "day", "part": "day_hand"}}
    return {"case_centre": list(L.CC), "fixed": FIXED, "mobiles": mob, "meshes": meshes, "hands": hands}


def main():
    os.makedirs(PARTS_DIR, exist_ok=True)
    ph = compute_phases()
    P = build_parts(ph)
    only = set(sys.argv[1:])
    for n, s in P.items():
        if only and n not in only:
            continue
        vals = s.vals()
        assert len(vals) == 1, (n, len(vals))
        solids = vals[0].Solids()
        assert len(solids) == 1, (n, len(solids))
        kernel.write_step(os.path.join(PARTS_DIR, n + ".step"), solids[0])
        print("wrote", n)
    for b, fn in (("8", "movement.json"), ("6", "variant_6h.json")):
        with open(os.path.join(DELIV, fn), "w") as f:
            json.dump(movement(b), f, indent=1)


if __name__ == "__main__":
    main()
