"""Designer's own run of the checks of QA-W100 rev A on the delivery folder (not the official inspection).

    python3 inspect_qa.py movement.json|variant_6h.json [check names...]   e.g. c2 free held seated mesh pairs
                                                                             hands case print strength asm
"""
import json
import math
import os
import pickle
import sys
from fractions import Fraction

import numpy as np
import manifold3d as m3

HERE = os.path.dirname(os.path.abspath(__file__))
DELIVERY = os.path.dirname(HERE)
APP = os.path.dirname(DELIVERY)
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel  # noqa: E402

TOL = 0.01
CASE_R, CASE_H = 20.7, 13.4
T_BARREL = 70.1
ALLOW = {"AD-C100-HT": 725.0, "AD-CW614N": 110.0}
CACHE = os.environ.get("QA_CACHE", "")


def lewis_table():
    Y = {}
    with open(os.path.join(APP, "datasheets", "DS-W04_gear_rating.md")) as f:
        for line in f:
            c = [x.strip() for x in line.strip().strip("|").split("|")]
            if len(c) == 11 and c[0].isdigit():
                for k in range(10):
                    try:
                        Y[int(c[0]) + k] = float(c[1 + k])
                    except ValueError:
                        pass
    return Y


def load(name):
    if name == "barrel":
        t = kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 7, 10 ** 9)
        return kernel.tris_to_manifold(t)          # drum and arbor: two bodies in one mesh
    p = os.path.join(DELIVERY, "parts", name + ".step")
    key = None
    if CACHE:
        key = os.path.join(CACHE, "%s_%d_%d.pkl" % (name, os.path.getsize(p), int(os.path.getmtime(p) * 1000)))
        if os.path.exists(key):
            with open(key, "rb") as f:
                tris = pickle.load(f)
            return kernel.tris_to_part(tris, 0.005)
    tris = kernel.read_step(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096)
    if key:
        with open(key, "wb") as f:
            pickle.dump(tris, f)
    return kernel.tris_to_part(tris, 0.005)


def rot(man, axis, deg):
    """Counter-clockwise (seen from +z) by deg about the vertical through axis."""
    return man.translate([-axis[0], -axis[1], 0]).rotate([0, 0, deg]).translate([axis[0], axis[1], 0])


def shift(man, d):
    return man.translate(list(d))


class Movement:
    def __init__(self, fn, barrel_hours):
        with open(os.path.join(DELIVERY, fn)) as f:
            self.doc = json.load(f)
        d = self.doc
        self.part = {}
        names = list(d["fixed"]) + [p for m in d["mobiles"].values() for p in m["parts"]]
        for n in names:
            self.part[n] = load(n)
        self.part["barrel"] = load("barrel")
        self.frame = kernel.union([self.part[n] for n in d["fixed"]])
        self.mob = {"barrel": self.part["barrel"]}
        self.axis = {"barrel": (0.0, 0.0)}
        for k, m in d["mobiles"].items():
            self.mob[k] = kernel.union([self.part[n] for n in m["parts"]])
            self.axis[k] = tuple(m["axis"])
        # speeds, turns per hour, clockwise positive
        self.speed = {"barrel": Fraction(1, barrel_hours)}
        self.consistent = True
        changed = True
        while changed:
            changed = False
            for e in d["meshes"]:
                for a, b, za, zb in ((e["driver"], e["driven"], e["driver_teeth"], e["driven_teeth"]),
                                     (e["driven"], e["driver"], e["driven_teeth"], e["driver_teeth"])):
                    if a in self.speed:
                        s = -self.speed[a] * Fraction(za, zb)
                        if b not in self.speed:
                            self.speed[b] = s
                            changed = True
                        elif self.speed[b] != s:
                            self.consistent = False


def c2(M):
    ok = True
    d = M.doc
    solids = [("frame", M.frame)] + list(M.mob.items())
    for i in range(len(solids)):
        for j in range(i + 1, len(solids)):
            v = kernel.ivol(solids[i][1], solids[j][1])
            if v > TOL * 0.2:
                print("  C2 intersect", solids[i][0], solids[j][0], v)
            ok &= v <= TOL
    fx = d["fixed"]
    for i in range(len(fx)):
        for j in range(i + 1, len(fx)):
            v = kernel.ivol(M.part[fx[i]], M.part[fx[j]])
            ok &= v <= TOL
            print("  fixed", fx[i], fx[j], "ivol %.5f dist %.5f" % (v, kernel.min_distance(M.part[fx[i]], M.part[fx[j]], 1.0)))
    joined = {fx[0]}
    grow = True
    while grow:
        grow = False
        for a in fx:
            if a not in joined and any(kernel.min_distance(M.part[a], M.part[b], 1.0) <= 0.01 for b in joined):
                joined.add(a)
                grow = True
    ok &= len(joined) == len(fx)
    for k, m in d["mobiles"].items():
        ps = m["parts"]
        for i in range(len(ps)):
            for j in range(i + 1, len(ps)):
                v = kernel.ivol(M.part[ps[i]], M.part[ps[j]])
                if v > 0:
                    print("  mobile parts", ps[i], ps[j], v)
                ok &= v <= TOL
    return ok


def free(M):
    ok = True
    for k, man in M.mob.items():
        worst = max(kernel.ivol(rot(man, M.axis[k], 5.0 * i), M.frame) for i in range(72))
        if worst > TOL * 0.1:
            print("  free", k, worst)
        ok &= worst <= TOL
    return ok


DIRS = {"+x": (0.3, 0, 0), "-x": (-0.3, 0, 0), "+y": (0, 0.3, 0), "-y": (0, -0.3, 0), "+z": (0, 0, 0.3), "-z": (0, 0, -0.3)}


def held(M):
    ok = True
    for dn, dv in DIRS.items():
        h = {}
        for k, man in M.mob.items():
            v = kernel.ivol(shift(man, dv), M.frame)
            h[k] = v > TOL
            if 0 < v < 0.03:
                print("  held: weak", k, dn, v)
        changed = True
        while changed:
            changed = False
            for k, man in M.mob.items():
                if h[k]:
                    continue
                for k2, man2 in M.mob.items():
                    if k2 != k and h[k2] and math.dist(M.axis[k], M.axis[k2]) <= 0.01:
                        v = kernel.ivol(shift(man, dv), man2)
                        if v > TOL:
                            h[k] = True
                            changed = True
                            print("  held via", k, dn, k2, "%.3f" % v)
        for k in h:
            if not h[k]:
                print("  NOT HELD", k, dn)
                ok = False
    return ok


def seated(M):
    ok = True
    for k, m in M.doc["mobiles"].items():
        ps = m["parts"]
        if len(ps) < 2:
            continue
        for p in ps:
            others = kernel.union([M.part[q] for q in ps if q != p])
            vs = {dn: kernel.ivol(shift(M.part[p], dv), others) for dn, dv in DIRS.items()}
            good = all(vs[d] > TOL for d in ("+x", "-x", "+y", "-y")) and (vs["+z"] > TOL or vs["-z"] > TOL)
            print("  seated", p, {a: round(b, 3) for a, b in vs.items()}, "ok" if good else "FAIL")
            ok &= good
        linked = {ps[0]}
        grow = True
        while grow:
            grow = False
            for a in ps:
                if a not in linked and any(kernel.min_distance(M.part[a], M.part[b], 1.0) <= 0.02 for b in linked):
                    linked.add(a)
                    grow = True
        ok &= len(linked) == len(ps)
    return ok


def crop(man, axis_other, axis_self, reach):
    """Speed-up only for the designer's run: keep the part of man within `reach` of the other axis in plan."""
    return man


def mesh_test(M, e, offset=0.0, verbose=True):
    Dn, Nn, zD, zN = e["driver"], e["driven"], e["driver_teeth"], e["driven_teeth"]
    D, N = M.mob[Dn], M.mob[Nn]
    aD, aN = np.array(M.axis[Dn]), np.array(M.axis[Nn])
    dist = float(np.linalg.norm(aN - aD))
    m = 2 * dist / (zD + zN)
    u = (aN - aD) / dist if dist > 1e-12 else np.array([1.0, 0.0])
    aN2 = aN + offset * u
    N = shift(N, [offset * u[0], offset * u[1], 0])
    # designer's speed-up: only the gears' neighbourhood matters; trim both solids to a slab region near the
    # line of centres would change nothing in the result but is not done, to stay identical to the procedure.
    steps = 8 * max(zD, zN)
    worst_jam, worst_gap, minA, minH = 0.0, 0.0, 1e9, 1e9
    ok = True

    def pose(i):
        a = i * 360.0 / (8 * zD)
        return rot(D, aD, a), rot(N, aN2, -a * zD / zN), a
    for i in range(steps):
        subs = [i] + ([i + 1 / 3, i + 1 / 5] if i % 8 == 0 else [])
        for s in subs:
            Dp, Np, a = pose(s)
            v = kernel.ivol(Dp, Np)
            worst_jam = max(worst_jam, v)
            if s == i and i % 4 == 0 and v == 0.0:
                inter_empty = (Dp ^ Np).is_empty()
                if inter_empty:
                    g = Dp.min_gap(Np, 0.5)
                    worst_gap = max(worst_gap, g)
            if s == i and i % 8 == 0:
                D2 = rot(D, aD, a + 90.0 / zD)
                R = (D2 ^ Np) - Dp
                V = R.volume()
                if R.is_empty() or V <= 0:
                    minA = 0.0
                    continue
                bb = R.bounding_box()
                H = bb[5] - bb[2]
                minA = min(minA, V / H)
                minH = min(minH, H)
                if V < 0.001:
                    ok = False
    ok &= worst_jam <= TOL and worst_gap <= 0.1 and minA > 0.5 * m * m
    if verbose:
        print("  mesh %-7s->%-7s off %+.2f m=%.4f jam %.5f gap %.4f  A/m2 %.3f (need >0.5)  H %.3f  %s"
              % (Dn, Nn, offset, m, worst_jam, worst_gap, minA / (m * m), minH, "ok" if ok else "FAIL"))
    return ok, minH, m


def meshes(M, offsets=(0.0, 0.03, -0.03), only=None):
    ok = True
    M.H = {}
    for idx, e in enumerate(M.doc["meshes"]):
        if only is not None and idx not in only:
            continue
        for off in offsets:
            o, H, m = mesh_test(M, e, off)
            ok &= o
            if off == 0.0:
                M.H[idx] = (H, m)
    return ok


def pairs(M):
    ok = True
    declared = {frozenset((e["driver"], e["driven"])) for e in M.doc["meshes"]}
    names = list(M.mob)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            if frozenset((a, b)) in declared:
                continue
            if not kernel.bbox_overlap(_swept_box(M, a), _swept_box(M, b)):
                continue
            sa, sb = M.speed.get(a, Fraction(0)), M.speed.get(b, Fraction(0))
            worst = 0.0
            fast = max(abs(sa), abs(sb))
            seqs = []
            if fast > 0:
                seqs.append([(float(sa / fast) * 360.0 * k / 144, float(sb / fast) * 360.0 * k / 144) for k in range(144)])
            if sa != sb:
                rel = abs(sa - sb)
                seqs.append([(float(sa / rel) * 360.0 * k / 144, float(sb / rel) * 360.0 * k / 144) for k in range(144)])
            for seq in seqs:
                for ta, tb in seq:           # clockwise positive -> rotate by minus
                    v = kernel.ivol(rot(M.mob[a], M.axis[a], -ta), rot(M.mob[b], M.axis[b], -tb))
                    worst = max(worst, v)
            if worst > 0:
                print("  pair", a, b, worst)
            ok &= worst <= TOL
    return ok


def _swept_box(M, k):
    man = M.mob[k]
    v = kernel.verts(man)
    r = np.hypot(v[:, 0] - M.axis[k][0], v[:, 1] - M.axis[k][1]).max()
    ax = M.axis[k]
    return kernel.box([ax[0] - r, ax[1] - r, v[:, 2].min()], [ax[0] + r, ax[1] + r, v[:, 2].max()])


def hands(M):
    ok = True
    d = M.doc
    want = {"hour": Fraction(1, 12), "minute": Fraction(1), "seconds": Fraction(60), "day": Fraction(1, 24)}
    ftop = max(M.part[n].bounding_box()[5] for n in d["fixed"])
    print("  consistent speeds:", M.consistent, " frame top", ftop)
    ok &= M.consistent
    for h, w in want.items():
        e = d["hands"][h]
        s = M.speed.get(e["mobile"])
        ax = M.axis[e["mobile"]]
        p = M.part[e["part"]]
        v = kernel.verts(p)
        reach = np.hypot(v[:, 0] - ax[0], v[:, 1] - ax[1]).max()
        # centre of volume
        mesh = p.to_mesh()
        vv = np.asarray(mesh.vert_properties, float)[:, :3]
        t = vv[np.asarray(mesh.tri_verts)]
        vol6 = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2]))
        cen = (vol6[:, None] * (t[:, 0] + t[:, 1] + t[:, 2]) / 4).sum(0) / vol6.sum()
        cd = math.hypot(cen[0] - ax[0], cen[1] - ax[1])
        need = 3.0 if h == "day" else 5.0
        good = s == w and reach >= need and v[:, 2].min() >= ftop and cd >= 0.5
        print("  hand %-7s speed %s (want %s cw)  reach %.2f  zmin %.3f  centroid %.2f  %s"
              % (h, s, w, reach, v[:, 2].min(), cd, "ok" if good else "FAIL"))
        ok &= good
    dh = math.dist(M.axis[d["hands"]["hour"]["mobile"]], M.axis[d["hands"]["minute"]["mobile"]])
    dd = math.dist(M.axis[d["hands"]["hour"]["mobile"]], M.axis[d["hands"]["day"]["mobile"]])
    print("  hour-minute axes %.4f ; day-hour axes %.3f" % (dh, dd))
    ok &= dh <= 0.01 and dd >= 6
    ok &= set(M.speed) == set(M.mob)
    return ok


def case(M):
    d = M.doc
    cc = d["case_centre"]
    worst = 0.0
    for n in d["fixed"]:
        v = kernel.verts(M.part[n])
        worst = max(worst, np.hypot(v[:, 0] - cc[0], v[:, 1] - cc[1]).max())
    zs = [M.frame.bounding_box()[2], M.frame.bounding_box()[5]]
    for k, man in M.mob.items():
        v = kernel.verts(man)
        ax = M.axis[k]
        r = np.hypot(v[:, 0] - ax[0], v[:, 1] - ax[1]).max() + math.dist(ax, cc)
        worst = max(worst, r)
        zs += [v[:, 2].min(), v[:, 2].max()]
    print("  largest radius %.4f (limit %.1f); height %.3f (limit %.1f)" % (worst, CASE_R, max(zs) - min(zs), CASE_H))
    return worst <= CASE_R and max(zs) - min(zs) <= CASE_H


def printable(names):
    ok = True
    h = 0.05
    for n in names:
        man = load(n)
        bb = man.bounding_box()
        lo = np.array(bb[:3]) - 4 * h
        org = np.floor((lo - 0.0113) / h) * h + 0.0113 - h / 2      # voxel centres at 0.05 k + 0.0113
        shape = tuple(int(x) for x in np.ceil((np.array(bb[3:]) + 4 * h - org) / h).astype(int) + 1)
        npc, dev = kernel.opening_test_slabs(man, org, shape, h, 1.5, 1.0, 6.0)
        good = npc >= 1 and dev * h <= 0.2 + 1e-9
        print("  print %-14s pieces %d  largest distance %.4f mm  %s" % (n, npc, dev * h, "ok" if good else "FAIL"))
        ok &= good
    return ok


def strength(M):
    """Needs meshes() run first (face widths)."""
    Y = lewis_table()
    d = M.doc
    sec = d["hands"]["seconds"]["mobile"]
    # path barrel -> seconds
    prev = {"barrel": None}
    q = ["barrel"]
    while q:
        a = q.pop(0)
        for idx, e in enumerate(d["meshes"]):
            for x, y in ((e["driver"], e["driven"]), (e["driven"], e["driver"])):
                if x == a and y not in prev:
                    prev[y] = (a, idx)
                    q.append(y)
    ok = True
    k = sec
    while prev[k] is not None:
        a, idx = prev[k]
        e = d["meshes"][idx]
        H, m = M.H[idx]
        Dn, Nn, zD, zN = e["driver"], e["driven"], e["driver_teeth"], e["driven_teeth"]
        TD = T_BARREL * abs(float(M.speed["barrel"] / M.speed[Dn]))
        F = TD / (m * zD / 2)
        for g, z in ((Dn, zD), (Nn, zN)):
            if g == "barrel":
                continue
            sig = F / (H * m * Y[z])
            al = ALLOW[d["mobiles"][g]["material"]]
            print("  strength %-7s z=%-3d F=%.3f N b=%.3f m=%.3f sigma=%.1f MPa allow %.0f %s"
                  % (g, z, F, H, m, sig, al, "ok" if sig <= al else "FAIL"))
            ok &= sig <= al
        k = a
    return ok


def asm(M):
    with open(os.path.join(DELIVERY, "assembly.json")) as f:
        A = json.load(f)
    d = M.doc
    names = list(d["fixed"]) + [p for m in d["mobiles"].values() for p in m["parts"]] + ["barrel"]
    allb = np.array([M.part[n].bounding_box() for n in names])
    lo, hi = allb[:, :3].min(0) - 5, allb[:, 3:].max(0) + 5
    order = []
    for n in A["order"]:
        if n in names and n not in order:
            order.append(n)
    placed = [n for n in names if n not in order]
    if placed:
        print("  not in order:", placed)
    installed = 0
    for n in order:
        P = [np.array(T, float) for T in A["paths"].get(n, [])]
        good = 2 <= len(P) <= 1500
        man = M.part[n]
        v = kernel.verts(man)
        if good:
            for T in P:
                R = T[:3, :3]
                good &= bool(np.isfinite(T).all() and np.allclose(R.T @ R, np.eye(3), atol=1e-6)
                             and abs(np.linalg.det(R) - 1) < 1e-6 and np.allclose(T[3], [0, 0, 0, 1], atol=1e-6))
            good &= bool(np.allclose(P[-1], np.eye(4), atol=1e-6))
            v0 = v @ P[0][:3, :3].T + P[0][:3, 3]
            b0, b1 = v0.min(0), v0.max(0)
            outside = bool(((b1 < lo) | (b0 > hi)).any())
            good &= outside
            prevv = None
            maxstep = 0.0
            for T in P:
                vv = v @ T[:3, :3].T + T[:3, 3]
                if prevv is not None:
                    maxstep = max(maxstep, np.linalg.norm(vv - prevv, axis=1).max())
                prevv = vv
            good &= maxstep <= 0.2
            worst = 0.0
            if placed:
                for T in P:
                    mm = kernel.apply(man, T)
                    for q in placed:
                        if kernel.bbox_overlap(mm, M.part[q]):
                            worst = max(worst, kernel.ivol(mm, M.part[q]))
            good &= worst <= TOL
            print("  asm %-14s poses %d outside %s maxstep %.3f worst %.5f %s"
                  % (n, len(P), outside, maxstep, worst, "ok" if good else "FAIL"))
        else:
            print("  asm", n, "bad path")
        installed += bool(good)
        placed.append(n)
    print("  installed %d of %d" % (installed, len(names)))
    return installed == len(names)


def main():
    fn = sys.argv[1]
    which = sys.argv[2:] or ["c2", "free", "held", "seated", "mesh", "pairs", "hands", "case", "strength", "print", "asm"]
    M = Movement(fn, 8 if fn == "movement.json" else 6)
    res = {}
    for w in which:
        print("==", w)
        if w == "c2":
            res[w] = c2(M)
        elif w == "free":
            res[w] = free(M)
        elif w == "held":
            res[w] = held(M)
        elif w == "seated":
            res[w] = seated(M)
        elif w == "mesh":
            res[w] = meshes(M)
        elif w == "mesh0":
            res[w] = meshes(M, offsets=(0.0,))
        elif w == "pairs":
            res[w] = pairs(M)
        elif w == "hands":
            res[w] = hands(M)
        elif w == "case":
            res[w] = case(M)
        elif w == "strength":
            if not hasattr(M, "H"):
                meshes(M, offsets=(0.0,))
            res[w] = strength(M)
        elif w == "print":
            d = M.doc
            res[w] = printable(list(d["fixed"]) + [p for m in d["mobiles"].values() for p in m["parts"]])
        elif w == "asm":
            res[w] = asm(M)
        print("==", w, "PASS" if res[w] else "FAIL", flush=True)
    print(fn, res)


if __name__ == "__main__":
    main()
