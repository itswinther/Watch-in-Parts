"""Builds every part of the calibre (STEP), movement.json, variant_6h.json and assembly.json.

    python3 build.py            (run from anywhere; writes into the delivery folder above this one)

Layout (world frame of the supplied barrel: barrel axis at x = 0, y = 0, dial side +z):
  going train, between main plate and train bridge:
      barrel 96 -> i1 pinion 24 (m 0.2) ; i1 wheel 30 -> centre pinion 15 (m 0.4)   [8 h: 4 x 2 = 8]
                                          i1 wheel 27 -> centre pinion 18 (m 0.4)   [6 h: 4 x 1.5 = 6]
      centre wheel 80 -> third pinion 10 (m 0.2) ; third wheel 75 -> fourth pinion 10 (m 0.2)   [x 60]
  motion work, between train bridge and dial plate:
      cannon pinion 12 -> minute wheel 36 (m 0.25) ; minute pinion 12 -> hour wheel 48 (m 0.2)  [1/12]
      hour wheel 48 -> idler wheel 24 ; idler pinion 12 -> day wheel 48 (m 0.2)                 [1/2]
"""
import json
import math
import os
import sys

import numpy as np
import cadquery as cq

HERE = os.path.dirname(os.path.abspath(__file__))
DELIVERY = os.path.dirname(HERE)
APP = os.path.dirname(DELIVERY)
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel  # noqa: E402

PARTS = os.path.join(DELIVERY, "parts")
ALPHA = math.radians(25.0)
THIN = 0.020            # each gear's tooth is thinned by this arc length on the pitch circle (backlash)


# ---------------------------------------------------------------- gears
def inv(a):
    return math.tan(a) - a


def gear_outline(z, m, x=0.0, phase=0.0, thin=THIN, nfl=12, add=1.0, ded=1.25):
    """Involute spur gear outline, counter-clockwise, one tooth centred on the angle `phase` (radians).
    x is the profile shift coefficient; tip radius r + (add + x) m, root radius r - (ded - x) m."""
    r = m * z / 2.0
    rb = r * math.cos(ALPHA)
    ra = r + (add + x) * m
    rf = r - (ded - x) * m
    s = m * (math.pi / 2 + 2 * x * math.tan(ALPHA)) - thin      # arc tooth thickness on the pitch circle

    def half(rr):                                               # half tooth angle at radius rr >= rb
        return s / (2 * r) + inv(ALPHA) - inv(math.acos(min(1.0, rb / rr)))
    r0 = max(rb, rf)
    assert half(ra) > 0.04 * m / ra, "pointed tooth z=%d" % z
    # radii along the flank, denser near the base circle where the curvature is high
    us = np.linspace(0.0, 1.0, nfl)
    rs = r0 + (ra - r0) * us ** 1.5
    right = [(rr, -half(rr)) for rr in rs]                      # flank at negative angles, root to tip
    tooth = []
    if rf < r0 - 1e-9:
        tooth.append((rf, -half(r0)))                           # radial flank below the base circle
    tooth += right
    tooth.append((ra, 0.0))                                     # middle of the tip land
    tooth += [(rr, -a) for rr, a in reversed(right)]
    if rf < r0 - 1e-9:
        tooth.append((rf, half(r0)))
    pitch = 2 * math.pi / z
    gap = pitch - 2 * half(r0)
    assert gap > 0
    pts = []
    for k in range(z):
        c = phase + k * pitch
        for rr, a in tooth:
            pts.append((rr * math.cos(c + a), rr * math.sin(c + a)))
        for f in (0.25, 0.5, 0.75):                             # root arc towards the next tooth
            a = c + half(r0) + gap * f
            pts.append((rf * math.cos(a), rf * math.sin(a)))
    return pts, dict(r=r, ra=ra, rf=rf, rb=rb)


def prism(pts, cx, cy, z0, z1, hole=None):
    w = cq.Workplane("XY").workplane(offset=z0).polyline([(cx + px, cy + py) for px, py in pts]).close()
    if hole:
        w = w.moveTo(cx, cy).circle(hole)
    return w.extrude(z1 - z0)


def turned(cx, cy, steps, bore=0.0):
    """Body of revolution about the vertical through (cx, cy). steps: [(z0, z1, radius), ...] bottom to top."""
    prof = [(bore, steps[0][0])]
    for z0, z1, rr in steps:
        prof += [(rr, z0), (rr, z1)]
    prof.append((bore, steps[-1][1]))
    clean = [prof[0]]
    for p in prof[1:]:
        if abs(p[0] - clean[-1][0]) > 1e-9 or abs(p[1] - clean[-1][1]) > 1e-9:
            clean.append(p)
    w = cq.Workplane("XZ").polyline(clean).close().revolve(360, (0, 0, 0), (0, 1, 0))
    return w.translate((cx, cy, 0))


def hand(cx, cy, z0, z1, bore, hub, length, w0, w1, angle):
    a0 = math.asin(w0 / hub)
    pts = [(hub * math.cos(a), hub * math.sin(a)) for a in np.linspace(a0, 2 * math.pi - a0, 40)]
    pts += [(length, -w1), (length, w1)]
    ca, sa = math.cos(angle), math.sin(angle)
    pts = [(px * ca - py * sa, px * sa + py * ca) for px, py in pts]
    return prism(pts, cx, cy, z0, z1, hole=bore)


# ---------------------------------------------------------------- layout
C = np.array([0.0, -10.75])                  # centre arbor = case centre
BAR = np.array([0.0, 0.0])


def from_c(x, y):
    return C + np.array([x, y])


def two_circles(p0, r0, p1, r1, side):
    d = np.linalg.norm(p1 - p0)
    a = (r0 * r0 - r1 * r1 + d * d) / (2 * d)
    h = math.sqrt(r0 * r0 - a * a)
    e = (p1 - p0) / d
    n = np.array([-e[1], e[0]])
    return p0 + a * e + side * h * n


AX = {"barrel": BAR, "centre": C}
AX["i1"] = two_circles(BAR, 12.0, C, 9.0, +1)            # east of the centre
if AX["i1"][0] < 0:
    AX["i1"] = two_circles(BAR, 12.0, C, 9.0, -1)
AX["fourth"] = from_c(0.0, -11.0)                         # small seconds at 6 o'clock
AX["third"] = two_circles(C, 9.0, AX["fourth"], 8.5, +1)
if AX["third"][0] > 0:
    AX["third"] = two_circles(C, 9.0, AX["fourth"], 8.5, -1)
AX["mw"] = from_c(6.0 * math.cos(math.radians(-30)), 6.0 * math.sin(math.radians(-30)))
AX["day"] = from_c(0.0, 8.0)                              # 24-hour dial at 12 o'clock
AX["idler"] = two_circles(C, 7.2, AX["day"], 6.0, +1)
if AX["idler"][0] > 0:
    AX["idler"] = two_circles(C, 7.2, AX["day"], 6.0, -1)
AX["hour"] = C

# z levels
PL0 = (-1.10, -0.15)          # main plate
PL1 = (5.004, 5.70)           # train bridge
PL2 = (7.504, 8.10)           # dial plate
SH0 = -0.06                   # lower shoulders
PLATE_R = 20.5
PILLARS = [from_c(19.3 * math.cos(math.radians(a)), 19.3 * math.sin(math.radians(a))) for a in (30, 150, 225, 315)]
PILLAR_R = 1.1

# gears: name -> (mobile, teeth, module, shift, z0, z1)
GEARS = {
    "i1_p":     ("i1", 24, 0.2, 0.0, -0.05, 1.05),
    "i1_w":     ("i1", 30, 0.4, 0.0, 1.35, 2.15),
    "c_p":      ("centre", 15, 0.4, 0.0, 1.30, 2.20),
    "c_w":      ("centre", 80, 0.2, -0.2, 2.55, 3.25),
    "t_p":      ("third", 10, 0.2, 0.2, 2.50, 3.30),
    "t_w":      ("third", 75, 0.2, -0.2, 3.65, 4.35),
    "f_p":      ("fourth", 10, 0.2, 0.2, 3.60, 4.40),
    "cannon":   ("centre", 12, 0.25, 0.0, 5.854, 6.50),
    "mw_w":     ("mw", 36, 0.25, 0.0, 5.95, 6.45),
    "mw_p":     ("mw", 12, 0.2, 0.0, 6.65, 7.35),
    "h_w":      ("hour", 48, 0.2, 0.0, 6.70, 7.30),
    "id_w":     ("idler", 24, 0.2, 0.0, 6.65, 7.35),
    "id_p":     ("idler", 12, 0.2, 0.0, 5.90, 6.50),
    "d_w":      ("day", 48, 0.2, 0.0, 5.95, 6.45),
    # 6-hour variant
    "i1_w6":    ("i1", 27, 0.4, 0.0, 1.35, 2.15),
    "c_p6":     ("centre", 18, 0.4, 0.0, 1.30, 2.20),
}
# meshes in power-flow order: (driver gear, driven gear)
MESHES_COMMON_TAIL = [("c_w", "t_p"), ("t_w", "f_p"), ("cannon", "mw_w"), ("mw_p", "h_w"), ("h_w", "id_w"),
                      ("id_p", "d_w")]
MESHES_8 = [("barrel", "i1_p"), ("i1_w", "c_p")] + MESHES_COMMON_TAIL
MESHES_6 = [("barrel", "i1_p"), ("i1_w6", "c_p6")] + MESHES_COMMON_TAIL

PHASE = {"barrel": 0.0}       # supplied barrel: a tooth centred on +x
TEETH = {"barrel": 96}
MOB = {"barrel": "barrel"}
for g, v in GEARS.items():
    TEETH[g] = v[1]
    MOB[g] = v[0]


def solve_phases(meshes):
    for a, b in meshes:
        if b in PHASE:
            continue
        PHASE.setdefault(a, 0.0)          # a wheel that nothing drives directly: free phase
        pa, pb = AX[MOB[a]], AX[MOB[b]]
        th = math.atan2(pb[1] - pa[1], pb[0] - pa[0])
        pitch_a = 2 * math.pi / TEETH[a]
        d = (th - PHASE[a]) % pitch_a
        if d > pitch_a / 2:
            d -= pitch_a
        # a's nearest tooth is at th - d: b turns the other way by d * za / zb
        PHASE[b] = th + math.pi + d * TEETH[a] / TEETH[b] + math.pi / TEETH[b]


solve_phases(MESHES_8)
solve_phases(MESHES_6)


def gear(g, hole=None):
    mob, z, m, x, z0, z1 = GEARS[g]
    pts, _ = gear_outline(z, m, x, PHASE[g], nfl=12 if z <= 30 else 8)
    cx, cy = AX[mob]
    return prism(pts, cx, cy, z0, z1, hole)


def fuse(*ws):
    out = ws[0]
    for w in ws[1:]:
        out = out.union(w)
    return out


# ---------------------------------------------------------------- parts
def build_parts():
    P = {}
    # --- going train
    a = AX["i1"]
    i1_arbor = [(-1.0, SH0, 0.4), (SH0, 2.3, 1.0), (2.3, 4.5, 0.5), (4.5, 4.9, 0.7), (4.9, 5.5, 0.4)]
    P["i1"] = fuse(turned(a[0], a[1], i1_arbor), gear("i1_p"), gear("i1_w"))
    P["i1_6h"] = fuse(turned(a[0], a[1], i1_arbor), gear("i1_p"), gear("i1_w6"))
    a = AX["centre"]
    c_arbor = [(-1.0, SH0, 0.4), (SH0, 1.2, 0.65), (1.2, 4.9, 1.0), (4.9, 5.85, 0.6), (5.85, 9.496, 0.45),
               (9.496, 10.0, 0.3)]
    P["centre"] = fuse(turned(a[0], a[1], c_arbor), gear("c_p"), gear("c_w"))
    P["centre_6h"] = fuse(turned(a[0], a[1], c_arbor), gear("c_p6"), gear("c_w"))
    P["cannon"] = gear("cannon", hole=0.455)
    P["minute_hand"] = hand(a[0], a[1], 9.50, 9.90, 0.305, 0.8, 10.0, 0.45, 0.2, math.radians(60))
    a = AX["third"]
    P["third"] = fuse(turned(a[0], a[1], [(-1.0, SH0, 0.4), (SH0, 4.9, 0.7), (4.9, 5.5, 0.4)]),
                      gear("t_p"), gear("t_w"))
    a = AX["fourth"]
    P["fourth"] = fuse(turned(a[0], a[1], [(-1.0, SH0, 0.4), (SH0, 4.9, 0.7), (4.9, 8.30, 0.45),
                                           (8.30, 8.75, 0.3)]), gear("f_p"))
    P["seconds_hand"] = hand(a[0], a[1], 8.304, 8.70, 0.305, 0.8, 5.6, 0.4, 0.2, math.radians(200))
    # --- motion work
    a = AX["mw"]
    P["mw"] = fuse(turned(a[0], a[1], [(5.15, 5.8, 0.4), (5.8, 7.4, 0.8), (7.4, 7.9, 0.4)]),
                   gear("mw_w"), gear("mw_p"))
    a = AX["idler"]
    P["idler"] = fuse(turned(a[0], a[1], [(5.15, 5.8, 0.4), (5.8, 7.4, 0.8), (7.4, 7.9, 0.4)]),
                      gear("id_p"), gear("id_w"))
    a = AX["day"]
    P["day"] = fuse(turned(a[0], a[1], [(5.15, 5.8, 0.4), (5.8, 7.4, 0.8), (7.4, 8.30, 0.45), (8.30, 8.75, 0.3)]),
                    gear("d_w"))
    P["day_hand"] = hand(a[0], a[1], 8.304, 8.70, 0.305, 0.8, 3.6, 0.5, 0.25, math.radians(90))
    a = AX["hour"]
    P["hour"] = fuse(turned(a[0], a[1], [(6.62, 8.90, 1.1), (8.90, 9.40, 0.85)], bore=0.53),
                     gear("h_w", hole=0.8))
    P["hour_hand"] = hand(a[0], a[1], 8.904, 9.30, 0.855, 1.35, 7.0, 0.55, 0.25, math.radians(150))

    # --- frame
    def plate(zr, holes, pillars_to=None):
        w = cq.Workplane("XY").workplane(offset=zr[0]).moveTo(C[0], C[1]).circle(PLATE_R).extrude(zr[1] - zr[0])
        if pillars_to is not None:
            zm = 0.5 * (zr[0] + zr[1])
            for p in PILLARS:
                w = w.union(cq.Workplane("XY").workplane(offset=zm).moveTo(p[0], p[1]).circle(PILLAR_R)
                            .extrude(pillars_to - zm))
        for name, rr in holes:
            p = AX[name]
            w = w.cut(cq.Workplane("XY").workplane(offset=zr[0] - 1).moveTo(p[0], p[1]).circle(rr)
                      .extrude(zr[1] - zr[0] + 2))
        return w
    P["main_plate"] = plate(PL0, [("barrel", 0.58), ("i1", 0.48), ("centre", 0.48), ("third", 0.48),
                                  ("fourth", 0.48)], pillars_to=5.0)
    P["train_bridge"] = plate(PL1, [("barrel", 0.58), ("i1", 0.48), ("centre", 0.68), ("third", 0.48),
                                    ("fourth", 0.53), ("mw", 0.48), ("idler", 0.48), ("day", 0.48)],
                              pillars_to=7.5)
    P["dial_plate"] = plate(PL2, [("centre", 1.18), ("fourth", 0.53), ("mw", 0.48), ("idler", 0.48),
                                  ("day", 0.53)])
    return P


FIXED = ["main_plate", "train_bridge", "dial_plate"]
STEEL, BRASS = "AD-C100-HT", "AD-CW614N"


def movement(six):
    s = "_6h" if six else ""
    mob = {
        "i1": {"parts": ["i1" + s], "material": STEEL},
        "centre": {"parts": ["centre" + s, "cannon", "minute_hand"], "material": STEEL},
        "third": {"parts": ["third"], "material": STEEL},
        "fourth": {"parts": ["fourth", "seconds_hand"], "material": STEEL},
        "mw": {"parts": ["mw"], "material": BRASS},
        "hour": {"parts": ["hour", "hour_hand"], "material": BRASS},
        "idler": {"parts": ["idler"], "material": BRASS},
        "day": {"parts": ["day", "day_hand"], "material": BRASS},
    }
    out = {"case_centre": [float(C[0]), float(C[1])], "fixed": list(FIXED), "mobiles": {}}
    for k, v in mob.items():
        out["mobiles"][k] = {"axis": [float(AX[k][0]), float(AX[k][1])], "parts": v["parts"],
                             "material": v["material"]}
    out["meshes"] = [{"driver": MOB[a], "driver_teeth": TEETH[a], "driven": MOB[b], "driven_teeth": TEETH[b]}
                     for a, b in (MESHES_6 if six else MESHES_8)]
    out["hands"] = {"hour": {"mobile": "hour", "part": "hour_hand"},
                    "minute": {"mobile": "centre", "part": "minute_hand"},
                    "seconds": {"mobile": "fourth", "part": "seconds_hand"},
                    "day": {"mobile": "day", "part": "day_hand"}}
    return out


ORDER = ["main_plate", "barrel", "i1", "centre", "third", "fourth", "train_bridge", "cannon", "mw", "day",
         "idler", "hour", "dial_plate", "seconds_hand", "day_hand", "hour_hand", "minute_hand"]


def assembly():
    """Every part is lowered straight down along -z into its place, in 0.19 mm steps."""
    paths = {}
    lift, step = 19.0, 0.19        # movement spans z -1.1 .. 10; the grown box ends at z 15
    n = int(round(lift / step))
    for name in ORDER:
        poses = []
        for i in range(n, -1, -1):
            T = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, round(i * step, 6)],
                 [0.0, 0.0, 0.0, 1.0]]
            poses.append(T)
        paths[name] = poses
    return {"order": ORDER, "paths": paths}


def main():
    os.makedirs(PARTS, exist_ok=True)
    only = set(sys.argv[1:])
    if "json" not in only:
        P = build_parts()
        for name, w in P.items():
            if only and name not in only:
                continue
            kernel.write_step(os.path.join(PARTS, name + ".step"), w)
            print("wrote", name, os.path.getsize(os.path.join(PARTS, name + ".step")))
    for fn, doc in (("movement.json", movement(False)), ("variant_6h.json", movement(True)),
                    ("assembly.json", assembly())):
        with open(os.path.join(DELIVERY, fn), "w") as f:
            json.dump(doc, f, indent=None if fn == "assembly.json" else 1)
    for k, v in AX.items():
        print("%-8s %9.4f %9.4f   from centre %7.3f" % (k, v[0], v[1], np.linalg.norm(v - C)))


if __name__ == "__main__":
    main()
