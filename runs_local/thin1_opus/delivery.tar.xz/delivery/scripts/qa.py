"""Own approximations of the QA-W100 tests, on manifold3d solids."""
import math
import sys
import os
import numpy as np
import manifold3d as m3

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
import kernel  # noqa: E402
import gearlib  # noqa: E402


def prism(poly, z0, z1):
    cs = m3.CrossSection([np.asarray(poly, float).tolist()], m3.FillRule.Positive)
    return m3.Manifold.extrude(cs, z1 - z0).translate([0, 0, z0])


def gear_solid(m, z, thin, phase, z0, z1, cx=0.0, cy=0.0, **kw):
    poly = gearlib.gear_polygon(m, z, thin=thin, phase=phase, **kw)
    return prism(poly, z0, z1).translate([cx, cy, 0])


def rot_about(man, axis, ang):
    """Rotate a manifold about the vertical line through axis by ang radians (CCW seen from +z)."""
    c, s = math.cos(ang), math.sin(ang)
    x, y = axis
    T = [[c, -s, 0, x - c * x + s * y], [s, c, 0, y - s * x - c * y], [0, 0, 1, 0]]
    return man.transform(T)


def zext(man):
    b = man.bounding_box()
    return b[5] - b[2]


def mesh_test(D, aD, N, aN, zD, zN, senseD, nsteps=24, span_pitches=1.0, verbose=False):
    """senseD: +1 CCW, -1 CW (running sense of D). Returns dict of worst values."""
    dist = math.hypot(aN[0] - aD[0], aN[1] - aD[1])
    mod = 2 * dist / (zD + zN)
    pitchD = 2 * math.pi / zD
    worst_col, worst_gap, worst_ratio, worst_vol, minH = 0.0, 0.0, 1e9, 1e9, 1e9
    for i in range(nsteps):
        th = senseD * pitchD * span_pitches * i / nsteps
        Dp = rot_about(D, aD, th)
        Np = rot_about(N, aN, -th * zD / zN)
        col = kernel.ivol(Dp, Np)
        worst_col = max(worst_col, col)
        if col <= 1e-9:
            gap = Dp.min_gap(Np, 1.0)
            worst_gap = max(worst_gap, gap)
        # drive step
        Dq = rot_about(D, aD, th + senseD * pitchD / 4)
        reg = (Dq ^ Np) - Dp
        v = reg.volume()
        H = zext(reg) if v > 0 else 0.0
        ratio = (v / H) / (0.5 * mod * mod) if H > 0 else 0.0
        worst_ratio = min(worst_ratio, ratio)
        worst_vol = min(worst_vol, v)
        minH = min(minH, H)
        if verbose:
            print("  step %2d col %.5f gap %.4f cutvol %.5f H %.3f ratio %.2f" % (i, col, gap if col <= 1e-9 else -1, v, H, ratio))
    return dict(col=worst_col, gap=worst_gap, ratio=worst_ratio, vol=worst_vol, H=minH, m=mod)


def shift_toward(aN, aD, d):
    dx, dy = aD[0] - aN[0], aD[1] - aN[1]
    L = math.hypot(dx, dy)
    return (aN[0] + dx / L * d, aN[1] + dy / L * d)


def full_mesh_test(D, aD, N, aN, zD, zN, senseD, nsteps=24):
    out = {}
    for name, d in (("nom", 0.0), ("in", 0.03), ("out", -0.03)):
        a2 = shift_toward(aN, aD, d)
        N2 = N.translate([a2[0] - aN[0], a2[1] - aN[1], 0])
        out[name] = mesh_test(D, aD, N2, a2, zD, zN, senseD, nsteps)
    return out


def ok(res):
    good = True
    for k, r in res.items():
        if r["col"] > 0.01 or r["gap"] > 0.1 or r["ratio"] <= 1.0 or r["vol"] < 0.001:
            good = False
    return good


def phase_pair(beta, zD, zN, phaseD=None):
    """Phases for a pair: D tooth on the line of centres (angle beta from D to N), N gap there."""
    if phaseD is None:
        phaseD = beta
    # D tooth at angle phaseD + k*pitchD; to centre D's tooth on beta, D must be rotated; we instead return
    # N's phase given D's phase: N gap centred at beta + pi when D's tooth is centred at beta.
    offD = (beta - phaseD) / (2 * math.pi / zD)
    # fractional offset of D tooth from the line of centres, in pitches
    frac = offD - round(offD)
    # D's tooth is frac pitches (of D) away from beta, ahead in CCW. Rotating D by -frac*pitchD aligns it;
    # the conjugate N rotation is +frac*pitchD*zD/zN = frac*pitchN... so N's gap sits at beta+pi + frac*pitchN*(-1)
    pitchN = 2 * math.pi / zN
    return beta + math.pi + pitchN / 2 + frac * pitchN


def printable(man, h=0.05, off=0.0113):
    """DS-W03 section 3. Returns (ok, deviation_mm, pieces)."""
    b = man.bounding_box()
    k0 = [math.floor((b[i] - off) / h) - 3 for i in range(3)]
    k1 = [math.ceil((b[i + 3] - off) / h) + 3 for i in range(3)]
    origin = [k0[i] * h + off - h / 2 for i in range(3)]
    shape = tuple(k1[i] - k0[i] + 1 for i in range(3))
    n, dev = kernel.opening_test_slabs(man, origin, shape, h, 1.5, 1.0, 6.0)
    return (n > 0 and dev * h <= 0.2 + 1e-9), dev * h, n
