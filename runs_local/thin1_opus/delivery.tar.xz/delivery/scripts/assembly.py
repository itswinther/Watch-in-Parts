"""Assembly plan of movement.json: every part comes straight down along -z from above the movement.
Writes assembly.json and checks the rules of QA-W100 Part 4 on its own solids."""
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import check  # noqa: E402
import kernel  # noqa: E402

DEL = check.DEL
ORDER = ["plate_bottom", "barrel", "second_8h", "centre_8h", "motion_wheel", "third", "seconds_arbor",
         "hour_wheel", "day_wheel", "plate_top", "hand_seconds", "hand_day", "hand_hour", "hand_minute"]
STEP = 0.19


def main(verify=True):
    doc = json.load(open(os.path.join(DEL, "movement.json")))
    names = list(doc["fixed"]) + [p for m in doc["mobiles"].values() for p in m["parts"]]
    assert sorted(names + ["barrel"]) == sorted(ORDER), (sorted(names), sorted(ORDER))
    solids = {n: check.load(n) for n in names}
    solids["barrel"] = check.barrel()
    bbs = np.array([s.bounding_box() for s in solids.values()])
    top = bbs[:, 5].max()
    paths = {}
    for n in ORDER:
        b = solids[n].bounding_box()
        lift = (top + 5.0 + 0.5) - b[2]          # first pose: wholly above the grown box
        k = int(math.ceil(lift / STEP))
        poses = []
        for i in range(k, -1, -1):
            T = np.eye(4)
            T[2, 3] = lift * i / k
            poses.append(T.round(9).tolist())
        paths[n] = poses
    with open(os.path.join(DEL, "assembly.json"), "w") as f:
        json.dump({"order": ORDER, "paths": paths}, f)
    if not verify:
        return
    placed = []
    allok = True
    for n in ORDER:
        s = solids[n]
        worst = (0.0, None, None)
        for T in paths[n]:
            dz = T[2][3]
            q = s.translate([0, 0, dz])
            for pn in placed:
                v = kernel.ivol(q, solids[pn])
                if v > worst[0]:
                    worst = (v, pn, dz)
        ok = worst[0] <= 0.01
        allok &= ok
        print("%-14s %s worst %.5f with %s at dz %s, %d poses" % (n, "ok" if ok else "FAIL", worst[0], worst[1], worst[2], len(paths[n])))
        placed.append(n)
    print("assembly", "ok" if allok else "FAIL")


if __name__ == "__main__":
    main(verify="--no-verify" not in sys.argv)
