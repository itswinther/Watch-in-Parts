"""Builds every part (STEP) and the two movement files. Run: python3 build.py"""
import json
import math
import os
import sys

import cadquery as cq
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "..", "tools"))
import kernel  # noqa: E402
import gearlib  # noqa: E402
from design import *  # noqa: F401,F403,E402

OUT = os.path.join(HERE, "..")
PARTS = os.path.join(OUT, "parts")
MAT = "AD-C100-HT"


def cyl(c, z, r):
    return cq.Workplane("XY").add(cq.Solid.makeCylinder(r, z[1] - z[0], cq.Vector(c[0], c[1], z[0])))


def tube(c, z, ro, ri):
    return cyl(c, z, ro).cut(cyl(c, (z[0] - 0.1, z[1] + 0.1), ri))


def gear(c, z, nteeth, phase, m=M, thin=THIN):
    pts = gearlib.gear_polygon_rdp(m, nteeth, thin=thin, phase=phase)
    pts = [(float(x + c[0]), float(y + c[1])) for x, y in pts]
    return cq.Workplane("XY").workplane(offset=z[0]).polyline(pts).close().extrude(z[1] - z[0])


def fuse(items):
    s = items[0]
    for it in items[1:]:
        s = s.union(it)
    return s.clean()


def solid_of(wp):
    vals = wp.solids().vals()
    assert len(vals) == 1, "parts must be one solid (%d)" % len(vals)
    return vals[0]


def save(name, wp):
    sol = solid_of(wp)
    assert sol.isValid(), name
    kernel.write_step(os.path.join(PARTS, name + ".step"), sol)
    print("wrote", name, round(sol.Volume(), 3))


def standard_arbor(c, top=PIVOT_HI[1], r_col_lo=R_COL):
    """Lower pivot, lower collar, arbor, upper collar, upper pivot (full height between the plates)."""
    return [cyl(c, PIVOT_LO, R_PIV), cyl(c, COLLAR_LO, r_col_lo), cyl(c, (COLLAR_LO[1] - 0.01, COLLAR_HI[0] + 0.01), R_ARB),
            cyl(c, COLLAR_HI, R_COL), cyl(c, (PIVOT_HI[0], top), R_PIV)]


# ---------------- phases ----------------
def phases(v):
    tr = TRAIN[v]
    ph = {}
    _, ph["M1p"] = pair_phase(B, M1, Z_M1P, phase_drv=0.0, z_drv=96)
    ph["M1w"], ph["Mnp"] = pair_phase(M1, MN, tr["Mnp"])
    ph["Mnw"], ph["Tp"] = pair_phase(MN, T, Z_TP)
    ph["Tw"], ph["Sp"] = pair_phase(T, S, Z_SP)
    ph["Can"], ph["MWw"] = pair_phase(MN, MW, Z_MWW)
    ph["MWpH"], ph["Hw"] = pair_phase(MW, MN, Z_HW)
    ph["MWpD"], ph["Dw"] = pair_phase(MW, D, Z_DW)
    return ph


# ---------------- parts ----------------
def part_second(v):
    ph = phases(v)
    c = M1
    items = [cyl(c, PIVOT_LO, R_PIV), gear(c, L0, Z_M1P, ph["M1p"]), cyl(c, (L0[1] - 0.01, COLLAR_HI[0] + 0.01), R_ARB),
             gear(c, LA, TRAIN[v]["M1w"], ph["M1w"]), cyl(c, COLLAR_HI, R_COL), cyl(c, PIVOT_HI, R_PIV)]
    return fuse(items)


def part_centre(v):
    ph = phases(v)
    c = MN
    items = [cyl(c, PIVOT_LO, R_PIV), cyl(c, COLLAR_LO, R_COL), cyl(c, (COLLAR_LO[1] - 0.01, LC[1]), R_ARB),
             gear(c, LA, TRAIN[v]["Mnp"], ph["Mnp"]), gear(c, LB, Z_MNW, ph["Mnw"]), gear(c, LC, Z_CAN, ph["Can"]),
             cyl(c, (LC[1] - 0.01, H_MIN[0] - 0.01), 0.35), cyl(c, (H_MIN[0] - 0.02, H_MIN[1]), 0.25)]
    return fuse(items)


def part_third():
    ph = phases("8h")
    c = T
    return fuse(standard_arbor(c, r_col_lo=0.55) + [gear(c, LB, Z_TP, ph["Tp"]), gear(c, LDl, Z_TW, ph["Tw"])])


def part_seconds_arbor():
    ph = phases("8h")
    c = S
    items = [cyl(c, PIVOT_LO, R_PIV), cyl(c, COLLAR_LO, 0.55), cyl(c, (COLLAR_LO[1] - 0.01, COLLAR_HI[0] + 0.01), R_ARB),
             gear(c, LDl, Z_SP, ph["Sp"]), cyl(c, COLLAR_HI, R_COL), cyl(c, (COLLAR_HI[1] - 0.01, H_SEC[0] - 0.01), R_PIV),
             cyl(c, (H_SEC[0] - 0.02, H_SEC[1]), 0.25)]
    return fuse(items)


def part_motion_wheel():
    ph = phases("8h")
    c = MW
    return fuse(standard_arbor(c) + [gear(c, LC, Z_MWW, ph["MWw"]), gear(c, LE, Z_MWP_H, ph["MWpH"]),
                                     gear(c, LF, Z_MWP_D, ph["MWpD"])])


def part_hour_wheel():
    ph = phases("8h")
    c = MN
    items = [gear(c, LE, Z_HW, ph["Hw"]), cyl(c, (LC[1] + 0.05, LE[0] + 0.01), 0.75), cyl(c, (LE[1] - 0.01, H_HOUR[0] - 0.01), 0.85), cyl(c, COLLAR_HI, 1.2),
             cyl(c, (H_HOUR[0] - 0.02, H_HOUR[1]), 0.68)]
    body = fuse(items)
    return body.cut(cyl(c, (LC[1], H_HOUR[1] + 0.1), 0.40))


def part_day_wheel():
    ph = phases("8h")
    c = D
    items = [cyl(c, PIVOT_LO, R_PIV), cyl(c, COLLAR_LO, R_COL), cyl(c, (COLLAR_LO[1] - 0.01, COLLAR_HI[0] + 0.01), R_ARB),
             gear(c, LF, Z_DW, ph["Dw"]), cyl(c, COLLAR_HI, R_COL), cyl(c, (COLLAR_HI[1] - 0.01, H_DAY[0] - 0.01), R_PIV),
             cyl(c, (H_DAY[0] - 0.02, H_DAY[1]), 0.25)]
    return fuse(items)


def hand(c, z, hole, hub, length, width, direction, tail=0.0):
    """A hand: hub ring around a hole, and a blade from the hub to `length` along `direction` (radians)."""
    L = length - 0.0
    blade = (cq.Workplane("XY").workplane(offset=z[0]).center(0, 0)
             .rect(L + tail, width, centered=(False, True)).extrude(z[1] - z[0]))
    blade = blade.translate((-tail, 0, 0))
    # round tip: shorten box by width/2 and add a disc at the tip
    hubw = cq.Workplane("XY").workplane(offset=z[0]).circle(hub).extrude(z[1] - z[0])
    body = hubw.union(blade)
    body = body.rotate((0, 0, 0), (0, 0, 1), math.degrees(direction)).translate((c[0], c[1], 0))
    body = body.cut(cyl(c, (z[0] - 0.1, z[1] + 0.1), hole))
    return body.clean()


def part_hand_minute():
    return hand(MN, H_MIN, 0.26, 0.60, 6.5, 0.30, math.radians(60))


def part_hand_hour():
    return hand(MN, H_HOUR, 0.69, 1.00, 5.5, 0.45, math.radians(-50))


def part_hand_seconds():
    return hand(S, H_SEC, 0.26, 0.55, 5.3, 0.30, math.radians(150), tail=1.2)


def part_hand_day():
    return hand(D, H_DAY, 0.26, 0.55, 3.5, 0.30, math.radians(100))


# ---------------- frame ----------------
RP = 19.0
MAXR = {"B": (B, 9.8), "M1": (M1, 5.2), "Mn": (MN, 6.6), "T": (T, 6.2), "S": (S, 1.0), "MW": (MW, 6.6),
        "H": (MN, 6.2), "D": (D, 7.4)}
R_PILLAR = 1.0


def pillar_sites():
    cands = []
    for rr in np.linspace(14.0, RP - 1.6, 12):
        for a in np.linspace(0, 2 * math.pi, 360, endpoint=False):
            p = (CASE_CENTRE[0] + rr * math.cos(a), CASE_CENTRE[1] + rr * math.sin(a))
            cl = min(math.hypot(p[0] - c[0], p[1] - c[1]) - r - R_PILLAR for c, r in MAXR.values())
            if cl > 0.6:
                cands.append((cl, a, p))
    # pick three well spread sites
    best = None
    for i in range(0, len(cands), 7):
        for j in range(i + 1, len(cands), 7):
            for k in range(j + 1, len(cands), 7):
                A = [cands[i][1], cands[j][1], cands[k][1]]
                A.sort()
                gaps = [A[1] - A[0], A[2] - A[1], 2 * math.pi - A[2] + A[0]]
                score = min(gaps)
                if best is None or score > best[0]:
                    best = (score, [cands[i][2], cands[j][2], cands[k][2]])
    return best[1]


def part_plate_bottom():
    pl = cyl(CASE_CENTRE, PLATE_B, RP)
    for c in (M1, MN, T, S, MW, D):
        pl = pl.cut(cyl(c, (PLATE_B[0] - 0.1, PLATE_B[1] + 0.1), R_HOLE))
    pl = pl.cut(cyl(B, (PLATE_B[0] - 0.1, PLATE_B[1] + 0.1), 0.55))
    for p in pillar_sites():
        pl = pl.union(cyl(p, (PLATE_B[1] - 0.01, PLATE_T[0] - 0.005), R_PILLAR))
    return pl.clean()


def part_plate_top():
    pl = cyl(CASE_CENTRE, PLATE_T, RP)
    for c in (M1, T, S, MW, D):
        pl = pl.cut(cyl(c, (PLATE_T[0] - 0.1, PLATE_T[1] + 0.1), R_HOLE))
    pl = pl.cut(cyl(MN, (PLATE_T[0] - 0.1, PLATE_T[1] + 0.1), 0.90))
    pl = pl.cut(cyl(B, (PLATE_T[0] - 0.1, PLATE_T[1] + 0.1), 0.55))
    return pl.clean()


BUILDERS = {
    "plate_bottom": part_plate_bottom,
    "plate_top": part_plate_top,
    "second_8h": lambda: part_second("8h"),
    "second_6h": lambda: part_second("6h"),
    "centre_8h": lambda: part_centre("8h"),
    "centre_6h": lambda: part_centre("6h"),
    "third": part_third,
    "seconds_arbor": part_seconds_arbor,
    "motion_wheel": part_motion_wheel,
    "hour_wheel": part_hour_wheel,
    "day_wheel": part_day_wheel,
    "hand_minute": part_hand_minute,
    "hand_hour": part_hand_hour,
    "hand_seconds": part_hand_seconds,
    "hand_day": part_hand_day,
}


def movement(v):
    tr = TRAIN[v]
    mob = lambda name, parts: {"axis": list(AXR[name]), "parts": parts, "material": MAT}
    doc = {
        "case_centre": list(CASE_CENTRE),
        "fixed": ["plate_bottom", "plate_top"],
        "mobiles": {
            "second": mob("M1", ["second_" + v]),
            "centre": mob("Mn", ["centre_" + v, "hand_minute"]),
            "third": mob("T", ["third"]),
            "fourth": mob("S", ["seconds_arbor", "hand_seconds"]),
            "motion": mob("MW", ["motion_wheel"]),
            "hour": mob("H", ["hour_wheel", "hand_hour"]),
            "day": mob("D", ["day_wheel", "hand_day"]),
        },
        "meshes": [
            {"driver": "barrel", "driver_teeth": 96, "driven": "second", "driven_teeth": Z_M1P},
            {"driver": "second", "driver_teeth": tr["M1w"], "driven": "centre", "driven_teeth": tr["Mnp"]},
            {"driver": "centre", "driver_teeth": Z_MNW, "driven": "third", "driven_teeth": Z_TP},
            {"driver": "third", "driver_teeth": Z_TW, "driven": "fourth", "driven_teeth": Z_SP},
            {"driver": "centre", "driver_teeth": Z_CAN, "driven": "motion", "driven_teeth": Z_MWW},
            {"driver": "motion", "driver_teeth": Z_MWP_H, "driven": "hour", "driven_teeth": Z_HW},
            {"driver": "motion", "driver_teeth": Z_MWP_D, "driven": "day", "driven_teeth": Z_DW},
        ],
        "hands": {
            "hour": {"mobile": "hour", "part": "hand_hour"},
            "minute": {"mobile": "centre", "part": "hand_minute"},
            "seconds": {"mobile": "fourth", "part": "seconds_arbor" if False else "hand_seconds"},
            "day": {"mobile": "day", "part": "hand_day"},
        },
    }
    return doc


if __name__ == "__main__":
    os.makedirs(PARTS, exist_ok=True)
    names = sys.argv[1:] or list(BUILDERS)
    for n in names:
        save(n, BUILDERS[n]())
    with open(os.path.join(OUT, "movement.json"), "w") as f:
        json.dump(movement("8h"), f, indent=1)
    with open(os.path.join(OUT, "variant_6h.json"), "w") as f:
        json.dump(movement("6h"), f, indent=1)
