exec(open('layout.py').read().split('random.seed(1)')[0])
from scipy.optimize import minimize
def slack(P):
    s=[]
    for g8 in (True,False):
        G=gears(g8)
        for i,gl in G.items():
            for (lay,R,partner) in gl:
                for j in P:
                    if j==i or j==partner or {i,j}=={'Mn','H'}: continue
                    if i=='B': rj=0.75
                    elif j=='B': rj=1.0 if lay in ('C','E','F') else 0.5
                    else: rj=0.5
                    d=np.linalg.norm(P[i]-P[j]); need=R+rj
                    if lay=='L0' and j!='B': need=R+0.75
                    s.append(d-need)
    s.append(np.linalg.norm(P['S']-P['Mn'])-(LS+1.2))
    s.append(np.linalg.norm(P['S']-P['D'])-(LS+0.8))
    s.append(np.linalg.norm(P['D']-P['Mn'])-8.1)
    return min(s)
def obj(p):
    P=place(p); R,_=caseR(P)
    return -min(slack(P),0.9) + 2*max(0,R-19.0)
best=None
random.seed(3)
starts=[[0.0, -2.007, -0.136, -1.978, -2.07, 2.809],[0.0, 1.87, 0.49, -0.931, 1.603, -2.61],[0.0, 1.982, 0.131, 1.75, 2.469, -3.039]]
for k in range(60):
    p0 = starts[k] if k<len(starts) else [0]+[random.uniform(-math.pi,math.pi) for _ in range(5)]
    r=minimize(lambda q: obj([0.0]+list(q)), p0[1:], method='Nelder-Mead',options={'maxiter':3000,'xatol':1e-4,'fatol':1e-6})
    p=[0.0]+list(r.x); P=place(p)
    sl=slack(P); R,c=caseR(P)
    if best is None or r.fun<best[0]:
        best=(r.fun,p,sl,R,c); print(k, round(sl,3), round(R,3), [round(x,4) for x in p], c)
