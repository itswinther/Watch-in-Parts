"""Design data of the calibre: axes, layers, gears, hands. Shared by build.py and check.py."""
import math

M = 0.2            # module of every gear of the train (the barrel's module)
THIN = 0.03        # tangential tooth thinning (backlash) of every delivered gear, on the pitch circle


def polar(r, a):
    return (r * math.cos(a), r * math.sin(a))


# ---- axes (layout solved in scratch, see report) ----
_p = [0.0, -2.0133, -0.1366, -1.9867, -2.0791, 2.8213]
B = (0.0, 0.0)
M1 = polar(12.0, _p[0])
MN = (M1[0] + 7.5 * math.cos(_p[1]), M1[1] + 7.5 * math.sin(_p[1]))
T = (MN[0] + 7.2 * math.cos(_p[2]), MN[1] + 7.2 * math.sin(_p[2]))
S = (T[0] + 6.8 * math.cos(_p[3]), T[1] + 6.8 * math.sin(_p[3]))
MW = (MN[0] + 8.0 * math.cos(_p[4]), MN[1] + 8.0 * math.sin(_p[4]))
D = (MW[0] + 8.4 * math.cos(_p[5]), MW[1] + 8.4 * math.sin(_p[5]))
AX = {"M1": M1, "Mn": MN, "T": T, "S": S, "MW": MW, "H": MN, "D": D}
AXR = {k: (round(v[0], 6), round(v[1], 6)) for k, v in AX.items()}
CASE_CENTRE = (5.0644, -5.5137)

# ---- z layers ----
PLATE_B = (-1.0, -0.05)       # bottom plate
PLATE_T = (4.95, 5.45)        # top plate
L0 = (0.0, 1.0)               # barrel teeth, M1 pinion
LA = (1.10, 1.55)             # M1 wheel - minute pinion
LB = (1.65, 2.10)             # minute wheel - third pinion
LDl = (2.75, 3.20)            # third wheel - seconds pinion
LC = (2.20, 2.65)             # cannon pinion - motion wheel
LE = (3.30, 3.75)             # motion pinion - hour wheel
LF = (3.85, 4.30)             # motion pinion - 24-hour wheel
COLLAR_LO = (0.0, 0.40)       # collar just above the bottom plate (stops -z)
COLLAR_HI = (4.50, 4.90)      # collar just under the top plate (stops +z)
PIVOT_LO = (-0.95, 0.0)
PIVOT_HI = (4.90, 5.40)
R_PIV = 0.40
R_HOLE = 0.45
R_ARB = 0.50
R_COL = 0.75
# hands
H_SEC = (5.65, 6.00)
H_DAY = (6.10, 6.45)
H_HOUR = (6.55, 6.90)
H_MIN = (7.00, 7.35)

# ---- train (tooth counts) ----
TRAIN = {
    "8h": {"M1w": 50, "Mnp": 25},
    "6h": {"M1w": 45, "Mnp": 30},
}
Z_M1P = 24
Z_MNW, Z_TP = 64, 8
Z_TW, Z_SP = 60, 8
Z_CAN, Z_MWW = 16, 64
Z_MWP_H, Z_HW = 20, 60
Z_MWP_D, Z_DW = 12, 72


def ang(a, b):
    return math.atan2(b[1] - a[1], b[0] - a[0])


def pair_phase(a_drv, a_drn, z_drn, phase_drv=None, z_drv=None):
    """(driver phase, driven phase): driver tooth on the line of centres, driven gap there."""
    beta = ang(a_drv, a_drn)
    if phase_drv is None:
        return beta, beta + math.pi + math.pi / z_drn
    pD = 2 * math.pi / z_drv
    off = (beta - phase_drv) / pD
    frac = off - round(off)
    pN = 2 * math.pi / z_drn
    return phase_drv, beta + math.pi + pN / 2 + frac * pN
