import math, random, itertools
import numpy as np
# gears: mobile -> list of (layer, tip radius, partner)
def gears(v8=True):
    return {
     'B': [('L0',9.8,'M1')],
     'M1':[('L0',2.6,'B'),('A',5.2 if v8 else 4.7,'Mn')],
     'Mn':[('A',2.7 if v8 else 3.2,'M1'),('B',6.6,'T'),('C',1.8,'MW')],
     'T': [('B',1.0,'Mn'),('Dl',6.2,'S')],
     'S': [('Dl',1.0,'T')],
     'MW':[('C',6.6,'Mn'),('E',2.2,'H'),('F',1.4,'D')],
     'H': [('E',6.2,'MW')],
     'D': [('F',7.4,'MW')],
    }
DIST={('B','M1'):12,('M1','Mn'):7.5,('Mn','T'):7.2,('T','S'):6.8,('Mn','MW'):8.0,('MW','D'):8.4}
def place(p):
    th1,psi,tau,sig,mu,dl=p
    P={'B':np.array([0,0.])}
    P['M1']=12*np.array([math.cos(th1),math.sin(th1)])
    P['Mn']=P['M1']+7.5*np.array([math.cos(psi),math.sin(psi)])
    P['T']=P['Mn']+7.2*np.array([math.cos(tau),math.sin(tau)])
    P['S']=P['T']+6.8*np.array([math.cos(sig),math.sin(sig)])
    P['MW']=P['Mn']+8.0*np.array([math.cos(mu),math.sin(mu)])
    P['D']=P['MW']+8.4*np.array([math.cos(dl),math.sin(dl)])
    P['H']=P['Mn']
    return P
def viol(P, margin=0.5):
    v=0; worst=[]
    for g8 in (True,False):
        G=gears(g8)
        for i,gl in G.items():
            for (lay,R,partner) in gl:
                for j in P:
                    if j==i or j==partner or {i,j}=={'Mn','H'}: continue
                    if i=='B': rj=0.75   # collar
                    elif j=='B': rj=1.0 if lay in ('C','E','F') else 0.5
                    else: rj=0.5
                    d=np.linalg.norm(P[i]-P[j]); need=R+rj+margin
                    if lay=='L0' and j not in ('B',): need=R+0.75+margin
                    if d<need: v+=need-d; worst.append((i,lay,j,round(d,2),round(need,2)))
    return v,worst
LS,LD,LH,LM=5.3,3.5,5.5,6.5
def extra(P):
    v=0
    d=np.linalg.norm(P['S']-P['Mn']); v+=max(0,LS+1.2-d)
    d=np.linalg.norm(P['S']-P['D']); v+=max(0,LS+0.8-d)
    d=np.linalg.norm(P['D']-P['Mn']); v+=max(0,8.1-d)
    return v
def caseR(P):
    rad={'B':9.8,'M1':5.2,'Mn':max(6.6,LM),'H':max(6.2,LH),'T':6.2,'S':max(1,LS),'MW':6.6,'D':7.4}
    # minimize max over mobiles of |c-P|+r: approximate by search
    pts=np.array([P[k] for k in rad]); rs=np.array([rad[k] for k in rad])
    from scipy.optimize import minimize
    f=lambda c: np.max(np.linalg.norm(pts-c,axis=1)+rs)
    best=None
    for c0 in [pts.mean(0)]:
        r=minimize(f,c0,method='Nelder-Mead',options={'xatol':1e-4,'fatol':1e-5,'maxiter':2000})
        if best is None or r.fun<best.fun: best=r
    return best.fun, best.x
random.seed(1)
best=None
for it in range(60000):
    p=[random.uniform(-math.pi,math.pi) for _ in range(6)]
    p[0]=0.0
    P=place(p)
    v,_=viol(P); v+=extra(P)
    if v>0: continue
    R,c=caseR(P)
    if best is None or R<best[0]:
        best=(R,p,c); print(it,R,[round(x,3) for x in p],c)
