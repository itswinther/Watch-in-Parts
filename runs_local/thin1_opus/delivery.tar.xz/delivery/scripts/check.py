"""Own inspection of the delivery against QA-W100 (an approximation of the rig).
python3 check.py [movement.json|variant_6h.json] [--quick] [--print] [--asm]"""
import json
import math
import os
import sys
import time
from fractions import Fraction as Fr

import numpy as np
import manifold3d as m3

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(APP, "tools"))
sys.path.insert(0, HERE)
import kernel  # noqa: E402
import qa  # noqa: E402

DEL = os.path.join(APP, "delivery")
CACHE = os.environ.get("PARTCACHE", "/tmp/claude-0/-tmp-claude-0-runs-thin1-opus-app/7c764678-0ff0-4c8a-b9ba-a7a4eee3d0db/scratchpad/cache")
os.makedirs(CACHE, exist_ok=True)

LEWIS = {}


def lewis(z):
    if not LEWIS:
        txt = open(os.path.join(APP, "datasheets", "DS-W04_gear_rating.md")).read()
        sec = txt.split("## 3.")[1]
        for line in sec.splitlines():
            c = [x.strip() for x in line.strip().strip("|").split("|")]
            if len(c) == 11 and c[0].isdigit():
                for u in range(10):
                    if c[u + 1] not in ("–", "-"):
                        LEWIS[int(c[0]) + u] = float(c[u + 1])
    return LEWIS[z]


def load(name):
    p = os.path.join(DEL, "parts", name + ".step")
    cp = os.path.join(CACHE, name + ".stl")
    if os.path.exists(cp) and os.path.getmtime(cp) > os.path.getmtime(p):
        return kernel.tris_to_part(kernel.read_stl(cp, 10 ** 7, 10 ** 9), 0.005)
    man = kernel.load_step_part(p, 16777216, 200000, 0.001, 0.1, 500, 120, 4096, 0.005)
    kernel.write_stl(cp, man)
    return man


def barrel():
    return kernel.tris_to_manifold(kernel.read_stl(os.path.join(APP, "supplied", "barrel.stl"), 10 ** 7, 10 ** 9))


def rot(man, axis, a):
    return qa.rot_about(man, axis, a)


def main(fname, quick=False, do_print=False, do_asm=False):
    doc = json.load(open(os.path.join(DEL, fname)))
    period = Fr(8) if fname == "movement.json" else Fr(6)
    nB = Fr(-1) / period         # turns per hour, CCW positive: barrel clockwise
    res = {}
    t0 = time.time()
    fixed = {n: load(n) for n in doc["fixed"]}
    mob = {"barrel": {"axis": (0.0, 0.0), "parts": {"barrel": barrel()}}}
    for k, m in doc["mobiles"].items():
        mob[k] = {"axis": tuple(m["axis"]), "parts": {n: load(n) for n in m["parts"]}}
    for k in mob:
        mob[k]["solid"] = kernel.union(list(mob[k]["parts"].values()))
    frame = kernel.union(list(fixed.values()))
    print("loaded in %.0f s" % (time.time() - t0))

    # C2
    bad = []
    names = list(mob)
    for i, a in enumerate(names):
        v = kernel.ivol(frame, mob[a]["solid"])
        if v > 0.01:
            bad.append(("frame", a, v))
        for b in names[i + 1:]:
            v = kernel.ivol(mob[a]["solid"], mob[b]["solid"])
            if v > 0.01:
                bad.append((a, b, v))
        ps = list(mob[a]["parts"].items())
        for x in range(len(ps)):
            for y in range(x + 1, len(ps)):
                v = kernel.ivol(ps[x][1], ps[y][1])
                if v > 0.01:
                    bad.append((ps[x][0], ps[y][0], v))
    fl = list(fixed.items())
    for x in range(len(fl)):
        for y in range(x + 1, len(fl)):
            v = kernel.ivol(fl[x][1], fl[y][1])
            if v > 0.01:
                bad.append((fl[x][0], fl[y][0], v))
    # frame link (chain)
    if len(fl) > 1:
        linked = {fl[0][0]}
        changed = True
        while changed:
            changed = False
            for n, s in fl:
                if n in linked:
                    continue
                if any(kernel.min_distance(s, fixed[l], 0.05) <= 0.01 for l in linked):
                    linked.add(n)
                    changed = True
        if len(linked) != len(fl):
            bad.append(("frame not linked", linked))
    res["C2"] = bad
    print("C2", bad or "ok")

    # 1 free to turn
    bad = []
    nang = 36 if quick else 120
    for a in names:
        s, ax = mob[a]["solid"], mob[a]["axis"]
        worst = 0
        for i in range(nang):
            v = kernel.ivol(frame, rot(s, ax, 2 * math.pi * i / nang))
            worst = max(worst, v)
        if worst > 0.01:
            bad.append((a, worst))
    res["1"] = bad
    print("1 free", bad or "ok")

    # 2 held
    dirs = {"+x": (1, 0, 0), "-x": (-1, 0, 0), "+y": (0, 1, 0), "-y": (0, -1, 0), "+z": (0, 0, 1), "-z": (0, 0, -1)}
    held = {a: {} for a in names}
    for a in names:
        for dn, d in dirs.items():
            s = mob[a]["solid"].translate([0.3 * d[0], 0.3 * d[1], 0.3 * d[2]])
            held[a][dn] = kernel.ivol(s, frame) > 0.01
    # coaxial help
    for _ in range(3):
        for a in names:
            for dn, d in dirs.items():
                if held[a][dn]:
                    continue
                s = mob[a]["solid"].translate([0.3 * d[0], 0.3 * d[1], 0.3 * d[2]])
                for b in names:
                    if b != a and math.dist(mob[a]["axis"], mob[b]["axis"]) <= 0.01 and held[b][dn]:
                        if kernel.ivol(s, mob[b]["solid"]) > 0.01:
                            held[a][dn] = True
    bad = [(a, dn) for a in names for dn in dirs if not held[a][dn]]
    res["2"] = bad
    print("2 held", bad or "ok")

    # 3 seated
    bad = []
    for a in names:
        ps = mob[a]["parts"]
        if a == "barrel" or len(ps) < 2:
            continue
        for n, s in ps.items():
            others = kernel.union([q for k, q in ps.items() if k != n])
            for dn in ("+x", "-x", "+y", "-y"):
                d = dirs[dn]
                if kernel.ivol(s.translate([0.3 * d[0], 0.3 * d[1], 0]), others) <= 0.01:
                    bad.append((n, dn))
            zs = [kernel.ivol(s.translate([0, 0, 0.3 * sg]), others) > 0.01 for sg in (1, -1)]
            if not any(zs):
                bad.append((n, "z"))
            if kernel.min_distance(s, others, 0.1) > 0.02:
                bad.append((n, "gap"))
    res["3"] = bad
    print("3 seated", bad or "ok")

    # speeds
    meshes = doc["meshes"]
    speed = {"barrel": nB}
    for _ in range(len(meshes) + 1):
        for e in meshes:
            if e["driver"] in speed and e["driven"] not in speed:
                speed[e["driven"]] = -speed[e["driver"]] * Fr(e["driver_teeth"], e["driven_teeth"])
    conflict = [e for e in meshes if e["driver"] in speed and e["driven"] in speed and
                speed[e["driven"]] != -speed[e["driver"]] * Fr(e["driver_teeth"], e["driven_teeth"])]
    print("speeds (turns/h, CCW +):", {k: str(v) for k, v in speed.items()}, "conflicts", conflict)

    # 4/5 mesh tests
    bad = []
    cutparts = {}
    for idx, e in enumerate(meshes):
        Dn, Nn = e["driver"], e["driven"]
        D, N = mob[Dn]["solid"], mob[Nn]["solid"]
        aD, aN = mob[Dn]["axis"], mob[Nn]["axis"]
        sense = 1 if speed[Dn] > 0 else -1
        r = qa.full_mesh_test(D, aD, N, aN, e["driver_teeth"], e["driven_teeth"], sense, nsteps=8 if quick else 16)
        good = qa.ok(r)
        print("  mesh %d %s->%s %s" % (idx, Dn, Nn, "ok" if good else "FAIL"),
              {k: {kk: round(vv, 4) for kk, vv in v.items()} for k, v in r.items()})
        if not good:
            bad.append(idx)
        e["_b"] = r["nom"]["H"]
        e["_m"] = r["nom"]["m"]
    res["4/5"] = bad

    # 6 nothing else collides
    declared = {frozenset((e["driver"], e["driven"])) for e in meshes}
    bad = []
    ntime = 24 if quick else 96
    rng = np.random.default_rng(1)
    for i in range(ntime):
        t = rng.uniform(0, 24)
        pos = {a: rot(mob[a]["solid"], mob[a]["axis"], float(2 * math.pi * float(speed.get(a, 0)) * t)) for a in names}
        for x in range(len(names)):
            for y in range(x + 1, len(names)):
                a, b = names[x], names[y]
                if frozenset((a, b)) in declared:
                    continue
                v = kernel.ivol(pos[a], pos[b])
                if v > 0.01:
                    bad.append((a, b, t, v))
    res["6"] = bad
    print("6", bad or "ok")

    # 7-10 hands
    h = doc["hands"]
    want = {"hour": Fr(-1, 12), "minute": Fr(-1), "seconds": Fr(-60), "day": Fr(-1, 24)}
    for k, w in want.items():
        if k in h and h[k]:
            got = speed.get(h[k]["mobile"])
            print("  hand", k, got, "ok" if got == w else "FAIL")
    print("10 common centre", math.dist(mob[h["hour"]["mobile"]]["axis"], mob[h["minute"]["mobile"]]["axis"]))
    top = max(s.bounding_box()[5] for s in fixed.values())
    for k in ("hour", "minute", "seconds", "day"):
        s = mob[h[k]["mobile"]]["parts"][h[k]["part"]]
        ax = mob[h[k]["mobile"]]["axis"]
        v = kernel.verts(s)
        reach = np.max(np.hypot(v[:, 0] - ax[0], v[:, 1] - ax[1]))
        low = s.bounding_box()[2]
        # centre of volume via voxel-free approach: slice area moments
        cx, cy = centroid(s)
        cdist = math.hypot(cx - ax[0], cy - ax[1])
        proj = s.project().area() if hasattr(s, "project") else float("nan")
        frac = proj / (math.pi * reach ** 2)
        print("11 hand %s reach %.3f low %.3f (frame top %.3f) centroid %.3f cover %.3f" % (k, reach, low, top, cdist, frac))
    print("P2 day axis to hour axis", math.dist(mob[h["day"]["mobile"]]["axis"], mob[h["hour"]["mobile"]]["axis"]))

    # 12 fits the case
    cc = doc["case_centre"]
    worst = 0
    for n, s in fixed.items():
        v = kernel.verts(s)
        worst = max(worst, np.max(np.hypot(v[:, 0] - cc[0], v[:, 1] - cc[1])))
    for a in names:
        v = kernel.verts(mob[a]["solid"])
        ax = mob[a]["axis"]
        worst = max(worst, np.max(np.hypot(v[:, 0] - ax[0], v[:, 1] - ax[1])) + math.dist(ax, cc))
    allb = [s.bounding_box() for s in list(fixed.values()) + [mob[a]["solid"] for a in names]]
    H = max(b[5] for b in allb) - min(b[2] for b in allb)
    print("12 radius %.3f (20.7)  height %.3f (13.4)" % (worst, H))

    # 14 strength
    T_barrel = 70.1
    path = bfs_path(meshes, h["seconds"]["mobile"])
    for e in path:
        Dn = e["driver"]
        TD = T_barrel * abs(float(nB / speed[Dn]))
        m = e["_m"]
        F = TD / (m * e["driver_teeth"] / 2)
        b = e["_b"]
        for z, who in ((e["driver_teeth"], Dn), (e["driven_teeth"], e["driven"])):
            if who == "barrel":
                continue
            sig = F / (b * m * lewis(z))
            print("14 %s->%s z=%d T=%.2f F=%.3f b=%.3f sigma=%.1f MPa (725)" % (Dn, e["driven"], z, TD, F, b, sig))

    if do_print:
        for a in names:
            if a == "barrel":
                continue
            for n, s in mob[a]["parts"].items():
                print("13", n, qa.printable(s))
        for n, s in fixed.items():
            print("13", n, qa.printable(s))
    print("done in %.0f s" % (time.time() - t0))


def bfs_path(meshes, target):
    from collections import deque
    prev = {"barrel": None}
    q = deque(["barrel"])
    while q:
        u = q.popleft()
        for e in meshes:
            if e["driver"] == u and e["driven"] not in prev:
                prev[e["driven"]] = e
                q.append(e["driven"])
            elif e["driven"] == u and e["driver"] not in prev:
                prev[e["driver"]] = e
                q.append(e["driver"])
    path = []
    n = target
    while prev.get(n):
        e = prev[n]
        path.append(e)
        n = e["driver"] if e["driven"] == n else e["driven"]
    return path[::-1]


def centroid(s):
    mesh = s.to_mesh()
    v = np.asarray(mesh.vert_properties)[:, :3].astype(float)
    t = np.asarray(mesh.tri_verts)
    a, b, c = v[t[:, 0]], v[t[:, 1]], v[t[:, 2]]
    vol = np.einsum("ij,ij->i", a, np.cross(b, c)) / 6
    cen = (a + b + c) / 4
    w = (cen * vol[:, None]).sum(0) / vol.sum()
    return w[0], w[1]


if __name__ == "__main__":
    args = sys.argv[1:]
    f = [a for a in args if a.endswith(".json")] or ["movement.json"]
    main(f[0], quick="--quick" in args, do_print="--print" in args)
