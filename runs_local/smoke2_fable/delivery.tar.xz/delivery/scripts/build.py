"""Builds every part (STEP), movement.json, variant_6h.json and assembly.json."""
import sys, os, json, math
import numpy as np
import cadquery as cq
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel
OUT = os.path.join(APP, "delivery")
PARTS = os.path.join(OUT, "parts")
os.makedirs(PARTS, exist_ok=True)
ALPHA = math.radians(25.0)
THIN = 0.03          # thinning of each tooth on the pitch circle (backlash 0.06 per mesh)
ADD, DED = 0.95, 1.4

def inv(a): return math.tan(a) - a

def gear_poly(z, m, x=0.0, phase=0.0, thin=THIN, add=ADD, ded=DED, nfl=7):
    r = m * z / 2; rb = r * math.cos(ALPHA)
    ra = r + m * (add + x); rf = r - m * (ded - x)
    s = m * (math.pi / 2 + 2 * x * math.tan(ALPHA)) - thin
    def psi(rho): return s / (2 * r) + inv(ALPHA) - inv(math.acos(min(1.0, rb / rho)))
    while psi(ra) * ra < 0.04: ra -= 0.002
    r0 = max(rb, rf)
    rs = [r0 + (ra - r0) * (k / (nfl - 1)) ** 1.0 for k in range(nfl)]
    tooth = []
    if rf < rb - 1e-9: tooth.append((rf, -psi(r0)))
    tooth += [(q, -psi(q)) for q in rs]
    tooth += [(q, psi(q)) for q in reversed(rs)]
    if rf < rb - 1e-9: tooth.append((rf, psi(r0)))
    gap = 2 * math.pi / z - 2 * psi(r0)
    assert gap > 0.02 / rf, (z, m, gap)
    for k in (1, 2): tooth.append((rf, psi(r0) + gap * k / 3))
    pts = []
    for i in range(z):
        for (q, a) in tooth:
            t = a + phase + 2 * math.pi * i / z
            pts.append((q * math.cos(t), q * math.sin(t)))
    return pts, ra, rf

def mate_phase(pA, phA, zA, pB, zB):
    th = math.atan2(pB[1] - pA[1], pB[0] - pA[0])
    return th + math.pi + math.pi / zB - (phA - th) * zA / zB

def prism(pts, z0, z1, c, hole=None):
    w = cq.Workplane("XY").workplane(offset=z0).polyline([(c[0] + p[0], c[1] + p[1]) for p in pts]).close().extrude(z1 - z0)
    if hole: w = w.cut(cyl(c, hole, z0 - 1, z1 + 1))
    return w

def cyl(c, r, z0, z1):
    return cq.Workplane("XY").workplane(offset=z0).center(c[0], c[1]).circle(r).extrude(z1 - z0)

def lathe(c, prof):
    """prof: closed polygon in (radius, z); revolved about the vertical line through c."""
    w = cq.Workplane("XZ").polyline(prof).close().revolve(360, (0, 0, 0), (0, 1, 0))
    return w.translate((c[0], c[1], 0))

def steps(segs, bore=None):
    """segs: list of (z0, z1, r) stacked bottom to top -> lathe profile. bore: list of (z0, z1, r) or None."""
    out = []
    for (z0, z1, r) in segs: out += [(r, z0), (r, z1)]
    if bore is None:
        inn = [(0, segs[-1][1]), (0, segs[0][0])]
    else:
        inn = []
        for (z0, z1, r) in reversed(bore): inn += [(r, z1), (r, z0)]
    prof = out + inn
    cl = [prof[0]]
    for p in prof[1:]:
        if abs(p[0] - cl[-1][0]) > 1e-9 or abs(p[1] - cl[-1][1]) > 1e-9: cl.append(p)
    return cl

def fuse(items):
    w = items[0]
    for it in items[1:]: w = w.union(it)
    return w

def save(name, w):
    kernel.write_step(os.path.join(PARTS, name + ".step"), w)

# ---------------- layout ----------------
def pol(p, d, a): return (p[0] + d * math.cos(a), p[1] + d * math.sin(a))
O = (0.0, 0.0)
M1 = (12.0, 0.0)
C = pol(M1, 9.0, 2.0822)
T = pol(C, 9.0, 2.6513)
S = pol(T, 8.5, 0.3121)
MW = pol(C, 5.0, 3.5706)
MH = 10.0 / 48.0                      # module of the hour / day meshes
D = pol(MW, MH * 42, 4.4363)
CC = (3.77, 4.9)
# levels
ZB0, ZB1 = -1.1, -0.1                 # bottom plate
L0 = (0.1, 0.9); L1 = (1.3, 1.9); L2 = (2.2, 2.8); L3 = (3.1, 3.7); L4 = (4.0, 4.6); L5 = (4.9, 5.5)
ZT0, P = 5.9, 6.9                     # top plate
SH = ZT0 - 0.05                       # shoulders under the top plate
G = 0.004                             # seat gap between parts of one mobile / fixed parts
dist = lambda a, b: math.hypot(a[0] - b[0], a[1] - b[1])

def pick_pillars():
    discs = [(O, 9.8), (M1, 6.33), (C, 8.2), (T, 7.7), (S, 1.3), (MW, 4.25), (D, 7.75)]
    cand = []
    for i in range(-240, 241):
        for j in range(-240, 241):
            p = (CC[0] + i * 0.1, CC[1] + j * 0.1)
            if dist(p, CC) > 16.6: continue
            if all(dist(p, c) >= r + 1.1 for c, r in discs): cand.append(p)
    lug = [p for p in cand if dist(p, O) < 11.05 and
           all(dist((p[0] * t, p[1] * t), M1) > 6.9 and dist((p[0] * t, p[1] * t), C) > 4.5 for t in np.linspace(0.75, 1, 6))]
    cn = np.array(cand[::5]); best = None
    for a in lug[::3]:
        da = np.hypot(cn[:, 0] - a[0], cn[:, 1] - a[1])
        far = cn[da > 10]
        for b in far[::3]:
            q = np.minimum(np.hypot(cn[:, 0] - b[0], cn[:, 1] - b[1]), da); k = int(q.argmax())
            v = min(q[k], dist(a, b))
            if best is None or v > best[0]: best = (v, tuple(a), (float(b[0]), float(b[1])), (float(cn[k][0]), float(cn[k][1])))
    return best[1:]

def hand(c, z0, zs, z1, r_low, r_tip, rh, reach, ang, width):
    """hub from z0 to z1 with a bore r_low + G below the seat zs and r_tip + G above; pointer from zs + G to z1."""
    zp = zs + G
    hub = lathe(c, steps([(z0, z1, rh)], bore=[(z0, zp, r_low + G), (zp, z1, r_tip + G)]) if zp > z0 + 1e-6
                else steps([(z0, z1, rh)], bore=[(z0, z1, r_tip + G)]))
    x0 = (r_tip + G + rh) / 2
    bar = cq.Workplane("XY").workplane(offset=zp).moveTo(x0, -width / 2).lineTo(reach - 0.5, -width / 2).lineTo(reach, -0.15) \
        .lineTo(reach, 0.15).lineTo(reach - 0.5, width / 2).lineTo(x0, width / 2).close().extrude(z1 - zp)
    bar = bar.rotate((0, 0, 0), (0, 0, 1), math.degrees(ang)).translate((c[0], c[1], 0))
    return hub.union(bar)

def main():
    PA, PB, PC = pick_pillars()
    print("pillars", PA, PB, PC)
    geo = {}
    # ---- gear phases ----
    ph_m1p = mate_phase(O, 0.0, 96, M1, 24)
    # third / seconds
    ph_cw = 0.0; ph_tp = mate_phase(C, ph_cw, 80, T, 10)
    ph_tw = 0.0; ph_sp = mate_phase(T, ph_tw, 75, S, 10)
    ph_can = 0.0; ph_mww = mate_phase(C, ph_can, 10, MW, 40)
    ph_mwp = 0.0; ph_h = mate_phase(MW, ph_mwp, 12, C, 36); ph_d = mate_phase(MW, ph_mwp, 12, D, 72)

    def arbor_full(c):   # pivots in both plates
        return [(-1.0, -0.05, 0.3), (-0.05, SH, 0.5), (SH, 6.5, 0.3)]

    # ---- M1 and centre, per build ----
    for tag, zw, zp in (("8h", 40, 20), ("6h", 36, 24)):
        g1, _, _ = gear_poly(24, 0.2, 0, ph_m1p)
        g2, _, _ = gear_poly(zw, 0.3, 0, 0.0)
        save("m1_" + tag, fuse([lathe(M1, steps(arbor_full(M1))), prism(g1, L0[0], L0[1], M1), prism(g2, L1[0], L1[1], M1)]))
        gp, _, _ = gear_poly(zp, 0.3, 0, mate_phase(M1, 0.0, zw, C, zp))
        gw, _, _ = gear_poly(80, 0.2, -0.2, ph_cw)
        gc, _, _ = gear_poly(10, 0.2, 0.2, ph_can)
        arb = [(-1.0, -0.05, 0.3), (-0.05, L4[1], 0.5), (L4[1], P + 1.5, 0.35), (P + 1.5, P + 1.85, 0.25)]
        save("centre_" + tag, fuse([lathe(C, steps(arb)), prism(gp, L1[0], L1[1], C), prism(gw, L2[0], L2[1], C),
                                    prism(gc, L4[0], L4[1], C)]))
    # ---- third ----
    gp, _, _ = gear_poly(10, 0.2, 0.2, ph_tp); gw, _, _ = gear_poly(75, 0.2, -0.2, ph_tw)
    save("third", fuse([lathe(T, steps(arbor_full(T))), prism(gp, L2[0], L2[1], T), prism(gw, L3[0], L3[1], T)]))
    # ---- seconds (hangs in the top plate) ----
    gp, _, _ = gear_poly(10, 0.2, 0.2, ph_sp)
    save("seconds_arbor", fuse([lathe(S, steps([(L3[0] - 0.2, SH, 0.6), (SH, P + 0.5, 0.35), (P + 0.5, P + 0.85, 0.25)])),
                                prism(gp, L3[0], L3[1], S)]))
    save("seconds_hand", hand(S, P + 0.05, P + 0.5, P + 0.85, 0.35, 0.25, 0.7, 5.3, 0.5, 0.45))
    # ---- minute wheel ----
    gw, _, _ = gear_poly(40, 0.2, -0.2, ph_mww); gp, _, _ = gear_poly(12, MH, 0, ph_mwp)
    save("minute_wheel", fuse([lathe(MW, steps([(L4[0] - 0.2, SH, 0.6), (SH, P + 0.15, 0.35), (P + 0.15, P + 0.4, 0.25)])),
                               prism(gw, L4[0], L4[1], MW), prism(gp, L5[0], L5[1], MW)]))
    save("minute_wheel_collar", lathe(MW, steps([(P + 0.05, P + 0.4, 0.7)],
                                                bore=[(P + 0.05, P + 0.15 + G, 0.35 + G), (P + 0.15 + G, P + 0.4, 0.25 + G)])))
    # ---- hour wheel ----
    gw, _, _ = gear_poly(36, MH, 0, ph_h)
    pipe = [(L4[1] + 0.05, L5[1], 0.7), (L5[1], SH, 1.2), (SH, P + 1.0, 0.9), (P + 1.0, P + 1.35, 0.7)]
    save("hour_wheel", fuse([lathe(C, steps(pipe, bore=[(L4[1] + 0.05, P + 1.35, 0.4)])), prism(gw, L5[0], L5[1], C, hole=0.55)]))
    save("hour_hand", hand(C, P + 1.0 + G, P + 1.0, P + 1.35, 0.9, 0.7, 1.2, 5.3, 2.2, 0.6))
    save("minute_hand", hand(C, P + 1.5 + G, P + 1.5, P + 1.85, 0.35, 0.25, 0.7, 6.3, 0.3, 0.5))
    # ---- day wheel (hangs in the top plate) ----
    gw, _, _ = gear_poly(72, MH, 0, ph_d)
    save("day_wheel", fuse([lathe(D, steps([(L5[0], SH, 0.6), (SH, P + 0.15, 0.35), (P + 0.15, P + 0.4, 0.25)])),
                            prism(gw, L5[0], L5[1], D)]))
    save("day_hand", hand(D, P + 0.05, P + 0.15, P + 0.4, 0.35, 0.25, 0.7, 3.4, 1.0, 0.5))
    # ---- frame ----
    Rpl = max(dist(CC, p) for p in (O, M1, C, T, S, MW, D, PA, PB, PC)) + 1.3
    print("plate radius", Rpl)
    bp = cyl(CC, Rpl, ZB0, ZB1).cut(cyl(O, 0.56, -2, 0))
    for c in (M1, C, T): bp = bp.cut(cyl(c, 0.34, -2, 0))
    save("bottom_plate", bp)
    tp = cyl(CC, Rpl, ZT0, P)
    for c in (M1, T): tp = tp.cut(cyl(c, 0.34, ZT0 - 1, 6.55))
    tp = tp.cut(cyl(C, 0.96, ZT0 - 1, P + 1))
    for c in (S, MW, D): tp = tp.cut(cyl(c, 0.4, ZT0 - 1, P + 1))
    save("top_plate", tp)
    for nm, p in (("pillar_a", PA), ("pillar_b", PB), ("pillar_c", PC)):
        w = cyl(p, 0.8, ZB1 + G, ZT0 - G)
        if nm == "pillar_a":
            a = math.atan2(p[1], p[0]); d = dist(p, O)
            lug = cq.Workplane("XY").workplane(offset=1.1).center((d + 8.6) / 2, 0).rect(d - 8.6, 1.2).extrude(0.6)
            w = w.union(lug.rotate((0, 0, 0), (0, 0, 1), math.degrees(a)))
        save(nm, w)
    # ---- movement files ----
    fixed = ["bottom_plate", "top_plate", "pillar_a", "pillar_b", "pillar_c"]
    def movement(tag, zw, zp):
        return {
            "case_centre": list(CC), "fixed": fixed,
            "mobiles": {
                "m1": {"axis": list(M1), "parts": ["m1_" + tag]},
                "centre": {"axis": list(C), "parts": ["centre_" + tag, "minute_hand"]},
                "third": {"axis": list(T), "parts": ["third"]},
                "seconds": {"axis": list(S), "parts": ["seconds_arbor", "seconds_hand"]},
                "minute_wheel": {"axis": list(MW), "parts": ["minute_wheel", "minute_wheel_collar"]},
                "hour": {"axis": list(C), "parts": ["hour_wheel", "hour_hand"]},
                "day": {"axis": list(D), "parts": ["day_wheel", "day_hand"]}},
            "meshes": [
                {"driver": "barrel", "driver_teeth": 96, "driven": "m1", "driven_teeth": 24},
                {"driver": "m1", "driver_teeth": zw, "driven": "centre", "driven_teeth": zp},
                {"driver": "centre", "driver_teeth": 80, "driven": "third", "driven_teeth": 10},
                {"driver": "third", "driver_teeth": 75, "driven": "seconds", "driven_teeth": 10},
                {"driver": "centre", "driver_teeth": 10, "driven": "minute_wheel", "driven_teeth": 40},
                {"driver": "minute_wheel", "driver_teeth": 12, "driven": "hour", "driven_teeth": 36},
                {"driver": "minute_wheel", "driver_teeth": 12, "driven": "day", "driven_teeth": 72}],
            "hands": {"hour": {"mobile": "hour", "part": "hour_hand"},
                      "minute": {"mobile": "centre", "part": "minute_hand"},
                      "seconds": {"mobile": "seconds", "part": "seconds_hand"},
                      "day": {"mobile": "day", "part": "day_hand"}}}
    json.dump(movement("8h", 40, 20), open(os.path.join(OUT, "movement.json"), "w"), indent=1)
    json.dump(movement("6h", 36, 24), open(os.path.join(OUT, "variant_6h.json"), "w"), indent=1)
    # ---- assembly: every part is lowered straight down ----
    order = ["bottom_plate", "barrel", "pillar_a", "pillar_b", "pillar_c", "m1_8h", "centre_8h", "third", "seconds_arbor",
             "minute_wheel", "hour_wheel", "day_wheel", "top_plate", "day_hand", "minute_wheel_collar", "seconds_hand",
             "hour_hand", "minute_hand"]
    zmin = {"bottom_plate": ZB0, "barrel": -1.0, "top_plate": ZT0}
    paths = {}
    for nm in order:
        lift = (P + 1.85) + 5.3 - ZB0          # clears the grown box whatever the part
        n = int(math.ceil(lift / 0.19))
        ps = []
        for k in range(n, -1, -1):
            Tm = np.eye(4); Tm[2, 3] = lift * k / n
            ps.append([[float(v) for v in row] for row in Tm])
        paths[nm] = ps
    json.dump({"order": order, "paths": paths}, open(os.path.join(OUT, "assembly.json"), "w"))

if __name__ == "__main__":
    main()
