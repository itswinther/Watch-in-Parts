"""My own replica of the acceptance test, as I read instruction.md. Usage: verify.py movement.json 8 [checks...]"""
import sys, os, json, math, time, itertools
from fractions import Fraction as Fr
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(APP, "tools"))
import kernel as K
import manifold3d as m3
DEL = os.path.join(APP, "delivery")
TOL = 0.01
_cache = {}
def part(name):
    if name not in _cache:
        if name == "barrel":
            _cache[name] = K.tris_to_part(K.read_stl(os.path.join(APP, "supplied/barrel.stl"), 10**7, 10**9), 0.005)
        else:
            _cache[name] = K.load_step_part(os.path.join(DEL, "parts", name + ".step"), 16777216, 200000, 0.001, 0.1, 500, 120, 4096, 0.005)
    return _cache[name]
def rot(man, ax, deg):
    return man.translate([-ax[0], -ax[1], 0]).rotate([0, 0, deg]).translate([ax[0], ax[1], 0])
def union(l): return K.union(l)

class Mv:
    def __init__(s, fn, hours):
        s.doc = json.load(open(os.path.join(DEL, fn))); d = s.doc
        s.hours = hours
        s.fixed = d["fixed"]; s.mob = dict(d["mobiles"]); s.mob["barrel"] = {"axis": [0, 0], "parts": ["barrel"]}
        s.frame = union([part(p) for p in s.fixed])
        s.sol = {k: union([part(p) for p in v["parts"]]) for k, v in s.mob.items()}
        s.ax = {k: v["axis"] for k, v in s.mob.items()}
        s.cc = d["case_centre"]; s.meshes = d["meshes"]
    def speeds(s):
        sp = {"barrel": Fr(-1, s.hours)}  # ccw positive, rev/h
        ch = True; ok = True
        while ch:
            ch = False
            for m in s.meshes:
                a, b, za, zb = m["driver"], m["driven"], m["driver_teeth"], m["driven_teeth"]
                for (p, q, zp, zq) in ((a, b, za, zb), (b, a, zb, za)):
                    if p in sp:
                        v = -sp[p] * zp / zq
                        if q not in sp: sp[q] = v; ch = True
                        elif sp[q] != v: ok = False
        return sp, ok

def c2(M):
    ok = True
    names = list(M.sol)
    for a in names:
        v = K.ivol(M.frame, M.sol[a])
        if v > TOL: print("  C2 frame/", a, v); ok = False
    for a, b in itertools.combinations(names, 2):
        v = K.ivol(M.sol[a], M.sol[b])
        if v > TOL: print("  C2", a, b, v); ok = False
    for a, b in itertools.combinations(M.fixed, 2):
        v = K.ivol(part(a), part(b))
        if v > TOL: print("  C2 fixed", a, b, v); ok = False
    for k, v in M.mob.items():
        for a, b in itertools.combinations(v["parts"], 2):
            w = K.ivol(part(a), part(b))
            if w > TOL: print("  C2 mobile parts", a, b, w); ok = False
    # connectivity
    seen = {M.fixed[0]}; ch = True
    while ch:
        ch = False
        for a in M.fixed:
            if a in seen: continue
            if any(K.min_distance(part(a), part(b), 0.05) <= 0.01 for b in seen): seen.add(a); ch = True
    if len(seen) != len(M.fixed): print("  C2 frame not joined", set(M.fixed) - seen); ok = False
    return ok

def free(M):
    ok = True
    for k in M.sol:
        w = max(K.ivol(M.frame, rot(M.sol[k], M.ax[k], 5 * i)) for i in range(72))
        if w > TOL: print("  free", k, w); ok = False
    return ok

DIRS = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
def held(M):
    ok = True
    H = {(k, d): K.ivol(M.frame, M.sol[k].translate([0.3 * c for c in d])) > TOL for k in M.sol for d in DIRS}
    info = {kd: ("frame" if v else None) for kd, v in H.items()}
    ch = True
    while ch:
        ch = False
        for (k, d), v in list(H.items()):
            if v: continue
            for o in M.sol:
                if o == k or not H[(o, d)]: continue
                if math.hypot(M.ax[o][0] - M.ax[k][0], M.ax[o][1] - M.ax[k][1]) > 0.01: continue
                if K.ivol(M.sol[o], M.sol[k].translate([0.3 * c for c in d])) > TOL:
                    H[(k, d)] = True; ch = True; break
    for kd, v in H.items():
        if not v: print("  not held", kd); ok = False
    return ok

def seated(M):
    ok = True
    for k, v in M.mob.items():
        ps = v["parts"]
        if k == "barrel" or len(ps) < 2: continue
        for p in ps:
            oth = union([part(q) for q in ps if q != p])
            r = [K.ivol(oth, part(p).translate([0.3 * c for c in d])) for d in DIRS]
            if min(r[:4]) <= TOL or max(r[4:]) <= TOL: print("  seated", p, r); ok = False
        seen = {ps[0]}; ch = True
        while ch:
            ch = False
            for a in ps:
                if a not in seen and any(K.min_distance(part(a), part(b), 0.05) <= 0.02 for b in seen): seen.add(a); ch = True
        if len(seen) != len(ps): print("  seated chain", k); ok = False
    return ok

def mesh_test(M, m, shift=0.0, verbose=True):
    Dn, Nn, zD, zN = m["driver"], m["driven"], m["driver_teeth"], m["driven_teeth"]
    D, N = M.sol[Dn], M.sol[Nn]; aD, aN = M.ax[Dn], list(M.ax[Nn])
    dx, dy = aN[0] - aD[0], aN[1] - aD[1]; d = math.hypot(dx, dy)
    mod = 2 * d / (zD + zN)
    if shift:
        u = (dx / d, dy / d) if d > 1e-9 else (1, 0)
        N = N.translate([u[0] * shift, u[1] * shift, 0]); aN = [aN[0] + u[0] * shift, aN[1] + u[1] * shift]
    ok = True; worst = [0, 1e9, 0]
    def pose(i):
        a = i * 360.0 / (8 * zD)
        return rot(D, aD, a), rot(N, aN, -a * zD / zN)
    for i in range(8 * max(zD, zN)):
        for j in ([i, i + 1 / 3, i + 1 / 5] if i % 8 == 0 else [i]):
            Dr, Nr = pose(j)
            v = K.ivol(Dr, Nr); worst[0] = max(worst[0], v)
            if v > TOL: ok = False
            if j == i and i % 4 == 0 and (Dr ^ Nr).is_empty():
                g = Dr.min_gap(Nr, 0.5); worst[2] = max(worst[2], g)
                if g > 0.1: ok = False
            if j == i and i % 8 == 0:
                D2 = rot(Dr, aD, 90.0 / zD)
                reg = (D2 ^ Nr) - Dr
                V = reg.volume()
                if reg.is_empty() or V < 0.001: ok = False; worst[1] = 0; continue
                bb = reg.bounding_box(); Hh = bb[5] - bb[2]
                q = V / Hh / (0.5 * mod * mod); worst[1] = min(worst[1], q)
                if not (q > 1): ok = False
    if verbose: print("  mesh %s-%s shift %+.2f: %s  max ivol %.5f  min drive ratio %.2f  max gap %.4f" % (Dn, Nn, shift, "ok" if ok else "FAIL", *worst), flush=True)
    return ok

def _mt(args):
    fn, hours, k, shift = args
    M = Mv(fn, hours)
    return mesh_test(M, M.meshes[k], shift)

def train(M, fn, shifts=(0.0,)):
    from multiprocessing import Pool
    jobs = [(fn, M.hours, k, s) for k in range(len(M.meshes)) for s in shifts]
    with Pool(4) as p: r = p.map(_mt, jobs, chunksize=1)
    return all(r)

def nothing_else(M):
    sp, _ = M.speeds(); ok = True
    declared = {frozenset((m["driver"], m["driven"])) for m in M.meshes}
    for a, b in itertools.combinations(M.sol, 2):
        if frozenset((a, b)) in declared: continue
        if not K.bbox_overlap(_sweep_bb(M, a), _sweep_bb(M, b)): continue
        wa, wb = sp.get(a, Fr(0)), sp.get(b, Fr(0))
        seqs = []
        f = max(abs(wa), abs(wb))
        if f > 0: seqs += [(float(wa / f) * 360 * i / 144, float(wb / f) * 360 * i / 144) for i in range(144)]
        else: seqs.append((0, 0))
        if wa != wb:
            r = abs(wa - wb)
            seqs += [(float(wa / r) * 360 * i / 144, float(wb / r) * 360 * i / 144) for i in range(144)]
        w = max(K.ivol(rot(M.sol[a], M.ax[a], x), rot(M.sol[b], M.ax[b], y)) for x, y in seqs)
        if w > TOL: print("  collide", a, b, w); ok = False
    return ok
def _sweep_bb(M, k):
    v = K.verts(M.sol[k]); r = np.hypot(v[:, 0] - M.ax[k][0], v[:, 1] - M.ax[k][1]).max()
    return K.box([M.ax[k][0] - r, M.ax[k][1] - r, v[:, 2].min()], [M.ax[k][0] + r, M.ax[k][1] + r, v[:, 2].max()])

def hands(M):
    sp, cons = M.speeds(); ok = cons
    want = {"hour": Fr(-1, 12), "minute": Fr(-1), "seconds": Fr(-60), "day": Fr(-1, 24)}
    h = M.doc["hands"]
    for k, w in want.items():
        if sp.get(h[k]["mobile"]) != w: print("  hand speed", k, sp.get(h[k]["mobile"])); ok = False
    ztop = max(K.verts(part(p))[:, 2].max() for p in M.fixed)
    for k, reach in (("hour", 5), ("minute", 5), ("seconds", 5), ("day", 3)):
        ax = M.ax[h[k]["mobile"]]; pm = part(h[k]["part"]); v = K.verts(pm)
        r = np.hypot(v[:, 0] - ax[0], v[:, 1] - ax[1]).max()
        mesh = pm.to_mesh(); vv = np.asarray(mesh.vert_properties)[:, :3].astype(float); t = vv[np.asarray(mesh.tri_verts)]
        vol6 = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])); cen = ((t.sum(1) / 4) * vol6[:, None]).sum(0) / vol6.sum()
        cd = math.hypot(cen[0] - ax[0], cen[1] - ax[1])
        print("  hand %s reach %.2f lowest %.3f (frame top %.3f) centroid %.2f" % (k, r, v[:, 2].min(), ztop, cd))
        if r < reach or v[:, 2].min() < ztop or cd < 0.5: ok = False
    a, b = M.ax[h["hour"]["mobile"]], M.ax[h["minute"]["mobile"]]
    if math.hypot(a[0] - b[0], a[1] - b[1]) > 0.01: ok = False
    d = M.ax[h["day"]["mobile"]]
    if math.hypot(a[0] - d[0], a[1] - d[1]) < 6: ok = False
    return ok

def case(M, R=20.7, Hmax=13.4):
    ok = True; zs = []
    for p in M.fixed:
        v = K.verts(part(p)); zs += [v[:, 2].min(), v[:, 2].max()]
        r = np.hypot(v[:, 0] - M.cc[0], v[:, 1] - M.cc[1]).max()
        if r > R: print("  case fixed", p, r); ok = False
    worst = 0
    for k in M.sol:
        v = K.verts(M.sol[k]); zs += [v[:, 2].min(), v[:, 2].max()]
        r = np.hypot(v[:, 0] - M.ax[k][0], v[:, 1] - M.ax[k][1]).max() + math.hypot(M.ax[k][0] - M.cc[0], M.ax[k][1] - M.cc[1])
        worst = max(worst, r)
        if r > R: print("  case mobile", k, r); ok = False
    print("  case: worst mobile radius %.2f, height %.2f" % (worst, max(zs) - min(zs)))
    return ok and max(zs) - min(zs) <= Hmax

def printable_one(name):
    man = part(name); bb = man.bounding_box(); h = 0.05
    lo = np.array([math.floor((bb[i] - 0.0113) / h) * h + 0.0113 - h - h / 2 for i in range(3)])
    shape = tuple(int(math.ceil((bb[i + 3] - lo[i]) / h)) + 2 for i in range(3))
    n, dev = K.opening_test_slabs(man, lo, shape, h, 1.5, 1.0, 6.0)
    return name, n, dev
def printable(names):
    from multiprocessing import Pool
    t = time.time()
    with Pool(4) as p: r = p.map(printable_one, names, chunksize=1)
    ok = True
    for name, n, dev in r:
        good = n >= 1 and dev <= 4.0 + 1e-9
        print("  printable %-22s pieces %d dev %.2f voxels %s" % (name, n, dev, "ok" if good else "FAIL"))
        ok &= good
    print("  printable time (4 procs) %.0fs" % (time.time() - t))
    return ok

def assembly():
    M = Mv("movement.json", 8); A = json.load(open(os.path.join(DEL, "assembly.json")))
    names = M.fixed + [p for k, v in M.mob.items() for p in v["parts"]]
    allbb = union([part(p) for p in names]).bounding_box()
    grown = [allbb[0] - 5, allbb[1] - 5, allbb[2] - 5, allbb[3] + 5, allbb[4] + 5, allbb[5] + 5]
    order = []
    for n in A["order"]:
        if n in names and n not in order: order.append(n)
    placed = [p for p in names if p not in order]
    if placed: print("  not in order:", placed)
    good = 0
    for n in order:
        path = np.array(A["paths"].get(n, []), float); pm = part(n); ok = 2 <= len(path) <= 1500
        if ok:
            R = path[:, :3, :3]
            ok &= np.isfinite(path).all() and np.abs(np.einsum("nji,njk->nik", R, R) - np.eye(3)).max() < 1e-6 and np.abs(np.linalg.det(R) - 1).max() < 1e-6
            ok &= np.abs(path[:, 3] - [0, 0, 0, 1]).max() < 1e-6 and np.abs(path[-1] - np.eye(4)).max() < 1e-6
            v = K.verts(pm); w = np.einsum("nij,vj->nvi", R, v) + path[:, None, :3, 3]
            if np.linalg.norm(np.diff(w, axis=0), axis=2).max() > 0.2: ok = False; print("   step too long", n)
            b0 = K.apply(pm, path[0]).bounding_box()
            if all(b0[i] < grown[i + 3] and grown[i] < b0[i + 3] for i in range(3)): ok = False; print("   start inside box", n)
            worst = 0
            for Tm in path:
                q = K.apply(pm, Tm)
                for o in placed:
                    worst = max(worst, K.ivol(q, part(o)))
            if worst > TOL: ok = False; print("   collides", n, worst)
        print("  assembly %-22s %s" % (n, "installed" if ok else "NOT installed"), flush=True)
        good += bool(ok); placed.append(n)
    return good == len(names)

if __name__ == "__main__":
    fn, hours = sys.argv[1], int(sys.argv[2]); which = sys.argv[3:] or ["c2", "free", "held", "seated", "else", "hands", "case", "train", "train5", "print"]
    t0 = time.time(); res = {}
    if which == ["assembly"]:
        print("assembly", assembly()); sys.exit()
    M = Mv(fn, hours); print("loaded %.0fs" % (time.time() - t0))
    fns = {"c2": lambda: c2(M), "free": lambda: free(M), "held": lambda: held(M), "seated": lambda: seated(M),
           "else": lambda: nothing_else(M), "hands": lambda: hands(M), "case": lambda: case(M),
           "train": lambda: train(M, fn), "train5": lambda: train(M, fn, (0.03, -0.03)),
           "print": lambda: printable(M.fixed + [p for k, v in M.mob.items() if k != "barrel" for p in v["parts"]])}
    for w in which:
        t = time.time(); res[w] = fns[w](); print("%s: %s (%.0fs)" % (w, "PASS" if res[w] else "FAIL", time.time() - t), flush=True)
    print(res)
