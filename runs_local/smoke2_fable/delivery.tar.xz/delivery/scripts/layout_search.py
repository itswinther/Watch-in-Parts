# random search for the plan layout of the arbors (see build.py for the result that was kept)
import numpy as np
from scipy.optimize import minimize
O=np.zeros(2); M1=np.array([12.,0])
def pos(v):
    a,b,g,d,e=v[:5]
    C=M1+9*np.array([np.cos(a),np.sin(a)])
    T=C+9*np.array([np.cos(b),np.sin(b)])
    S=T+8.5*np.array([np.cos(g),np.sin(g)])
    MW=C+5*np.array([np.cos(d),np.sin(d)])
    D=MW+8.75*np.array([np.cos(e),np.sin(e)])
    return C,T,S,MW,D,np.array(v[5:7])
def cons(v):
    C,T,S,MW,D,cc=pos(v)
    n=np.linalg.norm
    g=[n(C)-10.45, n(M1-T)-8.35, n(M1-MW)-4.9, n(M1-D)-8.4, n(T)-10.45, n(T-MW)-4.9, n(T-D)-8.4,
       n(S-MW)-4.9, n(S-C)-6.5, n(S-D)-8.4, n(D-C)-11.8, n(S)-10.45+0, n(S-M1)-7.0]
    R=[n(cc)+9.8, n(M1-cc)+6.4, n(C-cc)+8.3, n(T-cc)+7.7, n(S-cc)+5.4, n(MW-cc)+4.3, n(D-cc)+7.8]
    return np.array(g), max(R)
def f(v):
    g,R=cons(v)
    return R+100*np.sum(np.minimum(g-0.35,0)**2)*10
rng=np.random.default_rng(1); best=None
for k in range(300):
    v0=np.concatenate([rng.uniform(0,2*np.pi,5),rng.uniform(-3,12,2)])
    r=minimize(f,v0,method='Nelder-Mead',options={'maxiter':4000,'xatol':1e-4,'fatol':1e-6})
    g,R=cons(r.x)
    if g.min()>0.3 and (best is None or R<best[0]): best=(R,r.x); print(R, np.round(r.x,4), g.min())
C,T,S,MW,D,cc=pos(best[1]); print('C',C,'T',T,'S',S,'MW',MW,'D',D,'cc',cc)
