from layout2 import *
D1=7.8;P,H=prims(D1);SK=skipset(P);random.seed(1)
cnt=0;cyc=0;ex=None
from collections import Counter
cc=Counter()
for it in range(30000):
    ang=[random.uniform(0,2*math.pi) for _ in range(7)]
    m,pos=score(D1,ang,P,SK)
    if m<0.3: continue
    cnt+=1
    E=edges(P,pos)
    if toposort(P.keys(),E) is None:
        cyc+=1
        # find 2-cycles
        for a,b in E:
            if (b,a) in E: cc[(min(a,b),max(a,b))]+=1
print(cnt,cyc); print(cc.most_common(10))
