import numpy as np, math, random, json, itertools
from layout import L0,L1,L2,L3,L4,L5,L6,L7,FOOT,TOP,CH,build as _b
def prims(D1):
    rAv=0.514*D1+0.1; rMp=0.6*D1
    P={};HAND={}
    P['B']=[(0,1,9.8),(-1,5.6,0.5),(3.3,4.9,1.0)]
    P['A']=[(*L0,1.4),(*L1,rAv),(*L2,6.2),(-0.5,4.9,0.4),TOP]
    P['X']=[FOOT,(*L2,1.4),(*L3,5.0),(-0.5,4.9,0.4),TOP]
    P['Y']=[FOOT,(*L3,1.8),(*L4,3.8),(-0.5,4.9,0.4),TOP]
    P['S']=[FOOT,(*L4,1.4),(-0.5,7.1,0.4),TOP]
    P['M']=[FOOT,(*L1,rMp),(*L5,1.5),(-0.5,6.7,0.5)]
    P['H']=[(*L6,4.95),(3.72,6.3,0.9),(4.55,4.9,1.4)]
    P['I']=[FOOT,(*L5,5.3),(*L6,1.8),(*L7,1.3),(-0.5,4.9,0.4)]
    P['D']=[FOOT,(*L7,6.7),(-0.5,5.9,0.4)]
    HAND={'S':(6.8,7.1,5.5),'M':(6.4,6.7,5.4),'H':(6.0,6.3,5.2),'D':(5.6,5.9,3.3)}
    for k,h in HAND.items(): P[k]=P[k]+[h]
    return P,HAND
def skipset(P):
    pr=lambda k,lv: [p for p in P[k] if (p[0],p[1])==lv][0]
    return {('B','A'):[(P['B'][0],P['A'][0])],('A','M'):[(pr('A',L1),pr('M',L1))],('A','X'):[(pr('A',L2),pr('X',L2))],
        ('X','Y'):[(pr('X',L3),pr('Y',L3))],('Y','S'):[(pr('Y',L4),pr('S',L4))],('M','I'):[(pr('M',L5),pr('I',L5))],
        ('I','D'):[(pr('I',L7),pr('D',L7))],('I','H'):[(pr('I',L6),pr('H',L6))]}
def clear(P,SK,i,j,d,margin=0.25):
    skip=SK.get((i,j),[])+[(b,a) for (a,b) in SK.get((j,i),[])]
    w=1e9
    for a in P[i]:
        for b in P[j]:
            if a[1]+0.05<=b[0] or b[1]+0.05<=a[0]: continue
            if (a,b) in skip: continue
            w=min(w,d-(a[2]+b[2]+margin))
    return w
HANDZ={6.8,6.4,6.0,5.6}
def edges(P,pos):
    """edge i->j means i must be placed before j (vertical descent)."""
    E=set(); ks=[k for k in P]
    for i in ks:
        for j in ks:
            if i>=j: continue
            if {i,j}=={'M','H'}:
                E.add(('M','H')); continue
            d=np.linalg.norm(pos[i]-pos[j])
            for a in P[i]:
                if a[0] in HANDZ and a[1]-a[0]<0.35 and a[2]>3: continue
                for b in P[j]:
                    if b[0] in HANDZ and b[1]-b[0]<0.35 and b[2]>3: continue
                    if d<a[2]+b[2]+0.05:
                        if a[0]>=b[1]-1e-9: E.add((j,i))
                        if b[0]>=a[1]-1e-9: E.add((i,j))
    return E
def toposort(nodes,E):
    nodes=list(nodes); indeg={n:0 for n in nodes}
    for a,b in E: indeg[b]+=1
    out=[]; ready=[n for n in nodes if indeg[n]==0]
    while ready:
        n=ready.pop(0); out.append(n)
        for a,b in E:
            if a==n:
                indeg[b]-=1
                if indeg[b]==0: ready.append(b)
    return out if len(out)==len(nodes) else None
def build(D1,angles):
    pos={'B':np.zeros(2)}
    for (par,ch,dist),ang in zip(CH,angles):
        if dist is None: dist=D1
        pos[ch]=pos[par]+dist*np.array([math.cos(ang),math.sin(ang)])
    pos['H']=pos['M'].copy(); return pos
def score(D1,ang,P,SK):
    pos=build(D1,ang); ks=list(pos); mn=1e9
    for a in range(len(ks)):
        for b in range(a+1,len(ks)):
            i,j=ks[a],ks[b]
            if {i,j}=={'M','H'}: continue
            mn=min(mn,clear(P,SK,i,j,np.linalg.norm(pos[i]-pos[j]),0.0))
    mn=min(mn,np.linalg.norm(pos['D']-pos['M'])-6.6)
    return mn,pos
def encl(P,pos):
    pts=[(pos[k],r) for k,pr in P.items() for (z0,z1,r) in pr]
    from scipy.optimize import minimize
    c=np.mean([p for p,_ in pts],axis=0)
    f=lambda c:max(np.linalg.norm(c-p)+r for p,r in pts)
    r=minimize(f,c,method='Nelder-Mead',options=dict(xatol=1e-3,fatol=1e-3)); return r.x,r.fun
if __name__=="__main__":
    best=None
    for D1 in (7.2,7.6,8.0,8.4):
        P,H=prims(D1); SK=skipset(P); random.seed(int(D1*10))
        for it in range(60000):
            ang=[random.uniform(0,2*math.pi) for _ in range(7)]
            m,pos=score(D1,ang,P,SK)
            if m<0.4: continue
            E=edges(P,pos)
            if toposort(P.keys(),E) is None: continue
            c,R=encl(P,pos)
            if R>19.0: continue
            val=m*3-R*0.2
            if best is None or val>best[0]:
                best=(val,D1,ang,m,R,c); print(D1,it,'clear',round(m,2),'R',round(R,2),[round(math.degrees(a)) for a in ang],flush=True)
    json.dump(dict(D1=best[1],ang=best[2],c=list(best[5])),open('layout.json','w'))
