import json, spec
from spec import POS, CASE, gears
MAT='AD-C100-HT'
def mov(b):
    g=gears(b)
    ax=lambda k:[float(POS[k][0]),float(POS[k][1])]
    mob={
     'A':{'axis':ax('A'),'parts':[f'A_{b}'],'material':MAT},
     'M':{'axis':ax('M'),'parts':[f'M_{b}','M_hand'],'material':MAT},
     'X':{'axis':ax('X'),'parts':[f'X_{b}'],'material':MAT},
     'Y':{'axis':ax('Y'),'parts':[f'Y_{b}'],'material':MAT},
     'S':{'axis':ax('S'),'parts':['S_body','S_hand'],'material':MAT},
     'I':{'axis':ax('I'),'parts':['I_body'],'material':MAT},
     'H':{'axis':ax('H'),'parts':['H_body','H_hand'],'material':MAT},
     'D':{'axis':ax('D'),'parts':['D_body','D_hand'],'material':MAT},
    }
    z=lambda k,key:g[(k,key)]['z']
    meshes=[
     dict(driver='barrel',driver_teeth=96,driven='A',driven_teeth=12),
     dict(driver='A',driver_teeth=z('A','v'),driven='M',driven_teeth=z('M','p')),
     dict(driver='A',driver_teeth=60,driven='X',driven_teeth=12),
     dict(driver='X',driver_teeth=z('X','w'),driven='Y',driven_teeth=12),
     dict(driver='Y',driver_teeth=36,driven='S',driven_teeth=12),
     dict(driver='M',driver_teeth=12,driven='I',driven_teeth=48),
     dict(driver='I',driver_teeth=15,driven='H',driven_teeth=45),
     dict(driver='I',driver_teeth=12,driven='D',driven_teeth=72),
    ]
    return {'case_centre':CASE,'fixed':['plate','bridge'],'mobiles':mob,'meshes':meshes,
      'hands':{'hour':{'mobile':'H','part':'H_hand'},'minute':{'mobile':'M','part':'M_hand'},
               'seconds':{'mobile':'S','part':'S_hand'},'day':{'mobile':'D','part':'D_hand'}}}
D='/tmp/claude-0/runs/thin1_sonnet/app/delivery/'
json.dump(mov('8'),open(D+'movement.json','w'),indent=1)
json.dump(mov('6'),open(D+'variant_6h.json','w'),indent=1)
