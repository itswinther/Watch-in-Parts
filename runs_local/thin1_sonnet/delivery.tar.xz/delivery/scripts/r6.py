from rig import *
import random
which=sys.argv[1]; M=Mov(DEL+('movement.json' if which=='8' else 'variant_6h.json'))
sp=M.speeds(1/8 if which=='8' else 1/6)
meshed={frozenset((m['driver'],m['driven'])) for m in M.j['meshes']}
names=list(M.mob); random.seed(7); worst=0; bad=[]
for it in range(40):
    t=random.uniform(0,24)
    cur={k:rotz(M.mob[k],M.axis[k],2*math.pi*sp[k]*t) for k in names}
    for a,b in itertools.combinations(names,2):
        if frozenset((a,b)) in meshed: continue
        v=kernel.ivol(cur[a],cur[b])
        worst=max(worst,v)
        if v>0.01: bad.append((t,a,b,v))
print(which,'R6 worst',worst,'bad',bad[:5])
