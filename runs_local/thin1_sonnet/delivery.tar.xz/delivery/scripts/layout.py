import numpy as np, math, random, json, itertools
L0=(0.10,0.90);L1=(1.12,1.52);L2=(1.64,2.04);L3=(2.16,2.56);L4=(2.68,3.08);L5=(3.20,3.60);L6=(3.72,4.12);L7=(4.50,4.90)
FOOT=(0.05,0.35,0.7); TOP=(4.55,4.90,0.9)
def prims(D1):
    rAv=3.8 if D1>7 else 2.7; rMp=4.35 if D1>7 else 3.1
    P={}
    P['B']=[(0,1,9.8),(-1,5.6,0.5),(3.3,4.9,1.0)]
    P['A']=[(*L0,1.4),(*L1,rAv),(*L2,6.2),(-0.5,4.9,0.4),TOP]
    P['X']=[FOOT,(*L2,1.4),(*L3,5.0),(-0.5,4.9,0.4),TOP]
    P['Y']=[FOOT,(*L3,1.8),(*L4,3.8),(-0.5,4.9,0.4),TOP]
    P['S']=[FOOT,(*L4,1.4),(-0.5,7.1,0.4),TOP,(6.8,7.1,5.5)]
    P['M']=[FOOT,(*L1,rMp),(*L5,1.4),(4.15,4.45,1.0),(-0.5,6.7,0.5),(6.4,6.7,5.4)]
    P['H']=[(*L7,4.7),(4.50,6.3,0.9),(6.0,6.3,5.2)]
    P['I']=[FOOT,(*L5,5.0),(*L6,1.4),(*L7,1.7),(-0.5,4.9,0.4)]
    P['D']=[FOOT,(*L6,7.4),(-0.5,5.9,0.4),TOP,(5.6,5.9,3.3)]
    return P
def skipset(P):
    pr=lambda k,lv: [p for p in P[k] if (p[0],p[1])==lv][0]
    return {('B','A'):[(P['B'][0],P['A'][0])],('A','M'):[(pr('A',L1),pr('M',L1))],('A','X'):[(pr('A',L2),pr('X',L2))],
        ('X','Y'):[(pr('X',L3),pr('Y',L3))],('Y','S'):[(pr('Y',L4),pr('S',L4))],('M','I'):[(pr('M',L5),pr('I',L5))],
        ('I','D'):[(pr('I',L6),pr('D',L6))],('I','H'):[(pr('I',L7),pr('H',L7))]}
def prim_clear(P,SK,i,j,d,margin=0.25):
    skip=SK.get((i,j),[])+[(b,a) for (a,b) in SK.get((j,i),[])]
    worst=1e9
    for a in P[i]:
        for b in P[j]:
            if a[1]+0.05<=b[0] or b[1]+0.05<=a[0]: continue
            if (a,b) in skip: continue
            worst=min(worst,d-(a[2]+b[2]+margin))
    return worst
CH=[('B','A',10.8),('A','M',None),('A','X',7.2),('X','Y',6.0),('Y','S',4.8),('M','I',6.3),('I','D',7.56)]
def build(D1,angles):
    pos={'B':np.zeros(2)}
    for (par,ch,dist),ang in zip(CH,angles):
        if dist is None: dist=D1
        pos[ch]=pos[par]+dist*np.array([math.cos(ang),math.sin(ang)])
    pos['H']=pos['M'].copy()
    return pos
def violation(P,SK,pos):
    v=0; ks=list(pos)
    for a in range(len(ks)):
        for b in range(a+1,len(ks)):
            i,j=ks[a],ks[b]
            if {i,j}=={'M','H'}: continue
            d=np.linalg.norm(pos[i]-pos[j]); w=prim_clear(P,SK,i,j,d)
            if w<0: v+=-w
    dm=np.linalg.norm(pos['D']-pos['M'])
    if dm<6.6: v+=6.6-dm
    return v
def encl(P,pos):
    pts=[(pos[k],r) for k,pr in P.items() for (z0,z1,r) in pr]
    from scipy.optimize import minimize
    c=np.mean([p for p,_ in pts],axis=0)
    f=lambda c:max(np.linalg.norm(c-p)+r for p,r in pts)
    res=minimize(f,c,method='Nelder-Mead',options=dict(xatol=1e-3,fatol=1e-3))
    return res.x,res.fun
if __name__=="__main__":
    for D1 in (7.2,4.8):
        P=prims(D1); SK=skipset(P); random.seed(3); best=(1e9,None); feas=None
        for it in range(150000):
            ang=[random.uniform(0,2*math.pi) for _ in range(7)]
            pos=build(D1,ang); v=violation(P,SK,pos)
            if v<best[0]: best=(v,ang)
            if v==0:
                c,R=encl(P,pos)
                if feas is None or R<feas[0]: feas=(R,ang,c); print(D1,'feasible',it,R,c,[round(math.degrees(a)) for a in ang],flush=True)
        print(D1,'best viol',best[0])
