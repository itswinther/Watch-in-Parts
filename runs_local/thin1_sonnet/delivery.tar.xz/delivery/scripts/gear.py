import math, numpy as np
ALPHA=math.radians(25)
def inv(a): return math.tan(a)-a
def gear_points(z, m, s_pitch=None, phase=0.0, nflank=10, nroot=3, ntip=2):
    """CCW polygon points of a full-depth 25deg involute gear, tooth 0 centred on angle `phase` (rad)."""
    rp=m*z/2; rb=rp*math.cos(ALPHA); ra=rp+m; rr=rp-1.25*m
    if s_pitch is None: s_pitch=math.pi*m/2
    half0=s_pitch/(2*rp)+inv(ALPHA)   # half angle at base circle
    def half(r):
        if r<=rb: return half0
        return half0-inv(math.acos(min(1,rb/r)))
    r0=max(rb,rr)
    rs=np.linspace(r0,ra,nflank)
    pitch=2*math.pi/z
    pts=[]
    for k in range(z):
        c=phase+k*pitch
        # right flank (clockwise side, angle c-half) going outward
        # start at root circle
        seq=[]
        if rr<r0: seq.append((rr,half(r0)))
        for r in rs: seq.append((r,half(r)))
        right=[(r,c-h) for r,h in seq]
        left=[(r,c+h) for r,h in reversed(seq)]
        # tip arc between
        tipa=[(ra,c+t) for t in np.linspace(-half(ra),half(ra),ntip)] if False else []
        pts+=[(r*math.cos(a),r*math.sin(a)) for r,a in right]
        pts+=[(r*math.cos(a),r*math.sin(a)) for r,a in left]
        # root arc to next tooth
        a_start=c+half(r0); a_end=c+pitch-half(r0)
        for t in np.linspace(a_start,a_end,nroot+2)[1:-1]:
            pts.append((rr*math.cos(t),rr*math.sin(t)))
    return pts
def dims(z,m): return dict(rp=m*z/2, ra=m*z/2+m, rr=m*z/2-1.25*m)
if __name__=="__main__":
    p=gear_points(12,0.2); print(len(p))
