import math, json, numpy as np
from layout2 import build, prims
from layout import L0,L1,L2,L3,L4,L5,L6,L7
lay=json.load(open('layout.json'))
D1=lay['D1']; ang=list(lay['ang'])
# rotate whole layout so B->A direction is a multiple of 3.75 deg
th=ang[0]; step=math.radians(3.75); new=round(th/step)*step; d=new-th
ang[0]=new
for i in range(1,7): ang[i]+=0 # relative angles are absolute in build(); rotate all
ang=[a+d for a in ang]; ang[0]=new
POS=build(D1,ang)
C0=np.array(lay['c']); 
c,s=math.cos(d),math.sin(d); C=np.array([c*C0[0]-s*C0[1],s*C0[0]+c*C0[1]])
POS={k:np.array(v) for k,v in POS.items()}
CASE=[round(float(C[0]),3),round(float(C[1]),3)]
# levels
LV={0:(0.10,0.90),1:L1,2:L2,3:L3,4:L4,5:L5,6:L6,7:L7}
BACK=0.04
def S(m): return math.pi*m/2-BACK/2
# gear definitions: (mobile, key) -> dict(z, m, level)
M_AV={'8':(36,2*D1/72),'6':(30,2*D1/70)}
M_MP={'8':(36,2*D1/72),'6':(40,2*D1/70)}
def gears(b):
    g={}
    g[('A','p')]=dict(z=12,m=0.2,lv=0,s=math.pi*0.2/2-0.01)
    g[('A','v')]=dict(z=M_AV[b][0],m=M_AV[b][1],lv=1)
    g[('A','w')]=dict(z=60,m=0.2,lv=2)
    g[('M','p')]=dict(z=M_MP[b][0],m=M_MP[b][1],lv=1)
    g[('M','c')]=dict(z=12,m=0.21,lv=5)
    g[('X','p')]=dict(z=12,m=0.2,lv=2)
    g[('X','w')]=dict(z=48 if b=='8' else 36,m=0.2 if b=='8' else 0.25,lv=3)
    g[('Y','p')]=dict(z=12,m=0.2 if b=='8' else 0.25,lv=3)
    g[('Y','w')]=dict(z=36,m=0.2,lv=4)
    g[('S','p')]=dict(z=12,m=0.2,lv=4)
    g[('I','w')]=dict(z=48,m=0.21,lv=5)
    g[('I','p15')]=dict(z=15,m=0.21,lv=6)
    g[('I','p12')]=dict(z=12,m=0.18,lv=7)
    g[('H','w')]=dict(z=45,m=0.21,lv=6)
    g[('D','w')]=dict(z=72,m=0.18,lv=7)
    for k,v in g.items(): v.setdefault('s',S(v['m']))
    return g
# meshes: (driverMobile,key, drivenMobile,key)
MESHES=[('B',None,'A','p'),('A','v','M','p'),('A','w','X','p'),('X','w','Y','p'),('Y','w','S','p'),('M','c','I','w'),('I','p15','H','w'),('I','p12','D','w')]
def gear_phases(b):
    g=gears(b); ph={}
    for dm,dk,nm,nk in MESHES:
        P1=POS[dm]; P2=POS[nm]; th=math.atan2(*(P2-P1)[::-1])
        if dm=='B':
            ph[(nm,nk)]=th+math.pi+math.pi/g[(nm,nk)]['z']
        else:
            ph[(dm,dk)]=th
            ph[(nm,nk)]=th+math.pi+math.pi/g[(nm,nk)]['z']
    return ph
def dist(a,b): return float(np.linalg.norm(POS[a]-POS[b]))
if __name__=="__main__":
    print(CASE, math.degrees(ang[0]), math.degrees(ang[0])/3.75)
    for dm,dk,nm,nk in MESHES:
        for b in '86':
            g=gears(b)
            if dm=='B': zd,md=96,0.2
            else: zd,md=g[(dm,dk)]['z'],g[(dm,dk)]['m']
            zn,mn=g[(nm,nk)]['z'],g[(nm,nk)]['m']
            d=dist(dm,nm); print(b,dm,nm,'d=%.4f'%d,'pitch sum=%.4f'%((zd*md+zn*mn)/2), 'm_from_d=%.4f'%(2*d/(zd+zn)),'mods',md,mn)
