import json, math, sys, numpy as np
from rig import *
def printable(name):
    man=part(name); bb=man.bounding_box(); h=0.05
    ox=0.0113-0.025+h*math.floor((bb[0]-0.3-0.0113)/h); oy=0.0113-0.025+h*math.floor((bb[1]-0.3-0.0113)/h); oz=0.0113-0.025+h*math.floor((bb[2]-0.3-0.0113)/h)
    shape=(int((bb[3]+0.3-ox)/h)+2,int((bb[4]+0.3-oy)/h)+2,int((bb[5]+0.3-oz)/h)+2)
    n,dev=kernel.opening_test_slabs(man,(ox,oy,oz),shape,h,1.5,1.0,6.0)
    return n,dev*h
def static(path,tag):
    M=Mov(path); j=M.j; out={}
    names=list(M.mob.keys())
    # C2
    bad=[]
    for a in names:
        v=kernel.ivol(M.frame,M.mob[a])
        if v>0.01: bad.append(('frame',a,v))
    for a,b in itertools.combinations(names,2):
        v=kernel.ivol(M.mob[a],M.mob[b])
        if v>0.01: bad.append((a,b,v))
    for a,b in itertools.combinations(j['fixed'],2):
        v=kernel.ivol(part(a),part(b))
        if v>0.01: bad.append((a,b,v))
    for k,pl in M.parts_of.items():
        for a,b in itertools.combinations(pl,2):
            v=kernel.ivol(part(a),part(b))
            if v>0.01: bad.append((a,b,v))
    print(tag,'C2 collisions:',bad)
    # frame linked
    print(tag,'fixed gap plate-bridge', kernel.min_distance(part(j['fixed'][0]),part(j['fixed'][1]),0.1))
    # R1 free to turn
    r1=[]
    for a in names:
        for deg in np.arange(0,360,6):
            v=kernel.ivol(M.frame,rotz(M.mob[a],M.axis[a],math.radians(deg)))
            if v>0.01: r1.append((a,deg,v)); break
    print(tag,'R1 free-turn failures',r1)
    # R2 held
    dirs={'+x':[.3,0,0],'-x':[-.3,0,0],'+y':[0,.3,0],'-y':[0,-.3,0],'+z':[0,0,.3],'-z':[0,0,-.3]}
    fr={a:{d:kernel.ivol(M.frame,trans(M.mob[a],v))>0.01 for d,v in dirs.items()} for a in names}
    held={a:dict(fr[a]) for a in names}
    for it in range(3):
        for a in names:
            for b in names:
                if a!=b and abs(M.axis[a][0]-M.axis[b][0])<0.01 and abs(M.axis[a][1]-M.axis[b][1])<0.01:
                    for d,v in dirs.items():
                        if not held[a][d] and held[b][d] and kernel.ivol(trans(M.mob[a],v),M.mob[b])>0.01: held[a][d]=True
    print(tag,'R2 not held:',[(a,d) for a in names for d in dirs if not held[a][d]])
    # R3 seated
    r3=[]
    for k,pl in M.parts_of.items():
        if len(pl)<2: continue
        for p in pl:
            others=kernel.union([part(q) for q in pl if q!=p])
            for d in ['+x','-x','+y','-y']:
                if kernel.ivol(trans(part(p),dirs[d]),others)<=0.01: r3.append((k,p,d))
            if kernel.ivol(trans(part(p),dirs['+z']),others)<=0.01 and kernel.ivol(trans(part(p),dirs['-z']),others)<=0.01: r3.append((k,p,'z'))
        # connectivity
        for a,b in itertools.combinations(pl,2): pass
        gaps=[(a,b,kernel.min_distance(part(a),part(b),0.1)) for a,b in itertools.combinations(pl,2)]
        print(tag,'  gaps',k,[(a,b,round(g,4)) for a,b,g in gaps])
    print(tag,'R3 seat failures',r3)
    # R11/12 hands
    hs=j['hands']; fixedtop=max(part(n).bounding_box()[5] for n in j['fixed'])
    for hn,hd in hs.items():
        p=part(hd['part']); ax=np.array(M.axis[hd['mobile']]); V=kernel.verts(p)
        reach=np.max(np.hypot(V[:,0]-ax[0],V[:,1]-ax[1])); low=V[:,2].min()
        # centre of volume via mesh
        mesh=p.to_mesh(); vp=np.asarray(mesh.vert_properties)[:,:3]; tv=np.asarray(mesh.tri_verts)
        a=vp[tv[:,0]];b=vp[tv[:,1]];c=vp[tv[:,2]]; vol=np.einsum('ij,ij->i',a,np.cross(b,c))/6
        com=((a+b+c)/4*vol[:,None]).sum(0)/vol.sum()
        cd=np.hypot(com[0]-ax[0],com[1]-ax[1])
        proj=p.project(); area=proj.area(); frac=area/(math.pi*reach**2)
        print(tag,hn,'reach %.2f lowz %.2f (frame top %.2f) com %.2f cover %.3f'%(reach,low,fixedtop,cd,frac))
    d=np.hypot(*(np.array(M.axis[hs['day']['mobile']])-np.array(M.axis[hs['hour']['mobile']]))); print(tag,'day-hour axis dist',d)
    # case fit
    C=np.array(j['case_centre']); worst=0
    for n in j['fixed']:
        V=kernel.verts(part(n)); worst=max(worst,np.max(np.hypot(V[:,0]-C[0],V[:,1]-C[1])))
    print(tag,'fixed max radius from case centre',worst)
    for k in M.mob:
        V=kernel.verts(M.mob[k]); ax=np.array(M.axis[k]); r=np.max(np.hypot(V[:,0]-ax[0],V[:,1]-ax[1]))+np.hypot(*(ax-C))
        worst=max(worst,r)
    print(tag,'max extent incl mobiles',worst,'(limit 20.7)')
    zs=[kernel.verts(M.mob[k])[:,2] for k in M.mob]+[kernel.verts(part(n))[:,2] for n in j['fixed']]
    zmin=min(z.min() for z in zs); zmax=max(z.max() for z in zs); print(tag,'height',zmax-zmin,zmin,zmax)
if __name__=="__main__":
    static(DEL+'movement.json','8h'); static(DEL+'variant_6h.json','6h')
