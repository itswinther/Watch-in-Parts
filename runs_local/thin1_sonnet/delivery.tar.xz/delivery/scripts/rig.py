import json, math, sys, itertools, numpy as np
sys.path.insert(0,'/tmp/claude-0/runs/thin1_sonnet/app/tools')
import kernel
APP='/tmp/claude-0/runs/thin1_sonnet/app/'
DEL=APP+'delivery/'
def load_part(name):
    return kernel.load_step_part(DEL+'parts/%s.step'%name,16777216,200000,0.001,0.1,500,120,4096,0.005)
_barrel=None
def barrel():
    global _barrel
    if _barrel is None:
        _barrel=kernel.tris_to_manifold(kernel.read_stl(APP+'supplied/barrel.stl',10**7,10**9))
    return _barrel
def rotz(man,axis,a):
    c,s=math.cos(a),math.sin(a); x,y=axis
    T=np.array([[c,-s,0,x-c*x+s*y],[s,c,0,y-s*x-c*y],[0,0,1,0],[0,0,0,1]])
    return kernel.apply(man,T)
def trans(man,d): return kernel.apply(man,kernel.translation(d))
_cache={}
def part(name):
    if name not in _cache: _cache[name]=load_part(name)
    return _cache[name]
class Mov:
    def __init__(self,path):
        self.j=json.load(open(path)); j=self.j
        self.fixed=[part(n) for n in j['fixed']]
        self.frame=kernel.union(self.fixed)
        self.mob={}; self.axis={}
        for k,m in j['mobiles'].items():
            self.mob[k]=kernel.union([part(n) for n in m['parts']]); self.axis[k]=tuple(m['axis'])
        self.mob['barrel']=barrel(); self.axis['barrel']=(0.0,0.0)
        self.parts_of={k:m['parts'] for k,m in j['mobiles'].items()}
    def speeds(self,barrel_turns_per_h):
        # signed turns per hour, CCW positive; barrel clockwise
        sp={'barrel':-barrel_turns_per_h}
        ms=self.j['meshes']; ch=True
        while ch:
            ch=False
            for m in ms:
                d,n=m['driver'],m['driven']
                if d in sp and n not in sp:
                    sp[n]=-sp[d]*m['driver_teeth']/m['driven_teeth']; ch=True
        return sp
def mesh_test(M,mesh,speedsign,nsteps=24,shifts=(0.0,),verbose=False):
    D,N=mesh['driver'],mesh['driven']; zD,zN=mesh['driver_teeth'],mesh['driven_teeth']
    ax_D=np.array(M.axis[D]); ax_N=np.array(M.axis[N]); dist=np.linalg.norm(ax_D-ax_N); m=2*dist/(zD+zN)
    sD=speedsign[D]/abs(speedsign[D])   # +1 ccw
    pitch=2*math.pi/zD
    res=dict(maxint=0,maxgap=0,minarea=1e9,minH=1e9,minvol=1e9,m=m)
    Nsol=M.mob[N]; Dsol=M.mob[D]
    u=(ax_D-ax_N)/dist
    for sh in shifts:
        Nm=trans(Nsol,[u[0]*(-sh)*0+ (ax_D-ax_N)[0]/dist*sh, (ax_D-ax_N)[1]/dist*sh,0]) if sh else Nsol
        axN=ax_N+u*sh
        for i in range(nsteps):
            phi=sD*pitch*i/nsteps
            Dr=rotz(Dsol,tuple(ax_D),phi)
            Nr=rotz(Nm,tuple(axN),-phi*zD/zN)
            iv=kernel.ivol(Dr,Nr); res['maxint']=max(res['maxint'],iv)
            if iv<=0.01:
                g=kernel.min_distance(Dr,Nr,0.5) if iv<=1e-9 else 0.0
                res['maxgap']=max(res['maxgap'],g)
            # drive step
            phi2=phi+sD*pitch*0.25
            Dr2=rotz(Dsol,tuple(ax_D),phi2)
            cut=(Dr2^Nr)
            vol=cut.volume()
            if vol<=1e-9: H=0; area=0
            else:
                bb=cut.bounding_box(); H=bb[5]-bb[2]; area=vol/H
            # region not occupied before: D(phi) ∩ N is ~0
            res['minvol']=min(res['minvol'],vol); res['minH']=min(res['minH'],H)
            res['minarea']=min(res['minarea'],area/(0.5*m*m) if m>0 else 0)
    return res
if __name__=="__main__":
    which=sys.argv[1]; path=DEL+('movement.json' if which=='8' else 'variant_6h.json')
    M=Mov(path); sp=M.speeds(1/8 if which=='8' else 1/6); print({k:round(v,4) for k,v in sp.items()})
    shifts=(0.0,0.03,-0.03)
    for mesh in M.j['meshes']:
        r=mesh_test(M,mesh,sp,nsteps=int(sys.argv[2]) if len(sys.argv)>2 else 12,shifts=shifts)
        print(mesh['driver'],'->',mesh['driven'],{k:round(v,4) for k,v in r.items()},flush=True)
