from layout import *
random.seed(2); best=(1e9,None)
for it in range(60000):
    ang=[random.uniform(0,2*math.pi) for _ in range(7)]
    pos=build(ang); v=violation(pos)
    if v<best[0]: best=(v,ang)
v,ang=best; pos=build(ang); print(v,[round(math.degrees(a)) for a in ang])
ks=list(pos)
for a in range(len(ks)):
    for b in range(a+1,len(ks)):
        i,j=ks[a],ks[b]
        if {i,j}=={'M','H'}: continue
        d=np.linalg.norm(pos[i]-pos[j]); w=prim_clear(i,j,d)
        if w<0: print(i,j,round(d,2),round(w,2))
