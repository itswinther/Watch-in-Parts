import json, math, sys, itertools, numpy as np
from rig import *
j=json.load(open(DEL+'movement.json'))
names=['plate','bridge']+[p for m in j['mobiles'].values() for p in m['parts']]
sol={n:part(n) for n in names}; sol['barrel']=barrel()
allz=[kernel.verts(s) for s in sol.values()]
V=np.vstack(allz); lo=V.min(0); hi=V.max(0); print('movement bbox',lo,hi)
STEP=0.19
def path_for(n):
    bb=sol[n].bounding_box(); shift=hi[2]+5.2-bb[2]
    k=int(math.ceil(shift/STEP)); 
    return [np.array([0,0,shift*(1-i/k)]) for i in range(k+1)]   # last =0
def blocked(mov,placed):
    for d in path_for(mov)[:-1]:
        s=trans(sol[mov],d)
        if kernel.ivol(s,sol[placed])>0.01: return True
    return False
hands=['H_hand','M_hand','D_hand','S_hand']
core=[n for n in names if n not in hands and n not in('plate','bridge')]+['barrel']
E=set()
for a,b in itertools.permutations(core,2):
    if blocked(a,b): E.add((a,b))   # a moving blocked by placed b => a before b
print('edges',sorted(E))
nodes=list(core); indeg={n:0 for n in nodes}
for a,b in E: indeg[b]+=1
order=[]; ready=[n for n in nodes if indeg[n]==0]
while ready:
    n=ready.pop(0); order.append(n)
    for a,b in E:
        if a==n:
            indeg[b]-=1
            if indeg[b]==0: ready.append(b)
print('core order',order, len(order)==len(nodes))
full=['plate']+order+['bridge','D_hand','H_hand','M_hand','S_hand']
# verify
placed=[]; ok=True
paths={}
for n in full:
    ps=path_for(n); mats=[]
    for d in ps:
        T=np.eye(4); T[:3,3]=d; mats.append(T)
        s=trans(sol[n],d)
        for q in placed:
            v=kernel.ivol(s,sol[q])
            if v>0.01: print('COLLISION',n,q,v,d); ok=False
    paths[n]=[T.tolist() for T in mats]; placed.append(n)
print('all installed',ok)
json.dump({'order':full,'paths':paths},open(DEL+'assembly.json','w'))
