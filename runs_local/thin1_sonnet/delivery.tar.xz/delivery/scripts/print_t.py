from rig2 import *
import os,sys
for f in sorted(os.listdir(DEL+'parts')):
    n=f[:-5]
    n_,dev=printable(n); print(n,'pieces',n_,'maxdev %.3f'%dev,'OK' if (n_>=1 and dev<=0.2) else 'FAIL',flush=True)
