import math, json, os, sys
import numpy as np, cadquery as cq
sys.path.insert(0,'/tmp/claude-0/runs/thin1_sonnet/app/tools')
import kernel
from gear import gear_points
import spec
from spec import POS, LV, gears, gear_phases, CASE
OUT='/tmp/claude-0/runs/thin1_sonnet/app/delivery/parts'
os.makedirs(OUT,exist_ok=True)
def cyl(p,z0,z1,r):
    return cq.Workplane('XY').workplane(offset=z0).center(float(p[0]),float(p[1])).circle(r).extrude(z1-z0)
def gearsolid(p,g,phase,z0=None,z1=None):
    a,b=LV[g['lv']]
    if z0 is not None: a,b=z0,z1
    pts=gear_points(g['z'],g['m'],g['s'],phase,nflank=8,nroot=2)
    pts=[(float(p[0]+x),float(p[1]+y)) for x,y in pts]
    return cq.Workplane('XY').workplane(offset=a).polyline(pts).close().extrude(b-a)
def U(*s):
    r=s[0]
    for x in s[1:]: r=r.union(x,clean=True)
    return r
def body(name,b):
    g=gears(b); ph=gear_phases(b); p=POS[name]
    FOOTz=(0.05,0.35,0.7); TOPz=(4.55,4.9,0.9)
    def common(r_arb,ztop,foot=True,top=True):
        s=[cyl(p,-0.6,0.05,0.4),cyl(p,0.05,ztop,r_arb)]
        if foot: s.append(cyl(p,*FOOTz[:2],FOOTz[2]))
        if top: s.append(cyl(p,TOPz[0],TOPz[1],TOPz[2]))
        return s
    G=lambda k: gearsolid(p,g[(name,k)],ph[(name,k)])
    if name=='A':
        s=[cyl(p,-0.6,0.10,0.4),cyl(p,0.10,4.9,0.4),cyl(p,*TOPz[:2],TOPz[2]),
           gearsolid(p,g[('A','p')],ph[('A','p')],0.10,0.90),G('v'),G('w')]
    elif name=='X': s=common(0.4,4.9)+[G('p'),G('w')]
    elif name=='Y': s=common(0.4,4.9)+[G('p'),G('w')]
    elif name=='S': s=common(0.4,6.8)+[G('p'),cyl(p,6.8,7.1,0.3)]
    elif name=='M': s=common(0.5,6.4,top=False)+[G('p'),G('c'),cyl(p,6.4,6.7,0.35)]
    elif name=='I': s=common(0.4,4.9,top=False)+[G('p15'),G('w'),G('p12')]
    elif name=='D': s=common(0.4,5.6,top=False)+[G('w'),cyl(p,5.6,5.9,0.3)]
    return U(*s)
def hbody(b):
    g=gears(b); ph=gear_phases(b); p=POS['H']
    s=cyl(p,3.72,6.0,0.9).union(gearsolid(p,g[('H','w')],ph[('H','w')]),clean=True).union(cyl(p,4.55,4.9,1.4),clean=True).union(cyl(p,6.0,6.3,0.8),clean=True)
    return s.cut(cyl(p,3.0,7.0,0.55),clean=True)
def hand(p,z0,z1,rin,rhub,length,w0,w1,direction):
    # bar from hub outwards along direction
    c,s=math.cos(direction),math.sin(direction)
    def pt(u,v): return (float(p[0]+u*c-v*s),float(p[1]+u*s+v*c))
    poly=[pt(0,-w0/2),pt(length-0.3,-w1/2),pt(length,-w1/4),pt(length,w1/4),pt(length-0.3,w1/2),pt(0,w0/2)]
    bar=cq.Workplane('XY').workplane(offset=z0).polyline(poly).close().extrude(z1-z0)
    h=cyl(p,z0,z1,rhub)
    r=h.union(bar,clean=True)
    return r.cut(cyl(p,z0-1,z1+1,rin),clean=True)
def plate():
    C=CASE
    r=cq.Workplane('XY').workplane(offset=-0.9).center(*C).circle(19.0).extrude(0.85)
    for k in ['A','X','Y','S','M','I','D']:
        r=r.cut(cyl(POS[k],-1.0,0.0,0.45),clean=True)
    r=r.cut(cyl(POS['B'],-1.0,0.0,0.55),clean=True)
    for q in POSTS: r=r.union(cyl(q,-0.05,4.95,0.8),clean=True)
    return r
def bridge():
    C=CASE
    r=cq.Workplane('XY').workplane(offset=4.95).center(*C).circle(19.0).extrude(0.6)
    r=r.cut(cyl(POS['B'],4,6,0.55),clean=True)
    for k in ['S','D']: r=r.cut(cyl(POS[k],4,6,0.45),clean=True)
    r=r.cut(cyl(POS['M'],4,6,0.95),clean=True)
    return r
def find_posts(n=4):
    from layout2 import prims
    P,H=prims(spec.D1)
    C=np.array(CASE); cands=[]
    for ang in np.linspace(0,2*math.pi,720,endpoint=False):
        for rr in np.arange(10,18.3,0.25):
            q=C+rr*np.array([math.cos(ang),math.sin(ang)]); ok=True; clr=1e9
            for k,pr in P.items():
                for (z0,z1,r) in pr:
                    if z1<-0.05 or z0>4.95: continue
                    if r>3 and z0>5: continue
                    d=np.linalg.norm(q-POS[k])-r-0.8; clr=min(clr,d)
            if clr>0.6: cands.append((q,ang,rr,clr))
    # choose n spread by angle, prefer large radius
    chosen=[]
    for target in np.linspace(0,2*math.pi,n,endpoint=False)+0.3:
        best=None
        for q,a,rr,clr in cands:
            da=abs((a-target+math.pi)%(2*math.pi)-math.pi)
            sc=da*10-rr
            if best is None or sc<best[0]: best=(sc,q)
        chosen.append(best[1])
    return chosen
if __name__=="__main__":
    POSTS=find_posts(4); print('posts',[p.round(2) for p in POSTS])
    json.dump([p.tolist() for p in POSTS],open('posts.json','w'))
    parts={}
    parts['plate']=plate(); parts['bridge']=bridge()
    for b in '86':
        for n in ['A','M','X','Y']: parts[f'{n}_{b}']=body(n,b)
    parts['S_body']=body('S','8'); parts['I_body']=body('I','8'); parts['D_body']=body('D','8')
    parts['H_body']=hbody('8')
    parts['H_hand']=hand(POS['H'],6.0,6.3,0.8,1.2,5.2,1.0,0.5,math.radians(100))
    parts['M_hand']=hand(POS['M'],6.4,6.7,0.35,1.0,5.4,0.9,0.4,math.radians(10))
    parts['D_hand']=hand(POS['D'],5.6,5.9,0.3,0.9,3.3,0.8,0.45,math.radians(200))
    parts['S_hand']=hand(POS['S'],6.8,7.1,0.3,0.8,5.5,0.5,0.25,math.radians(300))
    for n,s in parts.items():
        kernel.write_step(f'{OUT}/{n}.step',s); v=s.val()
        print(n,'valid',v.isValid(),'solids',len(s.solids().vals()),'vol %.2f'%v.Volume(),flush=True)
