from layout import *
import layout
D1=7.2; P=prims(D1); SK=skipset(P)
ang0=[math.radians(x) for x in [35,41,118,109,219,292,244]]
def ok(ang,margin):
    pos=build(D1,ang)
    ks=list(pos); mn=1e9
    for a in range(len(ks)):
        for b in range(a+1,len(ks)):
            i,j=ks[a],ks[b]
            if {i,j}=={'M','H'}: continue
            d=np.linalg.norm(pos[i]-pos[j]); mn=min(mn,prim_clear(P,SK,i,j,d,0.25)+0.25)
    dm=np.linalg.norm(pos['D']-pos['M']); mn=min(mn,dm-6.6+0.25)
    return mn,pos
random.seed(5)
best=ang0; bm,_=ok(best,0)
print('start clearance',bm)
for it in range(40000):
    a=[x+random.gauss(0,0.08) for x in best]
    m,pos=ok(a,0)
    if m>bm+1e-9: best,bm=a,m
print('clearance',bm,[round(math.degrees(x),1) for x in best])
pos=build(D1,best); c,R=encl(P,pos); print(R,c)
for k,v in pos.items(): print(k,v.round(3))
json.dump(dict(ang=best,c=list(c)),open('layout.json','w'))
